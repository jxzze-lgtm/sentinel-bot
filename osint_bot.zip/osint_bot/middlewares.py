"""Middleware de acceso: registra usuarios, avisa a admins y filtra pendientes/bloqueados."""
import logging
from typing import Any, Awaitable, Callable

from aiogram import BaseMiddleware
from aiogram.types import CallbackQuery, Message, TelegramObject

import keyboards as K
import texts as T
from config import settings
from database import db
from utils import code, esc

log = logging.getLogger(__name__)


class AccessMiddleware(BaseMiddleware):
    async def __call__(self, handler: Callable[[TelegramObject, dict], Awaitable[Any]],
                       event: TelegramObject, data: dict) -> Any:
        user = data.get("event_from_user")
        if user is None or user.is_bot:
            return
        chat = data.get("event_chat")
        if chat is not None and chat.type != "private":
            return  # el bot solo funciona en chats privados

        record, is_new = await db.upsert_user(user.id, user.username, user.full_name)
        is_admin = user.id in settings.admin_ids
        data["is_admin"] = is_admin

        if is_new and not is_admin:
            await self._notify_admins(data["bot"], user, record["status"])

        if is_admin or record["status"] == "active":
            return await handler(event, data)

        if record["status"] == "blocked":
            return  # no responder a bloqueados (evita spam)
        if isinstance(event, Message):
            await event.answer(T.PENDING)
        elif isinstance(event, CallbackQuery):
            await event.answer("Acceso pendiente de aprobación", show_alert=True)

    @staticmethod
    async def _notify_admins(bot, user, status: str):
        uname = f"@{user.username}" if user.username else "sin usuario"
        title = "🆕 <b>Nuevo usuario · pendiente</b>" if status == "pending" else "🆕 <b>Nuevo usuario</b>"
        text = (f"{title}\n\n"
                f"├ Nombre · {code(user.full_name)}\n"
                f"├ Usuario · {esc(uname)}\n"
                f"├ ID · {code(user.id)}\n"
                f"└ Idioma · {code(user.language_code or '—')}")
        for admin in settings.admin_ids:
            try:
                await bot.send_message(admin, text, reply_markup=K.new_user_alert(user.id))
            except Exception as e:  # noqa: BLE001
                log.warning("No pude avisar al admin %s: %s", admin, e)
