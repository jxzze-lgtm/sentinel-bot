"""Sentinel OSINT · punto de entrada.

Ejecutar:  python bot.py
"""
import asyncio
import logging
import sys

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import BotCommand, BotCommandScopeChat, BotCommandScopeDefault, ErrorEvent

import scheduler
from config import settings
from database import db
from handlers import admin, common, tools
from middlewares import AccessMiddleware
from services import http

logging.basicConfig(level=logging.INFO, format="%(asctime)s · %(levelname)s · %(name)s · %(message)s")
log = logging.getLogger("sentinel")

DESCRIPTION = (
    "Sentinel OSINT · inteligencia defensiva en Telegram.\n\n"
    "• Dominios e IPs: WHOIS, DNS, certificados, puertos y reputación\n"
    "• Enlaces, archivos y correos sospechosos\n"
    "• Alertas de CVEs y monitoreo de tu marca\n"
    "• Filtraciones de tus correos y limpieza de metadatos\n"
    "• Evidencia web con hash y sello de tiempo\n\n"
    "Toca INICIAR para comenzar."
)
SHORT_DESCRIPTION = "Inteligencia defensiva: dominios, IPs, enlaces, phishing, CVEs, filtraciones y más."


async def setup_bot_profile(bot: Bot):
    commands = [
        BotCommand(command="start", description="Menú principal"),
        BotCommand(command="help", description="Ayuda y atajos"),
        BotCommand(command="cancel", description="Cancelar acción"),
    ]
    await bot.set_my_commands(commands, scope=BotCommandScopeDefault())
    for admin_id in settings.admin_ids:
        try:
            await bot.set_my_commands(commands + [BotCommand(command="admin", description="Panel de administración")],
                                      scope=BotCommandScopeChat(chat_id=admin_id))
        except Exception as e:  # noqa: BLE001
            log.warning("No pude fijar comandos de admin para %s: %s (¿ya le escribió al bot?)", admin_id, e)
    try:
        await bot.set_my_description(DESCRIPTION)
        await bot.set_my_short_description(SHORT_DESCRIPTION)
    except Exception as e:  # noqa: BLE001
        log.warning("No pude fijar la descripción: %s", e)


async def main():
    if not settings.bot_token:
        sys.exit("Falta BOT_TOKEN en el archivo .env")
    if not settings.admin_ids:
        log.warning("ADMIN_IDS está vacío: nadie podrá aprobar usuarios ni ver el panel.")

    await db.connect()
    bot = Bot(settings.bot_token, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    dp = Dispatcher(storage=MemoryStorage())

    access = AccessMiddleware()
    dp.message.outer_middleware(access)
    dp.callback_query.outer_middleware(access)

    dp.include_routers(admin.router, common.router, tools.router)

    @dp.errors()
    async def on_error(event: ErrorEvent):
        """Cualquier fallo inesperado: se registra y el usuario recibe un aviso en lugar de silencio."""
        log.error("Error no controlado: %s", event.exception, exc_info=event.exception)
        upd = event.update
        chat_id = (upd.message and upd.message.chat.id) or (upd.callback_query and upd.callback_query.from_user.id)
        if chat_id:
            try:
                await bot.send_message(chat_id, "⚠️ Algo falló al procesar tu solicitud. Intenta de nuevo o usa /start.")
            except Exception:
                pass
        return True

    await setup_bot_profile(bot)
    sch = scheduler.setup(bot)
    log.info("Sentinel OSINT en marcha. Modo de acceso: %s", await db.access_mode())

    try:
        await bot.delete_webhook(drop_pending_updates=True)
        await dp.start_polling(bot, allowed_updates=dp.resolve_used_update_types())
    finally:
        sch.shutdown(wait=False)
        await http.close()
        await db.close()
        await bot.session.close()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except (KeyboardInterrupt, SystemExit):
        pass
