"""Mini servidor web para el acortador de enlaces (redirecciones + conteo de clics).

Solo se activa si SHORTENER_BASE_URL está configurado en el .env.
"""
import logging

from aiohttp import web

from config import settings
from database import db

log = logging.getLogger(__name__)


async def _redirect(request: web.Request) -> web.Response:
    code = request.match_info.get("code", "")
    link = await db.get_short(code)
    if not link:
        return web.Response(text="Enlace no encontrado.", status=404)
    await db.bump_short(code)
    raise web.HTTPFound(link["url"])


async def _health(request: web.Request) -> web.Response:
    return web.Response(text="ok")


async def start() -> web.AppRunner | None:
    if not settings.shortener_enabled:
        return None
    app = web.Application()
    app.router.add_get("/", _health)
    app.router.add_get("/{code}", _redirect)
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, host="0.0.0.0", port=settings.shortener_port)
    await site.start()
    log.info("Acortador escuchando en el puerto %s · base %s",
             settings.shortener_port, settings.shortener_base_url)
    return runner
