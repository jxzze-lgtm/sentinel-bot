"""Todos los textos de la interfaz en un solo lugar (fácil de editar o traducir)."""
from utils import DIV

WELCOME = f"""<b>Sentinel OSINT</b>
<i>Inteligencia defensiva, directo en Telegram.</i>
{DIV}
Analiza dominios, IPs, enlaces, archivos y correos sospechosos. Vigila vulnerabilidades y suplantaciones de tu marca. Protege tu huella digital y guarda evidencia verificable.

<b>Cómo usarlo</b>
├ Elige una sección del menú
└ O pega un dominio, IP, enlace o CVE: lo detecto solo

<i>Uso ético: activos propios o fines defensivos.</i>"""

PENDING = """⏳ <b>Solicitud enviada</b>

Tu acceso está en revisión. Te aviso aquí mismo en cuanto un administrador lo apruebe."""

APPROVED = """✅ <b>Acceso aprobado</b>

Ya puedes usar Sentinel OSINT. Escribe /start para abrir el menú."""

BLOCKED = "⛔️ Tu acceso a este bot fue revocado."

RATE_LIMITED = "⏱ Vas muy rápido. Espera unos segundos y vuelve a intentarlo."

SECTIONS = {
    "infra": ("infra.png", f"""🌐 <b>Infraestructura</b>
{DIV}
<b>Dominio</b>
WHOIS, DNS, SPF/DMARC, subdominios en certificados y cabeceras de seguridad.

<b>IP</b>
Red y ASN, ubicación aproximada del servidor, puertos expuestos, listas negras y reputación."""),

    "threats": ("threats.png", f"""🛡 <b>Amenazas</b>
{DIV}
<b>Enlace</b>
Sigue las redirecciones, aplica heurísticas y consulta VirusTotal, urlscan y Safe Browsing. Incluye captura de la página sin que la abras.

<b>Archivo</b>
Tipo real, hashes, extensiones engañosas y detecciones en VirusTotal.

<b>Correo</b>
Pega los encabezados y revisa SPF, DKIM, DMARC, ruta y señales de suplantación."""),

    "watch": ("watch.png", f"""🛰 <b>Vigilancia</b>
{DIV}
<b>Buscar CVE</b>
Detalle con CVSS, probabilidad de explotación (EPSS) y si está en el catálogo KEV de CISA.

<b>Alertas CVE</b>
Suscríbete a productos (nginx, wordpress, fortinet…) y recibe un resumen cada mañana.

<b>Monitoreo de marca</b>
Detecta dominios parecidos al tuyo y certificados nuevos con tu nombre. Te aviso si aparece uno nuevo."""),

    "privacy": ("privacy.png", f"""🔐 <b>Privacidad</b>
{DIV}
<b>Filtraciones</b>
Audita tus propios correos en Have I Been Pwned. Requiere verificar que el correo es tuyo; después te aviso si aparece en una filtración nueva.

<b>Metadatos</b>
Envía una foto, PDF o Word como archivo: te muestro qué datos ocultos lleva (GPS, cámara, autor) y te devuelvo la copia limpia."""),

    "evidence": ("evidence.png", f"""🗄 <b>Evidencia</b>
{DIV}
<b>Archivar página</b>
Guarda una copia del HTML con hash SHA-256 y sello de tiempo UTC, más un recibo JSON y una copia pública en Wayback Machine. Útil para documentar fraudes o contenido que podría borrarse."""),
}

HELP = f"""ℹ️ <b>Ayuda</b>
{DIV}
<b>Atajos</b>
├ /start · menú principal
├ /cancel · cancelar la acción actual
└ /admin · panel (solo administradores)

<b>Detección automática</b>
Fuera de cualquier herramienta, pega:
├ un dominio → análisis de dominio
├ una IP → análisis de IP
├ un enlace → revisión de enlace
├ un ID tipo CVE-2024-3400 → detalle de CVE
└ un archivo → eliges revisar o limpiar

<b>Privacidad</b>
No guardo tus consultas, solo un contador de uso. Los archivos se procesan en memoria y se descartan.

<i>Usa esta herramienta solo sobre activos propios o con fines defensivos.</i>"""

PROMPTS = {
    "domain": "🌐 <b>Análisis de dominio</b>\n\nEnvía el dominio.\n<i>Ejemplo:</i> <code>ejemplo.com</code>",
    "ip": "📍 <b>Análisis de IP</b>\n\nEnvía una IP pública.\n<i>Ejemplo:</i> <code>8.8.8.8</code>",
    "url": "🔗 <b>Revisión de enlace</b>\n\nPega o reenvía el enlace sospechoso.\n"
           "<i>No lo abras: yo lo reviso por ti.</i>",
    "file": "📄 <b>Revisión de archivo</b>\n\nEnvía el archivo (máx. {mb} MB).\n"
            "<i>Por defecto solo consulto su hash; no lo subo a ningún sitio.</i>",
    "mail": "✉️ <b>Análisis de correo</b>\n\nPega los <b>encabezados completos</b> del correo.\n\n"
            "Gmail: ⋮ → <i>Mostrar original</i>\nOutlook: Archivo → Propiedades → <i>Encabezados de Internet</i>",
    "cve": "🔎 <b>Buscar CVE</b>\n\nEnvía un ID.\n<i>Ejemplo:</i> <code>CVE-2024-3400</code>",
    "cve_kw": "🛰 <b>Nueva alerta</b>\n\nEscribe el producto o tecnología a vigilar.\n"
              "<i>Ejemplos:</i> <code>nginx</code> · <code>wordpress</code> · <code>fortios</code>",
    "brand": "🛡 <b>Monitoreo de marca</b>\n\nEnvía <b>tu</b> dominio.\n<i>Ejemplo:</i> <code>miempresa.com</code>",
    "breach": "🔐 <b>Agregar correo</b>\n\nEscribe un correo <b>tuyo</b>. Te mandaré un código para confirmarlo.",
    "breach_code": "📨 Te envié un código de 6 dígitos. Escríbelo aquí (vence en 15 min).",
    "meta": "🧹 <b>Metadatos</b>\n\nEnvía la imagen, PDF o .docx <b>como archivo</b>\n"
            "(📎 → Archivo) para que Telegram no lo comprima.",
    "archive": "🗄 <b>Archivar página</b>\n\nEnvía la URL a preservar.",
}

MISSING_KEY = "🔑 Esta herramienta necesita la llave <code>{key}</code> en el archivo .env."
