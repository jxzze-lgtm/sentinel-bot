"""Todos los textos de la interfaz en un solo lugar (fácil de editar o traducir)."""
from utils import DIV

WELCOME = f"""<b>Sentinel OSINT</b>
<i>Inteligencia defensiva, directo en Telegram.</i>
{DIV}
Analiza dominios, IPs, enlaces, archivos y correos sospechosos. Vigila vulnerabilidades y suplantaciones de tu marca. Protege tu huella digital y guarda evidencia verificable.

<b>Cómo usarlo</b>
├ Elige una sección del menú
└ O pega un dominio, IP, enlace o CVE: lo detecto solo

<i>Uso ético: activos propios o fines defensivos.</i>"""

PENDING = """⏳ <b>Solicitud enviada</b>

Tu acceso está en revisión. Te aviso aquí mismo en cuanto un administrador lo apruebe."""

APPROVED = """✅ <b>Acceso aprobado</b>

Ya puedes usar Sentinel OSINT. Escribe /start para abrir el menú."""

BLOCKED = "⛔️ Tu acceso a este bot fue revocado."

RATE_LIMITED = "⏱ Vas muy rápido. Espera unos segundos y vuelve a intentarlo."

SECTIONS = {
    "infra": ("infra.png", f"""🌐 <b>Infraestructura</b>
{DIV}
<b>Dominio</b>
WHOIS, DNS, SPF/DMARC, subdominios en certificados y cabeceras de seguridad.

<b>IP</b>
Red y ASN, ubicación aproximada del servidor, puertos expuestos, listas negras y reputación.

<b>Certificado SSL</b>
Emisor, protocolo y días que faltan para que caduque."""),

    "threats": ("threats.png", f"""🛡 <b>Amenazas</b>
{DIV}
<b>Enlace</b>
Sigue las redirecciones, aplica heurísticas y consulta VirusTotal, urlscan y Safe Browsing. Incluye captura de la página sin que la abras.

<b>Archivo</b>
Tipo real, hashes, extensiones engañosas y detecciones en VirusTotal.

<b>Correo</b>
Pega los encabezados y revisa SPF, DKIM, DMARC, ruta y señales de suplantación.

<b>Mensaje/SMS</b>
Pega un mensaje sospechoso y te doy una calificación de riesgo de estafa."""),

    "watch": ("watch.png", f"""🛰 <b>Vigilancia</b>
{DIV}
<b>Buscar CVE</b>
Detalle con CVSS, probabilidad de explotación (EPSS) y si está en el catálogo KEV de CISA.

<b>Alertas CVE</b>
Suscríbete a productos (nginx, wordpress, fortinet…) y recibe un resumen cada mañana.

<b>Monitoreo de marca</b>
Detecta dominios parecidos al tuyo y certificados nuevos con tu nombre. Te aviso si aparece uno nuevo."""),

    "privacy": ("privacy.png", f"""🔐 <b>Privacidad</b>
{DIV}
<b>Filtraciones</b>
Audita tus propios correos en Have I Been Pwned. Requiere verificar que el correo es tuyo; después te aviso si aparece en una filtración nueva.

<b>Contraseña</b>
Comprueba si una contraseña ya apareció en filtraciones. No sale del servidor: solo se consulta un fragmento de su huella.

<b>Metadatos</b>
Envía una foto, PDF o Word como archivo: te muestro qué datos ocultos lleva (GPS, cámara, autor) y te devuelvo la copia limpia."""),

    "utils": ("utils.png", f"""🧰 <b>Utilidades</b>
{DIV}
<b>Conversión</b>
Office → PDF · Imágenes → PDF · PDF → imágenes · convertir formato de imagen.

<b>PDF</b>
Unir varios en uno · dividir en páginas sueltas.

<b>Otros</b>
Comprimir imágenes · generar códigos QR · decodificar Base64, hex, URL y JWT.

<i>Los archivos se procesan y se borran enseguida; no se almacenan.</i>"""),

    "documents": ("documents.png", f"""📄 <b>Documentos</b>
{DIV}
<b>Firmar / sellar PDF</b>
Estampa firma, fecha y un folio único en cada página.

<b>Marca de agua</b>
Añade un texto diagonal (CONFIDENCIAL, tu marca) en todo el PDF.

<b>Proteger / quitar contraseña</b>
Cifra un PDF con contraseña o se la quita.

<b>Comprimir PDF</b> · <b>Tablas → Excel</b>
Reduce el peso, o extrae las tablas a una hoja de cálculo."""),

    "business": ("business.png", f"""💼 <b>Negocio</b>
{DIV}
<b>Recibo / Cotización</b>
Llenas unos datos y te devuelvo un PDF con formato profesional, con subtotal, IVA y total.

<b>Códigos QR útiles</b>
Wi-Fi (para compartir tu red), contacto (vCard) y enlace de pago.

<b>Encuesta</b>
Crea una pregunta con opciones y comparte; el bot cuenta los votos."""),

    "productivity": ("productivity.png", f"""📌 <b>Productividad</b>
{DIV}
<b>Recordatorios</b>
“en 2h …”, “mañana 9:00 …”, “viernes 10:00 …” y te aviso a tiempo.

<b>Notas</b>
Guarda ideas o enlaces y búscalos después.

<b>Acortador de enlaces</b>
Crea enlaces cortos tuyos con conteo de clics."""),

    "evidence": ("evidence.png", f"""🗄 <b>Evidencia</b>
{DIV}
<b>Archivar página</b>
Guarda una copia del HTML con hash SHA-256 y sello de tiempo UTC, más un recibo JSON y una copia pública en Wayback Machine. Útil para documentar fraudes o contenido que podría borrarse."""),
}

HELP = f"""ℹ️ <b>Ayuda</b>
{DIV}
<b>Atajos</b>
├ /start · menú principal
├ /cancel · cancelar la acción actual
└ /admin · panel (solo administradores)

<b>Detección automática</b>
Fuera de cualquier herramienta, pega:
├ un dominio → análisis de dominio
├ una IP → análisis de IP
├ un enlace → revisión de enlace
├ un ID tipo CVE-2024-3400 → detalle de CVE
└ un archivo → eliges revisar o limpiar

<b>Secciones</b>
🌐 Infraestructura · 🛡 Amenazas · 🛰 Vigilancia
🔐 Privacidad · 🧰 Utilidades · 🗄 Evidencia

<b>Privacidad</b>
No guardo tus consultas, solo un contador de uso. Los archivos se procesan en memoria y se descartan.

<i>Usa esta herramienta solo sobre activos propios o con fines defensivos.</i>"""

PROMPTS = {
    "domain": "🌐 <b>Análisis de dominio</b>\n\nEnvía el dominio.\n<i>Ejemplo:</i> <code>ejemplo.com</code>",
    "ip": "📍 <b>Análisis de IP</b>\n\nEnvía una IP pública.\n<i>Ejemplo:</i> <code>8.8.8.8</code>",
    "url": "🔗 <b>Revisión de enlace</b>\n\nPega o reenvía el enlace sospechoso.\n"
           "<i>No lo abras: yo lo reviso por ti.</i>",
    "file": "📄 <b>Revisión de archivo</b>\n\nEnvía el archivo (máx. {mb} MB).\n"
            "<i>Por defecto solo consulto su hash; no lo subo a ningún sitio.</i>",
    "mail": "✉️ <b>Análisis de correo</b>\n\nPega los <b>encabezados completos</b> del correo.\n\n"
            "Gmail: ⋮ → <i>Mostrar original</i>\nOutlook: Archivo → Propiedades → <i>Encabezados de Internet</i>",
    "cve": "🔎 <b>Buscar CVE</b>\n\nEnvía un ID.\n<i>Ejemplo:</i> <code>CVE-2024-3400</code>",
    "cve_kw": "🛰 <b>Nueva alerta</b>\n\nEscribe el producto o tecnología a vigilar.\n"
              "<i>Ejemplos:</i> <code>nginx</code> · <code>wordpress</code> · <code>fortios</code>",
    "brand": "🛡 <b>Monitoreo de marca</b>\n\nEnvía <b>tu</b> dominio.\n<i>Ejemplo:</i> <code>miempresa.com</code>",
    "breach": "🔐 <b>Agregar correo</b>\n\nEscribe un correo <b>tuyo</b>. Te mandaré un código para confirmarlo.",
    "breach_code": "📨 Te envié un código de 6 dígitos. Escríbelo aquí (vence en 15 min).",
    "meta": "🧹 <b>Metadatos</b>\n\nEnvía la imagen, PDF o .docx <b>como archivo</b>\n"
            "(📎 → Archivo) para que Telegram no lo comprima.",
    "archive": "🗄 <b>Archivar página</b>\n\nEnvía la URL a preservar.",
    # Defensivas nuevas
    "ssl": "🔒 <b>Certificado SSL</b>\n\nEnvía el dominio.\n<i>Ejemplo:</i> <code>ejemplo.com</code>",
    "message": "💬 <b>Mensaje / SMS sospechoso</b>\n\nPega el texto completo del mensaje "
               "(con sus enlaces). No abras nada: yo lo reviso.",
    "password": "🔑 <b>Comprobar contraseña</b>\n\nEscribe la contraseña a revisar.\n"
                "🔒 <i>No se guarda ni se envía completa: solo se consulta un fragmento de su huella. "
                "Aun así, borra tu mensaje después.</i>",
    # Utilidades
    "office_pdf": "📄 <b>Office → PDF</b>\n\nEnvía un archivo Word, Excel, PowerPoint, ODT, RTF o TXT "
                  "<b>como archivo</b> (📎 → Archivo).",
    "img_pdf": "🖼 <b>Imágenes → PDF</b>\n\nEnvía una o varias imágenes (como foto o como archivo). "
               "Cuando termines, toca <b>Generar</b>.",
    "pdf_img": "📑 <b>PDF → imágenes</b>\n\nEnvía el PDF como archivo. Te devuelvo cada página como PNG "
               f"(máx. 30 páginas).",
    "img_format": "🔄 <b>Convertir imagen</b>\n\nEnvía la imagen como archivo y luego elige el formato de salida.",
    "merge": "🔀 <b>Unir PDF</b>\n\nEnvía los PDF en el orden que quieras unirlos. "
             "Cuando termines, toca <b>Generar</b>.",
    "split": "✂️ <b>Dividir PDF</b>\n\nEnvía el PDF como archivo. Te devuelvo cada página como un PDF aparte "
             "(máx. 50).",
    "compress": "🗜 <b>Comprimir imagen</b>\n\nEnvía la imagen como archivo. Te devuelvo una versión más ligera.",
    "qr": "🔳 <b>Generar QR</b>\n\nEscribe el texto, enlace o dato para convertir en código QR.",
    "decode": "🧰 <b>Decodificador</b>\n\nPega un texto en Base64, hexadecimal, URL-encoding o un JWT "
              "y lo decodifico.",
    "collage": "🖇 <b>Unir imágenes</b>\n\nEnvía varias imágenes; las apilo en una sola (vertical). "
               "Cuando termines, toca <b>Generar</b>.",
    "convertx": "🔁 <b>Conversor</b>\n\nEscribe una conversión:\n"
                "<code>100 km a mi</code> · <code>5 kg a lb</code> · <code>30 C a F</code>\n"
                "<code>100 USD a MXN</code> · <code>50 EUR a USD</code>",
    "translate": "🌐 <b>Traductor</b>\n\n¿A qué idioma quieres traducir?",
    "qrscan": "📷 <b>Analizar QR</b>\n\nEnvía la foto de un código QR (de preferencia como archivo). "
              "Lo decodifico y reviso a dónde lleva sin que lo abras.",
    "securitytxt": "📋 <b>security.txt</b>\n\nEnvía el dominio a revisar.\n<i>Ejemplo:</i> <code>ejemplo.com</code>",
    # Documentos
    "doc_sign": "✍️ <b>Firmar PDF</b>\n\nEnvía el PDF como archivo.",
    "doc_wm": "💧 <b>Marca de agua</b>\n\nEnvía el PDF como archivo.",
    "doc_protect": "🔒 <b>Proteger PDF</b>\n\nEnvía el PDF como archivo.",
    "doc_unprotect": "🔓 <b>Quitar contraseña</b>\n\nEnvía el PDF protegido como archivo.",
    "doc_compress": "🗜 <b>Comprimir PDF</b>\n\nEnvía el PDF como archivo.",
    "doc_tables": "📊 <b>Tablas → Excel</b>\n\nEnvía el PDF con tablas como archivo. "
                  "Funciona mejor con tablas que tienen líneas.",
    # Negocio
    "biz_receipt": "🧾 <b>Recibo</b>\n\nPega los datos así:\n\n"
                   "<code>Negocio: Mi Empresa\nCliente: Juan Pérez\n"
                   "Café | 2 | 45\nPan | 5 | 12.5\nIVA: 16\nNota: Gracias</code>\n\n"
                   "<i>Cada concepto: descripción | cantidad | precio.</i>",
    "biz_quote": "📋 <b>Cotización</b>\n\nPega los datos así:\n\n"
                 "<code>Negocio: Mi Empresa\nCliente: Juan Pérez\n"
                 "Instalación | 1 | 4500\nMantenimiento | 1 | 1200\nIVA: 16</code>\n\n"
                 "<i>Cada concepto: descripción | cantidad | precio.</i>",
    "biz_wifi": "📶 <b>QR de Wi-Fi</b>\n\n¿Tu red tiene contraseña?",
    "biz_vcard": "👤 <b>QR de contacto</b>\n\nEscribe los datos así (solo el nombre es obligatorio):\n\n"
                 "<code>Nombre: Jose Fernando\nTel: +526620000000\nEmail: jose@correo.com\n"
                 "Empresa: Mi Negocio\nWeb: https://misitio.com</code>",
    "biz_payment": "💳 <b>QR de pago</b>\n\nPega el enlace de pago (PayPal, Mercado Pago, tu tienda…) "
                   "y lo convierto en QR.",
    # Productividad
    "reminder": "⏰ <b>Nuevo recordatorio</b>\n\nEscribe cuándo y qué:\n"
                "<code>en 2h sacar la ropa</code>\n<code>mañana 9:00 junta con el equipo</code>\n"
                "<code>viernes 10:00 entregar reporte</code>\n<code>2026-12-25 08:00 felicitar</code>",
    "note": "📝 <b>Nueva nota</b>\n\nEscribe la nota (texto o enlace).",
    "note_search": "🔎 <b>Buscar nota</b>\n\nEscribe una palabra a buscar.",
    "short": "🔗 <b>Acortar enlace</b>\n\nPega la URL larga que quieres acortar.",
    "poll": "📊 <b>Nueva encuesta</b>\n\nEscribe la pregunta y las opciones, una por línea:\n\n"
            "<code>¿Dónde comemos el viernes?\nTacos\nPizza\nSushi</code>\n\n"
            "<i>La primera línea es la pregunta; las demás, las opciones (2 a 10).</i>",
}

MISSING_KEY = "🔑 Esta herramienta necesita la llave <code>{key}</code> en el archivo .env."
