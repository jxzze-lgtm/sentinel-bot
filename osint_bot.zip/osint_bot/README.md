# Sentinel OSINT · Bot de Telegram

Inteligencia defensiva desde Telegram: dominios, IPs, enlaces, archivos y correos sospechosos, alertas de CVEs, monitoreo de marca, filtraciones de tus propios correos, limpieza de metadatos y archivo de evidencia.

## Estructura

```
osint_bot/
├── bot.py               # punto de entrada
├── config.py            # lee el .env
├── database.py          # SQLite (usuarios, alertas, vigilancias)
├── middlewares.py       # control de acceso y aviso de usuarios nuevos
├── keyboards.py         # botones
├── texts.py             # todos los textos (edítalos aquí)
├── ui.py                # pantallas con imagen y mensajes largos
├── scheduler.py         # tareas diarias / periódicas
├── handlers/
│   ├── common.py        # /start, menús, ayuda
│   ├── tools.py         # las herramientas + detección automática
│   └── admin.py         # panel de administración
├── services/            # la lógica de cada herramienta
├── assets/img/          # banners y avatar
├── scripts/generate_assets.py
└── deploy/sentinel.service
```

## Secciones y herramientas

| Sección | Herramienta | Fuentes | Llave |
|---|---|---|---|
| 🌐 Infraestructura | Dominio | WHOIS, DNS, SPF/DMARC, crt.sh, cabeceras HTTP | no |
| | IP | ipinfo, Shodan InternetDB, DNSBL, AbuseIPDB | AbuseIPDB opcional |
| 🛡 Amenazas | Enlace | redirecciones, heurísticas, VirusTotal, urlscan (con captura), Safe Browsing | opcionales |
| | Archivo | tipo real, hashes, VirusTotal | VirusTotal |
| | Correo phishing | encabezados, SPF/DKIM/DMARC, ruta, suplantación | no |
| 🛰 Vigilancia | Buscar CVE | NVD, CISA KEV, EPSS | NVD opcional |
| | Alertas CVE | resumen diario por producto | NVD opcional |
| | Monitoreo de marca | variantes typosquatting + certificados nuevos | no |
| 🔐 Privacidad | Filtraciones | Have I Been Pwned (con verificación por código) | HIBP (de pago) |
| | Metadatos | EXIF/GPS, PDF, Word → copia limpia | no |
| 🗄 Evidencia | Archivar página | HTML + SHA‑256 + recibo JSON + Wayback | no |

**Detección automática:** sin abrir ninguna herramienta, el usuario puede pegar un dominio, IP, enlace, CVE o encabezados de correo, o mandar un archivo, y el bot sabe qué hacer.

**Panel de administración** (`/admin` o botón ⚙️): estadísticas, usuarios pendientes, aprobar / bloquear / suspender, ficha de cada usuario, difusión a todos y cambio de modo de acceso (abierto o con aprobación). Cada usuario nuevo te llega como notificación con botones para aprobarlo.

---

## 1. Crear el bot en Telegram

1. Abre **@BotFather** → `/newbot` → elige nombre y usuario. Guarda el **token**.
2. `/setuserpic` → sube `assets/img/avatar.png`.
3. Escríbele a **@userinfobot** para saber tu **ID numérico** (será el `ADMIN_IDS`).
4. Mándale cualquier mensaje a tu bot nuevo (así podrá escribirte cuando arranque).

> La descripción que ve la gente antes de pulsar *Iniciar* y la lista de comandos se configuran solas al arrancar el bot.

## 2. Crear la instancia en Lightsail

1. Consola de AWS → **Lightsail** → *Create instance*.
2. Plataforma **Linux/Unix** → *OS Only* → **Ubuntu 24.04 LTS**.
3. Plan: el de **1 GB de RAM** va sobrado (el de 512 MB también funciona).
4. Crea la instancia y entra con el botón **Connect using SSH** (abre una terminal en el navegador).

> No necesitas abrir puertos: el bot usa *long polling* (él se conecta a Telegram, nadie se conecta a él).

**Importante:** en *Billing → Budgets* crea una alerta de presupuesto (por ejemplo, 1 USD) para enterarte si algo empieza a cobrar cuando termine el periodo de prueba.

## 3. Subir el código

Opción A — desde tu computadora (descarga la llave SSH en *Account → SSH keys*):

```bash
scp -i LightsailDefaultKey.pem osint_bot.zip ubuntu@IP_DE_TU_INSTANCIA:~
```

Opción B — súbelo a un repositorio privado de GitHub y en el servidor haz `git clone`.

## 4. Instalar

En la terminal del servidor:

```bash
sudo apt update && sudo apt install -y python3-venv unzip
unzip osint_bot.zip && cd osint_bot
python3 -m venv .venv
.venv/bin/pip install -r requirements.txt
cp .env.example .env
nano .env        # pega BOT_TOKEN, ADMIN_IDS y las llaves que tengas
```

Prueba en primer plano:

```bash
.venv/bin/python bot.py
```

Abre tu bot en Telegram y manda `/start`. Si todo responde, detén con `Ctrl+C`.

## 5. Dejarlo corriendo 24/7

```bash
sudo cp deploy/sentinel.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now sentinel
```

Comandos útiles:

```bash
sudo systemctl status sentinel      # ¿está vivo?
journalctl -u sentinel -f           # ver logs en vivo
sudo systemctl restart sentinel     # tras cambiar código o .env
```

## 6. Llaves de API (recomendadas)

Todas tienen plan gratuito excepto HIBP:

- **VirusTotal** → enlaces y archivos (4 consultas/min en plan gratis)
- **urlscan.io** → veredicto y captura de la página
- **Google Safe Browsing** → listas de phishing/malware de Google
- **AbuseIPDB** → reputación de IPs
- **NVD** → sube el límite de consultas de CVEs
- **HIBP** → auditoría de filtraciones (plan de pago más básico)

Sin llaves, el bot igual funciona con: dominio, IP (parcial), enlace (heurísticas + redirecciones), correo, CVE, marca, metadatos y evidencia.

## 7. Filtraciones: verificación de correo

Para que nadie use el bot para consultar correos ajenos, cada correo se verifica con un código de 6 dígitos enviado por SMTP. Con Gmail:

1. Activa la verificación en 2 pasos en tu cuenta.
2. Crea una **contraseña de aplicación** y ponla en `SMTP_PASSWORD`.

Si no configuras SMTP, solo los administradores pueden agregar correos.

## Personalizar

- **Textos:** `texts.py`
- **Imágenes:** edita colores o textos en `scripts/generate_assets.py` y ejecuta `python scripts/generate_assets.py`
- **Límites:** `RATE_LIMIT_PER_MINUTE`, `MAX_FILE_MB`, horarios en `.env`

## Seguridad y uso responsable

- El bot valida cada URL y cada redirección para no consultar redes internas del servidor (protección SSRF).
- Los archivos se procesan en memoria; solo la evidencia archivada se guarda en `data/evidence/`.
- Solo funciona en chats privados y aplica límite de consultas por usuario.
- Úsalo sobre activos propios o con fines defensivos. Las fuentes consultadas tienen sus propios términos de uso.
