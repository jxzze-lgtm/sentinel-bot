"""Persistencia en SQLite (aiosqlite). Un solo archivo: data/sentinel.db"""
import json
import time

import aiosqlite

from config import settings

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id          INTEGER PRIMARY KEY,
    username    TEXT,
    full_name   TEXT,
    status      TEXT NOT NULL DEFAULT 'pending',   -- pending | active | blocked
    joined_at   INTEGER NOT NULL,
    last_seen   INTEGER NOT NULL,
    queries     INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS usage (
    user_id INTEGER NOT NULL,
    tool    TEXT NOT NULL,
    ts      INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS usage_ts ON usage(ts);
CREATE TABLE IF NOT EXISTS cve_subs (
    user_id INTEGER NOT NULL,
    keyword TEXT NOT NULL,
    PRIMARY KEY (user_id, keyword)
);
CREATE TABLE IF NOT EXISTS brand_watch (
    user_id   INTEGER NOT NULL,
    domain    TEXT NOT NULL,
    known     TEXT NOT NULL DEFAULT '[]',
    last_scan INTEGER,
    PRIMARY KEY (user_id, domain)
);
CREATE TABLE IF NOT EXISTS emails (
    user_id        INTEGER NOT NULL,
    email          TEXT NOT NULL,
    verified       INTEGER NOT NULL DEFAULT 0,
    code           TEXT,
    code_expires   INTEGER,
    known_breaches TEXT NOT NULL DEFAULT '[]',
    PRIMARY KEY (user_id, email)
);
CREATE TABLE IF NOT EXISTS kv (
    key   TEXT PRIMARY KEY,
    value TEXT
);
CREATE TABLE IF NOT EXISTS reminders (
    id       INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id  INTEGER NOT NULL,
    text     TEXT NOT NULL,
    due_ts   INTEGER NOT NULL,
    done     INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS reminders_due ON reminders(due_ts, done);
CREATE TABLE IF NOT EXISTS notes (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id   INTEGER NOT NULL,
    text      TEXT NOT NULL,
    created   INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS short_links (
    code     TEXT PRIMARY KEY,
    user_id  INTEGER NOT NULL,
    url      TEXT NOT NULL,
    clicks   INTEGER NOT NULL DEFAULT 0,
    created  INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS polls (
    id       TEXT PRIMARY KEY,
    owner    INTEGER NOT NULL,
    question TEXT NOT NULL,
    options  TEXT NOT NULL,
    created  INTEGER NOT NULL,
    closed   INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS poll_votes (
    poll_id  TEXT NOT NULL,
    user_id  INTEGER NOT NULL,
    choice   INTEGER NOT NULL,
    PRIMARY KEY (poll_id, user_id)
);
"""


class DB:
    def __init__(self, path):
        self.path = path
        self.conn: aiosqlite.Connection | None = None

    async def connect(self):
        self.conn = await aiosqlite.connect(self.path)
        self.conn.row_factory = aiosqlite.Row
        await self.conn.executescript(SCHEMA)
        await self.conn.commit()

    async def close(self):
        if self.conn:
            await self.conn.close()

    async def _one(self, sql, args=()):
        async with self.conn.execute(sql, args) as cur:
            return await cur.fetchone()

    async def _all(self, sql, args=()):
        async with self.conn.execute(sql, args) as cur:
            return await cur.fetchall()

    async def _exec(self, sql, args=()):
        await self.conn.execute(sql, args)
        await self.conn.commit()

    # ── Ajustes ─────────────────────────────────────────────────────────
    async def get_kv(self, key: str, default: str | None = None) -> str | None:
        row = await self._one("SELECT value FROM kv WHERE key=?", (key,))
        return row["value"] if row else default

    async def set_kv(self, key: str, value: str):
        await self._exec("INSERT INTO kv(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                         (key, value))

    async def access_mode(self) -> str:
        return await self.get_kv("access_mode", settings.access_mode)

    # ── Usuarios ────────────────────────────────────────────────────────
    async def upsert_user(self, uid: int, username: str | None, full_name: str) -> tuple[dict, bool]:
        """Registra o actualiza. Devuelve (usuario, es_nuevo)."""
        now = int(time.time())
        row = await self._one("SELECT * FROM users WHERE id=?", (uid,))
        if row:
            await self._exec("UPDATE users SET username=?, full_name=?, last_seen=? WHERE id=?",
                             (username, full_name, now, uid))
            return dict(row), False
        is_admin = uid in settings.admin_ids
        status = "active" if is_admin or await self.access_mode() == "open" else "pending"
        await self._exec("INSERT INTO users(id,username,full_name,status,joined_at,last_seen) VALUES(?,?,?,?,?,?)",
                         (uid, username, full_name, status, now, now))
        return dict(await self._one("SELECT * FROM users WHERE id=?", (uid,))), True

    async def get_user(self, uid: int) -> dict | None:
        row = await self._one("SELECT * FROM users WHERE id=?", (uid,))
        return dict(row) if row else None

    async def set_status(self, uid: int, status: str):
        await self._exec("UPDATE users SET status=? WHERE id=?", (status, uid))

    async def list_users(self, status: str | None, offset: int, limit: int) -> list[dict]:
        if status:
            rows = await self._all("SELECT * FROM users WHERE status=? ORDER BY joined_at DESC LIMIT ? OFFSET ?",
                                   (status, limit, offset))
        else:
            rows = await self._all("SELECT * FROM users ORDER BY joined_at DESC LIMIT ? OFFSET ?", (limit, offset))
        return [dict(r) for r in rows]

    async def count_users(self, status: str | None = None) -> int:
        if status:
            row = await self._one("SELECT COUNT(*) c FROM users WHERE status=?", (status,))
        else:
            row = await self._one("SELECT COUNT(*) c FROM users")
        return row["c"]

    async def active_ids(self) -> list[int]:
        return [r["id"] for r in await self._all("SELECT id FROM users WHERE status='active'")]

    async def log_usage(self, uid: int, tool: str):
        now = int(time.time())
        await self.conn.execute("INSERT INTO usage(user_id,tool,ts) VALUES(?,?,?)", (uid, tool, now))
        await self.conn.execute("UPDATE users SET queries=queries+1 WHERE id=?", (uid,))
        await self.conn.commit()

    async def stats(self) -> dict:
        day = int(time.time()) - 86400
        week = int(time.time()) - 7 * 86400
        tools = await self._all("SELECT tool, COUNT(*) c FROM usage WHERE ts>? GROUP BY tool ORDER BY c DESC",
                                (week,))
        return {
            "total": await self.count_users(),
            "active": await self.count_users("active"),
            "pending": await self.count_users("pending"),
            "blocked": await self.count_users("blocked"),
            "new_24h": (await self._one("SELECT COUNT(*) c FROM users WHERE joined_at>?", (day,)))["c"],
            "seen_24h": (await self._one("SELECT COUNT(*) c FROM users WHERE last_seen>?", (day,)))["c"],
            "queries_24h": (await self._one("SELECT COUNT(*) c FROM usage WHERE ts>?", (day,)))["c"],
            "tools_7d": [(r["tool"], r["c"]) for r in tools],
        }

    # ── CVE ─────────────────────────────────────────────────────────────
    async def cve_keywords(self, uid: int) -> list[str]:
        return [r["keyword"] for r in await self._all("SELECT keyword FROM cve_subs WHERE user_id=? ORDER BY keyword", (uid,))]

    async def add_cve_keyword(self, uid: int, kw: str):
        await self._exec("INSERT OR IGNORE INTO cve_subs(user_id,keyword) VALUES(?,?)", (uid, kw))

    async def del_cve_keyword(self, uid: int, kw: str):
        await self._exec("DELETE FROM cve_subs WHERE user_id=? AND keyword=?", (uid, kw))

    async def cve_subscribers(self) -> dict[int, list[str]]:
        rows = await self._all("SELECT c.user_id, c.keyword FROM cve_subs c JOIN users u ON u.id=c.user_id "
                               "WHERE u.status='active'")
        out: dict[int, list[str]] = {}
        for r in rows:
            out.setdefault(r["user_id"], []).append(r["keyword"])
        return out

    # ── Marca ───────────────────────────────────────────────────────────
    async def brands(self, uid: int) -> list[str]:
        return [r["domain"] for r in await self._all("SELECT domain FROM brand_watch WHERE user_id=? ORDER BY domain", (uid,))]

    async def add_brand(self, uid: int, domain: str, known: list[str]):
        await self._exec("INSERT OR REPLACE INTO brand_watch(user_id,domain,known,last_scan) VALUES(?,?,?,?)",
                         (uid, domain, json.dumps(known), int(time.time())))

    async def del_brand(self, uid: int, domain: str):
        await self._exec("DELETE FROM brand_watch WHERE user_id=? AND domain=?", (uid, domain))

    async def all_brands(self) -> list[dict]:
        rows = await self._all("SELECT b.* FROM brand_watch b JOIN users u ON u.id=b.user_id "
                               "WHERE u.status='active'")
        return [{**dict(r), "known": json.loads(r["known"])} for r in rows]

    # ── Correos ─────────────────────────────────────────────────────────
    async def set_email_code(self, uid: int, email: str, code: str, ttl: int = 900):
        await self._exec(
            "INSERT INTO emails(user_id,email,code,code_expires) VALUES(?,?,?,?) "
            "ON CONFLICT(user_id,email) DO UPDATE SET code=excluded.code, code_expires=excluded.code_expires",
            (uid, email, code, int(time.time()) + ttl))

    async def verify_email_code(self, uid: int, code: str) -> str | None:
        row = await self._one("SELECT email FROM emails WHERE user_id=? AND code=? AND code_expires>?",
                              (uid, code, int(time.time())))
        if not row:
            return None
        await self._exec("UPDATE emails SET verified=1, code=NULL WHERE user_id=? AND email=?", (uid, row["email"]))
        return row["email"]

    async def mark_verified(self, uid: int, email: str):
        await self._exec("INSERT INTO emails(user_id,email,verified) VALUES(?,?,1) "
                         "ON CONFLICT(user_id,email) DO UPDATE SET verified=1", (uid, email))

    async def verified_emails(self, uid: int) -> list[str]:
        return [r["email"] for r in await self._all("SELECT email FROM emails WHERE user_id=? AND verified=1 ORDER BY email", (uid,))]

    async def del_email(self, uid: int, email: str):
        await self._exec("DELETE FROM emails WHERE user_id=? AND email=?", (uid, email))

    async def set_known_breaches(self, uid: int, email: str, names: list[str]):
        await self._exec("UPDATE emails SET known_breaches=? WHERE user_id=? AND email=?",
                         (json.dumps(names), uid, email))

    async def all_verified_emails(self) -> list[dict]:
        rows = await self._all("SELECT e.* FROM emails e JOIN users u ON u.id=e.user_id "
                               "WHERE e.verified=1 AND u.status='active'")
        return [{**dict(r), "known_breaches": json.loads(r["known_breaches"])} for r in rows]

    # ── Recordatorios ───────────────────────────────────────────────────
    async def add_reminder(self, uid: int, text: str, due_ts: int) -> int:
        cur = await self.conn.execute("INSERT INTO reminders(user_id,text,due_ts) VALUES(?,?,?)",
                                      (uid, text, due_ts))
        await self.conn.commit()
        return cur.lastrowid

    async def reminders(self, uid: int) -> list[dict]:
        rows = await self._all("SELECT * FROM reminders WHERE user_id=? AND done=0 ORDER BY due_ts", (uid,))
        return [dict(r) for r in rows]

    async def del_reminder(self, uid: int, rid: int):
        await self._exec("DELETE FROM reminders WHERE id=? AND user_id=?", (rid, uid))

    async def due_reminders(self, now_ts: int) -> list[dict]:
        rows = await self._all("SELECT * FROM reminders WHERE done=0 AND due_ts<=?", (now_ts,))
        return [dict(r) for r in rows]

    async def mark_reminder_done(self, rid: int):
        await self._exec("UPDATE reminders SET done=1 WHERE id=?", (rid,))

    # ── Notas ───────────────────────────────────────────────────────────
    async def add_note(self, uid: int, text: str) -> int:
        cur = await self.conn.execute("INSERT INTO notes(user_id,text,created) VALUES(?,?,?)",
                                      (uid, text, int(time.time())))
        await self.conn.commit()
        return cur.lastrowid

    async def notes(self, uid: int, query: str | None = None) -> list[dict]:
        if query:
            rows = await self._all("SELECT * FROM notes WHERE user_id=? AND text LIKE ? ORDER BY created DESC",
                                   (uid, f"%{query}%"))
        else:
            rows = await self._all("SELECT * FROM notes WHERE user_id=? ORDER BY created DESC", (uid,))
        return [dict(r) for r in rows]

    async def del_note(self, uid: int, nid: int):
        await self._exec("DELETE FROM notes WHERE id=? AND user_id=?", (nid, uid))

    # ── Enlaces cortos ──────────────────────────────────────────────────
    async def add_short(self, code: str, uid: int, url: str):
        await self._exec("INSERT INTO short_links(code,user_id,url,created) VALUES(?,?,?,?)",
                         (code, uid, url, int(time.time())))

    async def get_short(self, code: str) -> dict | None:
        row = await self._one("SELECT * FROM short_links WHERE code=?", (code,))
        return dict(row) if row else None

    async def bump_short(self, code: str):
        await self._exec("UPDATE short_links SET clicks=clicks+1 WHERE code=?", (code,))

    async def shorts(self, uid: int) -> list[dict]:
        rows = await self._all("SELECT * FROM short_links WHERE user_id=? ORDER BY created DESC LIMIT 20", (uid,))
        return [dict(r) for r in rows]

    async def del_short(self, uid: int, code: str):
        await self._exec("DELETE FROM short_links WHERE code=? AND user_id=?", (code, uid))

    # ── Encuestas ───────────────────────────────────────────────────────
    async def add_poll(self, pid: str, owner: int, question: str, options: list[str]):
        await self._exec("INSERT INTO polls(id,owner,question,options,created) VALUES(?,?,?,?,?)",
                         (pid, owner, question, json.dumps(options), int(time.time())))

    async def get_poll(self, pid: str) -> dict | None:
        row = await self._one("SELECT * FROM polls WHERE id=?", (pid,))
        if not row:
            return None
        d = dict(row)
        d["options"] = json.loads(d["options"])
        return d

    async def vote(self, pid: str, uid: int, choice: int):
        await self._exec("INSERT INTO poll_votes(poll_id,user_id,choice) VALUES(?,?,?) "
                         "ON CONFLICT(poll_id,user_id) DO UPDATE SET choice=excluded.choice",
                         (pid, uid, choice))

    async def poll_counts(self, pid: str) -> dict[int, int]:
        rows = await self._all("SELECT choice, COUNT(*) c FROM poll_votes WHERE poll_id=? GROUP BY choice", (pid,))
        return {r["choice"]: r["c"] for r in rows}


db = DB(settings.db_path)
