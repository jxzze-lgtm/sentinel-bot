"""Teclados en línea. Diseño: 2 columnas, emoji + texto corto, navegación ‹ Volver."""
from aiogram.types import InlineKeyboardButton as B
from aiogram.types import InlineKeyboardMarkup


def kb(*rows: list[tuple[str, str]]) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[B(text=t, callback_data=d) for t, d in row] for row in rows])


BACK_MAIN = ("‹ Menú", "nav:main")


def main_menu(is_admin: bool) -> InlineKeyboardMarkup:
    rows = [
        [("🌐 Infraestructura", "nav:infra"), ("🛡 Amenazas", "nav:threats")],
        [("🛰 Vigilancia", "nav:watch"), ("🔐 Privacidad", "nav:privacy")],
        [("🗄 Evidencia", "nav:evidence"), ("ℹ️ Ayuda", "nav:help")],
    ]
    if is_admin:
        rows.append([("⚙️ Panel de administración", "adm:home")])
    return kb(*rows)


SECTION_KB = {
    "infra": kb([("🌐 Dominio", "tool:domain"), ("📍 IP", "tool:ip")], [BACK_MAIN]),
    "threats": kb([("🔗 Enlace", "tool:url"), ("📄 Archivo", "tool:file")],
                  [("✉️ Correo phishing", "tool:mail")], [BACK_MAIN]),
    "watch": kb([("🔎 Buscar CVE", "tool:cve"), ("🛰 Alertas CVE", "tool:cvesubs")],
                [("🛡 Monitoreo de marca", "tool:brand")], [BACK_MAIN]),
    "privacy": kb([("🔐 Filtraciones", "tool:breach"), ("🧹 Metadatos", "tool:meta")], [BACK_MAIN]),
    "evidence": kb([("🗄 Archivar página", "tool:archive")], [BACK_MAIN]),
}

TOOL_SECTION = {"domain": "infra", "ip": "infra", "url": "threats", "file": "threats", "mail": "threats",
                "cve": "watch", "cvesubs": "watch", "brand": "watch", "breach": "privacy", "meta": "privacy",
                "archive": "evidence"}

CANCEL = kb([("✕ Cancelar", "cancel")])
HELP_KB = kb([BACK_MAIN])


def after_result(tool: str) -> InlineKeyboardMarkup:
    return kb([("↻ Otra consulta", f"tool:{tool}"), BACK_MAIN])


def doc_choice() -> InlineKeyboardMarkup:
    return kb([("📄 Revisar amenaza", "doc:scan"), ("🧹 Limpiar metadatos", "doc:meta")], [("✕ Cancelar", "cancel")])


def vt_upload() -> InlineKeyboardMarkup:
    return kb([("⬆️ Subir a VirusTotal", "doc:vt")], [("↻ Otro archivo", "tool:file"), BACK_MAIN])


def list_manager(items: list[str], prefix: str, add_label: str, back: str,
                 action: tuple[str, str] | None = None) -> InlineKeyboardMarkup:
    """Lista administrable. Usa índices en callback_data (límite de 64 bytes de Telegram).

    action=("🔍", "scan") añade un botón principal por elemento además del 🗑.
    """
    rows = []
    for i, it in enumerate(items[:10]):
        label = it if len(it) <= 28 else it[:27] + "…"
        if action:
            rows.append([(f"{action[0]} {label}", f"{prefix}:{action[1]}:{i}"), ("🗑", f"{prefix}:del:{i}")])
        else:
            rows.append([(f"🗑 {label}", f"{prefix}:del:{i}")])
    rows.append([(add_label, f"{prefix}:add")])
    rows.append([("‹ Volver", f"nav:{back}"), BACK_MAIN])
    return kb(*rows)


# ── Administración ──────────────────────────────────────────────────────
def admin_home(pending: int, mode: str) -> InlineKeyboardMarkup:
    mode_label = "🔓 Acceso: abierto" if mode == "open" else "🔐 Acceso: con aprobación"
    return kb(
        [("📊 Estadísticas", "adm:stats"), (f"⏳ Pendientes · {pending}", "adm:list:pending:0")],
        [("👥 Usuarios", "adm:list:all:0"), ("⛔️ Bloqueados", "adm:list:blocked:0")],
        [("📣 Difusión", "adm:bcast"), (mode_label, "adm:mode")],
        [BACK_MAIN],
    )


def admin_list(users: list[dict], status: str, page: int, has_next: bool) -> InlineKeyboardMarkup:
    icon = {"active": "🟢", "pending": "⏳", "blocked": "⛔️"}
    rows = []
    for u in users:
        name = (u["full_name"] or "Sin nombre")[:22]
        rows.append([(f"{icon.get(u['status'], '•')} {name}", f"adm:user:{u['id']}")])
    nav = []
    if page > 0:
        nav.append(("‹ Anterior", f"adm:list:{status}:{page - 1}"))
    if has_next:
        nav.append(("Siguiente ›", f"adm:list:{status}:{page + 1}"))
    if nav:
        rows.append(nav)
    rows.append([("‹ Panel", "adm:home")])
    return kb(*rows)


def admin_user(uid: int, status: str) -> InlineKeyboardMarkup:
    actions = []
    if status != "active":
        actions.append(("✅ Activar", f"adm:set:{uid}:active"))
    if status != "blocked":
        actions.append(("⛔️ Bloquear", f"adm:set:{uid}:blocked"))
    if status == "active":
        actions.append(("⏸ Suspender", f"adm:set:{uid}:pending"))
    return kb(actions, [("‹ Usuarios", "adm:list:all:0"), ("‹ Panel", "adm:home")])


def new_user_alert(uid: int) -> InlineKeyboardMarkup:
    return kb([("✅ Aprobar", f"adm:set:{uid}:active"), ("⛔️ Bloquear", f"adm:set:{uid}:blocked")],
              [("👤 Ver ficha", f"adm:user:{uid}")])


def broadcast_confirm() -> InlineKeyboardMarkup:
    return kb([("📣 Enviar a todos", "adm:bcast_ok"), ("✕ Cancelar", "adm:home")])
