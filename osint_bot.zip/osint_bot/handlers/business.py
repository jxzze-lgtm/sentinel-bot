"""Sección 💼 Negocio: recibos/cotizaciones, QR de Wi-Fi/contacto/pago y encuestas."""
import asyncio
import re
import secrets

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import BufferedInputFile, CallbackQuery, Message

import keyboards as K
import texts as T
from database import db
from handlers.base import allowed
from services import business, convert
from states import Biz, Poll
from utils import esc

router = Router(name="business")
BACK = [("‹ Negocio", "nav:business"), ("‹ Menú", "nav:main")]

OPEN = {"biz_receipt": Biz.receipt, "biz_quote": Biz.quote, "biz_vcard": Biz.vcard,
        "biz_payment": Biz.payment}


@router.callback_query(F.data.startswith("tool:"),
                       F.data.func(lambda d: d.split(":", 1)[1] in {*OPEN, "biz_wifi", "poll"}))
async def open_biz(cb: CallbackQuery, state: FSMContext):
    name = cb.data.split(":", 1)[1]
    await cb.answer()
    await state.clear()
    if name == "biz_wifi":
        await state.set_state(Biz.wifi)
        await state.update_data(step="auth")
        return await cb.message.answer(T.PROMPTS["biz_wifi"], reply_markup=K.wifi_auth())
    if name == "poll":
        await state.set_state(Poll.create)
        return await cb.message.answer(T.PROMPTS["poll"], reply_markup=K.CANCEL)
    await state.set_state(OPEN[name])
    await cb.message.answer(T.PROMPTS[name], reply_markup=K.CANCEL)


# ── 🧾 Recibo / 📋 Cotización ─────────────────────────────────────────────
@router.message(Biz.receipt, F.text)
async def receipt(message: Message, state: FSMContext):
    await _document(message, state, "recibo", "biz_receipt")


@router.message(Biz.quote, F.text)
async def quote(message: Message, state: FSMContext):
    await _document(message, state, "cotizacion", "biz_quote")


async def _document(message: Message, state: FSMContext, kind: str, tool: str):
    await state.clear()
    if not await allowed(message, tool, message.from_user.id):
        return
    data = business.parse_document(message.text)
    if not data["items"]:
        return await message.answer("⚠️ No encontré conceptos. Cada línea debe ser: "
                                    "<code>descripción | cantidad | precio</code>.", reply_markup=K.CANCEL)
    try:
        pdf = await asyncio.to_thread(business.make_document, data, kind)
    except Exception as e:  # noqa: BLE001
        return await message.answer(f"⚠️ No se pudo generar ({esc(type(e).__name__)}).",
                                    reply_markup=K.kb(BACK))
    fname = f"{'recibo' if kind == 'recibo' else 'cotizacion'}.pdf"
    await message.answer_document(BufferedInputFile(pdf, fname), caption="✅ Listo", reply_markup=K.kb(BACK))


# ── 📶 QR Wi-Fi ───────────────────────────────────────────────────────────
@router.callback_query(F.data.startswith("wifi:"))
async def wifi_auth(cb: CallbackQuery, state: FSMContext):
    auth = cb.data.split(":", 1)[1]
    await cb.answer()
    await state.update_data(auth=auth)
    if auth == "nopass":
        await state.update_data(step="ssid_only")
        await cb.message.answer("📶 Escribe el <b>nombre</b> de la red (SSID).", reply_markup=K.CANCEL)
    else:
        await state.update_data(step="ssid")
        await cb.message.answer("📶 Escribe el <b>nombre</b> de la red (SSID).", reply_markup=K.CANCEL)


@router.message(Biz.wifi, F.text)
async def wifi_text(message: Message, state: FSMContext):
    data = await state.get_data()
    step = data.get("step")
    if step in ("ssid", "ssid_only"):
        await state.update_data(ssid=message.text.strip())
        if step == "ssid_only":
            return await _make_wifi(message, state, message.text.strip(), "", "nopass")
        await state.update_data(step="pwd")
        return await message.answer("🔑 Ahora escribe la <b>contraseña</b> de la red.", reply_markup=K.CANCEL)
    if step == "pwd":
        await _make_wifi(message, state, data["ssid"], message.text, data.get("auth", "WPA"))


async def _make_wifi(message: Message, state: FSMContext, ssid: str, pwd: str, auth: str):
    await state.clear()
    if not await allowed(message, "biz_wifi", message.from_user.id):
        return
    payload = business.qr_wifi(ssid, pwd, auth)
    png = await asyncio.to_thread(convert.make_qr, payload)
    await message.answer_document(BufferedInputFile(png, "qr_wifi.png"),
                                  caption=f"✅ QR de Wi-Fi para <b>{esc(ssid)}</b>\n"
                                          "<i>Al escanearlo, el teléfono se conecta solo.</i>",
                                  reply_markup=K.kb(BACK))


# ── 👤 QR vCard ───────────────────────────────────────────────────────────
@router.message(Biz.vcard, F.text)
async def vcard(message: Message, state: FSMContext):
    await state.clear()
    if not await allowed(message, "biz_vcard", message.from_user.id):
        return
    fields = {}
    for line in message.text.splitlines():
        if ":" in line:
            k, _, v = line.partition(":")
            fields[k.strip().lower()] = v.strip()
    nombre = fields.get("nombre") or fields.get("name")
    if not nombre:
        return await message.answer("⚠️ Falta el nombre. Incluye una línea <code>Nombre: ...</code>.",
                                    reply_markup=K.CANCEL)
    payload = business.qr_vcard(nombre, fields.get("tel", ""), fields.get("email", ""),
                                fields.get("empresa", ""), fields.get("web", fields.get("url", "")))
    png = await asyncio.to_thread(convert.make_qr, payload)
    await message.answer_document(BufferedInputFile(png, "qr_contacto.png"),
                                  caption=f"✅ QR de contacto de <b>{esc(nombre)}</b>\n"
                                          "<i>Al escanearlo se guarda en los contactos.</i>",
                                  reply_markup=K.kb(BACK))


# ── 💳 QR de pago ─────────────────────────────────────────────────────────
@router.message(Biz.payment, F.text)
async def payment(message: Message, state: FSMContext):
    await state.clear()
    if not await allowed(message, "biz_payment", message.from_user.id):
        return
    url = message.text.strip()
    if not re.match(r"^https?://", url, re.I):
        return await message.answer("⚠️ Pega un enlace que empiece con http:// o https://", reply_markup=K.CANCEL)
    png = await asyncio.to_thread(convert.make_qr, url)
    await message.answer_document(BufferedInputFile(png, "qr_pago.png"),
                                  caption="✅ QR de pago · tus clientes lo escanean para pagar",
                                  reply_markup=K.kb(BACK))


# ── 📊 Encuesta ───────────────────────────────────────────────────────────
@router.message(Poll.create, F.text)
async def poll_create(message: Message, state: FSMContext):
    await state.clear()
    lines = [l.strip() for l in message.text.splitlines() if l.strip()]
    if len(lines) < 3:
        return await message.answer("⚠️ Necesito la pregunta y al menos 2 opciones, una por línea.",
                                    reply_markup=K.CANCEL)
    question, options = lines[0], lines[1:11]
    if not await allowed(message, "poll", message.from_user.id):
        return
    pid = secrets.token_urlsafe(6)
    await db.add_poll(pid, message.from_user.id, question, options)
    text = f"📊 <b>{esc(question)}</b>\n\n<i>Toca para votar. Puedes reenviar esta encuesta.</i>"
    await message.answer(text, reply_markup=K.poll_kb(pid, options, {}, 0))
    await message.answer("✅ Encuesta creada. Reenvía el mensaje de arriba a tu grupo o contactos.",
                         reply_markup=K.kb(BACK))


@router.callback_query(F.data.startswith("vote:"))
async def vote(cb: CallbackQuery):
    _, pid, choice = cb.data.split(":")
    poll = await db.get_poll(pid)
    if not poll:
        return await cb.answer("Esta encuesta ya no existe.", show_alert=True)
    if choice != "r":
        await db.vote(pid, cb.from_user.id, int(choice))
        await cb.answer("✅ Tu voto quedó registrado")
    else:
        await cb.answer("Actualizado")
    counts = await db.poll_counts(pid)
    total = sum(counts.values())
    text = f"📊 <b>{esc(poll['question'])}</b>\n\n<i>{total} voto(s). Toca para votar o cambiar tu voto.</i>"
    try:
        await cb.message.edit_text(text, reply_markup=K.poll_kb(pid, poll["options"], counts, total))
    except Exception:
        pass
