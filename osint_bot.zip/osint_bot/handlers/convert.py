"""Sección 🧰 Utilidades: conversión de archivos, QR y decodificador."""
import asyncio
import io
import zipfile

from aiogram import Bot, F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import BufferedInputFile, CallbackQuery, Message

import keyboards as K
import texts as T
from config import settings
from database import db
from services import convert
from states import Convert
from ui import finish, loading
from utils import RateLimiter, esc, human_size

router = Router(name="convert")
limiter = RateLimiter(settings.rate_limit_per_minute)

MAX_COLLECT = 20
PROMPT_STATE = {
    "office_pdf": Convert.office_pdf, "img_pdf": Convert.img_pdf, "pdf_img": Convert.pdf_img,
    "img_format": Convert.img_format, "merge": Convert.merge, "split": Convert.split,
    "compress": Convert.compress, "qr": Convert.qr, "decode": Convert.decode,
}


async def allowed(message: Message, tool: str, uid: int) -> bool:
    if not limiter.allow(uid):
        await message.answer(T.RATE_LIMITED)
        return False
    await db.log_usage(uid, tool)
    return True


async def grab(bot: Bot, message: Message) -> tuple[str, bytes] | None:
    doc = message.document
    if doc:
        if (doc.file_size or 0) > settings.max_file_mb * 1024 * 1024:
            await message.answer(f"⚠️ El archivo supera {settings.max_file_mb} MB.")
            return None
        buf = await bot.download(doc)
        return doc.file_name or "archivo", buf.read()
    if message.photo:
        buf = await bot.download(message.photo[-1])
        return "foto.jpg", buf.read()
    return None


@router.callback_query(F.data.startswith("tool:"), F.data.func(lambda d: d.split(":", 1)[1] in PROMPT_STATE))
async def open_util(cb: CallbackQuery, state: FSMContext):
    name = cb.data.split(":", 1)[1]
    await cb.answer()
    await state.clear()
    await state.set_state(PROMPT_STATE[name])
    kb = K.CANCEL
    if name in ("img_pdf", "merge"):
        await state.update_data(items=[])
        kb = K.collect(0)
    await cb.message.answer(T.PROMPTS[name], reply_markup=kb)


# ══ 📄 Office → PDF ══════════════════════════════════════════════════════
@router.message(Convert.office_pdf, F.document)
async def office_pdf(message: Message, bot: Bot, state: FSMContext):
    got = await grab(bot, message)
    if not got:
        return
    name, data = got
    ext = name.rsplit(".", 1)[-1].lower() if "." in name else ""
    if ext not in convert.OFFICE_EXT:
        return await message.answer("⚠️ Envía un documento de Office (Word, Excel, PowerPoint, ODT, RTF, TXT).",
                                    reply_markup=K.CANCEL)
    await state.clear()
    if not await allowed(message, "office_pdf", message.from_user.id):
        return
    if not convert.libreoffice_available():
        return await message.answer("⚠️ LibreOffice no está instalado en el servidor. "
                                    "Instálalo con:\n<code>sudo apt install -y libreoffice</code>",
                                    reply_markup=K.after_result("office_pdf", "utils"))
    status = await loading(message, "Convirtiendo a PDF")
    try:
        pdf = await convert.office_to_pdf_async(name, data)
    except Exception as e:  # noqa: BLE001
        return await finish(status, f"⚠️ No se pudo convertir ({esc(type(e).__name__)}).",
                            K.after_result("office_pdf", "utils"))
    out_name = (name.rsplit(".", 1)[0] if "." in name else name) + ".pdf"
    await status.delete()
    await message.answer_document(BufferedInputFile(pdf, out_name), caption="✅ PDF listo",
                                  reply_markup=K.after_result("office_pdf", "utils"))


# ══ 🖼 Imágenes → PDF  y  🔀 Unir PDF (flujos que acumulan archivos) ══════
@router.message(Convert.img_pdf, F.photo | F.document)
async def collect_img(message: Message, bot: Bot, state: FSMContext):
    await _collect(message, bot, state, kind="img")


@router.message(Convert.merge, F.document)
async def collect_pdf(message: Message, bot: Bot, state: FSMContext):
    await _collect(message, bot, state, kind="pdf")


async def _collect(message: Message, bot: Bot, state: FSMContext, kind: str):
    data = await state.get_data()
    items = data.get("items", [])
    if len(items) >= MAX_COLLECT:
        return await message.answer(f"⚠️ Máximo {MAX_COLLECT} archivos. Toca Generar.",
                                    reply_markup=K.collect(len(items)))
    if kind == "pdf":
        doc = message.document
        if not doc or not (doc.file_name or "").lower().endswith(".pdf"):
            return await message.answer("⚠️ Envía archivos PDF.", reply_markup=K.collect(len(items)))
        fid = doc.file_id
    else:
        if message.document:
            doc = message.document
            if not (doc.mime_type or "").startswith("image/"):
                return await message.answer("⚠️ Envía imágenes.", reply_markup=K.collect(len(items)))
            fid = doc.file_id
        else:
            fid = message.photo[-1].file_id
    items.append(fid)
    await state.update_data(items=items)
    await message.answer(f"➕ Recibido ({len(items)}). Envía más o toca Generar.",
                         reply_markup=K.collect(len(items)))


@router.callback_query(F.data == "conv:done")
async def collect_done(cb: CallbackQuery, bot: Bot, state: FSMContext):
    current = await state.get_state()
    data = await state.get_data()
    items = data.get("items", [])
    await cb.answer()
    if not items:
        return await cb.message.answer("No recibí archivos.", reply_markup=K.CANCEL)
    await state.clear()
    is_img = current == Convert.img_pdf.state
    tool = "img_pdf" if is_img else "merge"
    if not await allowed(cb.message, tool, cb.from_user.id):
        return
    status = await loading(cb.message, "Generando")
    try:
        blobs = []
        for fid in items:
            buf = await bot.download(fid)
            blobs.append(buf.read())
        if is_img:
            out = await asyncio.to_thread(convert.images_to_pdf, blobs)
            name = "imagenes.pdf"
        else:
            out = await asyncio.to_thread(convert.merge_pdfs, blobs)
            name = "unido.pdf"
    except Exception as e:  # noqa: BLE001
        return await finish(status, f"⚠️ No se pudo generar ({esc(type(e).__name__)}).",
                            K.after_result(tool, "utils"))
    await status.delete()
    await cb.message.answer_document(BufferedInputFile(out, name),
                                     caption=f"✅ Listo · {human_size(len(out))}",
                                     reply_markup=K.after_result(tool, "utils"))


# ══ 📑 PDF → imágenes  y  ✂️ Dividir PDF ═════════════════════════════════
@router.message(Convert.pdf_img, F.document)
async def pdf_to_img(message: Message, bot: Bot, state: FSMContext):
    await _pdf_output(message, bot, state, mode="render")


@router.message(Convert.split, F.document)
async def pdf_split(message: Message, bot: Bot, state: FSMContext):
    await _pdf_output(message, bot, state, mode="split")


async def _pdf_output(message: Message, bot: Bot, state: FSMContext, mode: str):
    got = await grab(bot, message)
    if not got:
        return
    name, data = got
    if not data.startswith(b"%PDF"):
        return await message.answer("⚠️ Envía un archivo PDF.", reply_markup=K.CANCEL)
    await state.clear()
    tool = "pdf_img" if mode == "render" else "split"
    if not await allowed(message, tool, message.from_user.id):
        return
    status = await loading(message, "Procesando el PDF")
    try:
        if mode == "render":
            images, total = await asyncio.to_thread(convert.pdf_to_images, data)
            zip_bytes = _zip([(f"pagina_{i:02d}.png", b) for i, b in enumerate(images, 1)])
            note = f"✅ {len(images)} de {total} páginas" + (" (máx. 30)" if total > len(images) else "")
            out_name = "paginas_png.zip"
        else:
            files = await asyncio.to_thread(convert.split_pdf, data)
            zip_bytes = _zip(files)
            note = f"✅ {len(files)} páginas separadas"
            out_name = "paginas_pdf.zip"
    except Exception as e:  # noqa: BLE001
        return await finish(status, f"⚠️ No se pudo procesar ({esc(type(e).__name__)}).",
                            K.after_result(tool, "utils"))
    await status.delete()
    await message.answer_document(BufferedInputFile(zip_bytes, out_name), caption=note,
                                  reply_markup=K.after_result(tool, "utils"))


def _zip(files: list[tuple[str, bytes]]) -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for fname, fdata in files:
            z.writestr(fname, fdata)
    return buf.getvalue()


# ══ 🔄 Convertir imagen (elige formato) ══════════════════════════════════
@router.message(Convert.img_format, F.document | F.photo)
async def img_format_receive(message: Message, bot: Bot, state: FSMContext):
    got = await grab(bot, message)
    if not got:
        return
    name, data = got
    try:
        convert._open_image(data)
    except Exception:
        return await message.answer("⚠️ No parece una imagen válida. Envíala como archivo.", reply_markup=K.CANCEL)
    await state.update_data(img=message.document.file_id if message.document else message.photo[-1].file_id,
                            img_name=name)
    await message.answer("¿A qué formato lo convierto?", reply_markup=K.img_format_choice())


@router.callback_query(F.data.startswith("fmt:"))
async def img_format_do(cb: CallbackQuery, bot: Bot, state: FSMContext):
    target = cb.data.split(":", 1)[1]
    data = await state.get_data()
    if "img" not in data:
        return await cb.answer("Envía la imagen de nuevo.", show_alert=True)
    await cb.answer()
    await state.clear()
    if not await allowed(cb.message, "img_format", cb.from_user.id):
        return
    buf = await bot.download(data["img"])
    raw = buf.read()
    base = data["img_name"].rsplit(".", 1)[0] if "." in data["img_name"] else data["img_name"]
    status = await loading(cb.message, "Convirtiendo")
    try:
        if target == "pdf":
            out = await asyncio.to_thread(convert.images_to_pdf, [raw])
            out_name = base + ".pdf"
        else:
            out = await asyncio.to_thread(convert.image_convert, raw, target)
            out_name = f"{base}.{target}"
    except Exception as e:  # noqa: BLE001
        return await finish(status, f"⚠️ No se pudo convertir ({esc(type(e).__name__)}).",
                            K.after_result("img_format", "utils"))
    await status.delete()
    await cb.message.answer_document(BufferedInputFile(out, out_name), caption="✅ Listo",
                                     reply_markup=K.after_result("img_format", "utils"))


# ══ 🗜 Comprimir imagen ══════════════════════════════════════════════════
@router.message(Convert.compress, F.document | F.photo)
async def compress(message: Message, bot: Bot, state: FSMContext):
    got = await grab(bot, message)
    if not got:
        return
    name, data = got
    await state.clear()
    if not await allowed(message, "compress", message.from_user.id):
        return
    status = await loading(message, "Comprimiendo")
    try:
        out = await asyncio.to_thread(convert.compress_image, data)
    except Exception as e:  # noqa: BLE001
        return await finish(status, f"⚠️ No se pudo comprimir ({esc(type(e).__name__)}).",
                            K.after_result("compress", "utils"))
    base = name.rsplit(".", 1)[0] if "." in name else name
    if len(out) >= len(data):
        caption = (f"ℹ️ Esta imagen ya estaba optimizada ({human_size(len(data))}); "
                   "comprimirla no la hace más pequeña.")
    else:
        saved = 100 - round(len(out) / len(data) * 100)
        caption = f"✅ {human_size(len(data))} → {human_size(len(out))} ({saved}% menos)"
    await status.delete()
    await message.answer_document(BufferedInputFile(out, f"{base}_comprimida.jpg"), caption=caption,
                                  reply_markup=K.after_result("compress", "utils"))


# ══ 🔳 Generar QR ════════════════════════════════════════════════════════
@router.message(Convert.qr, F.text)
async def qr(message: Message, state: FSMContext):
    text = message.text.strip()
    if len(text) > 1000:
        return await message.answer("⚠️ El texto es demasiado largo para un QR (máx. 1000).", reply_markup=K.CANCEL)
    await state.clear()
    if not await allowed(message, "qr", message.from_user.id):
        return
    try:
        png = await asyncio.to_thread(convert.make_qr, text)
    except Exception as e:  # noqa: BLE001
        return await message.answer(f"⚠️ No se pudo generar ({esc(type(e).__name__)}).",
                                    reply_markup=K.after_result("qr", "utils"))
    await message.answer_photo(BufferedInputFile(png, "qr.png"), caption="✅ Tu código QR",
                               reply_markup=K.after_result("qr", "utils"))


# ══ 🧰 Decodificador ═════════════════════════════════════════════════════
@router.message(Convert.decode, F.text)
async def decode(message: Message, state: FSMContext):
    await state.clear()
    if not await allowed(message, "decode", message.from_user.id):
        return
    result = await asyncio.to_thread(convert.smart_decode, message.text)
    await finish(await loading(message, "Decodificando"), result, K.after_result("decode", "utils"))


# ══ Si en un flujo de archivo mandan texto (o viceversa) ═════════════════
@router.message(Convert.office_pdf)
@router.message(Convert.pdf_img)
@router.message(Convert.split)
@router.message(Convert.compress)
@router.message(Convert.img_format)
async def expect_file(message: Message):
    await message.answer("📎 Envíame el archivo como archivo (📎 → Archivo), o toca Cancelar.",
                         reply_markup=K.CANCEL)
