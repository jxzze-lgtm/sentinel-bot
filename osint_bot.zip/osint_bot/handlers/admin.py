"""Panel de administración: estadísticas, usuarios, aprobaciones, difusión y modo de acceso."""
import asyncio
from datetime import datetime

from aiogram import Bot, F, Router
from aiogram.exceptions import TelegramForbiddenError, TelegramRetryAfter
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

import keyboards as K
import texts as T
from config import settings
from database import db
from states import Admin
from ui import send_screen, show_screen
from utils import DIV, code, esc

router = Router(name="admin")
router.message.filter(F.from_user.id.in_(settings.admin_ids))
router.callback_query.filter(F.from_user.id.in_(settings.admin_ids))

PAGE = 8
STATUS_LABEL = {"active": "🟢 Activo", "pending": "⏳ Pendiente", "blocked": "⛔️ Bloqueado"}


def _date(ts: int) -> str:
    return datetime.fromtimestamp(ts).strftime("%Y-%m-%d %H:%M")


async def home_caption() -> tuple[str, int, str]:
    s = await db.stats()
    mode = await db.access_mode()
    caption = (f"⚙️ <b>Panel de administración</b>\n{DIV}\n"
               f"├ Usuarios · {code(s['total'])}\n"
               f"├ Activos · {code(s['active'])}\n"
               f"├ Pendientes · {code(s['pending'])}\n"
               f"├ Nuevos 24 h · {code(s['new_24h'])}\n"
               f"└ Consultas 24 h · {code(s['queries_24h'])}")
    return caption, s["pending"], mode


@router.message(Command("admin"))
async def admin_cmd(message: Message, state: FSMContext):
    await state.clear()
    caption, pending, mode = await home_caption()
    await send_screen(message.bot, message.chat.id, "admin.png", caption, K.admin_home(pending, mode))


@router.callback_query(F.data == "adm:home")
async def admin_home(cb: CallbackQuery, state: FSMContext):
    await state.clear()
    await cb.answer()
    caption, pending, mode = await home_caption()
    await show_screen(cb, "admin.png", caption, K.admin_home(pending, mode))


@router.callback_query(F.data == "adm:stats")
async def admin_stats(cb: CallbackQuery):
    await cb.answer()
    s = await db.stats()
    tools = "\n".join(f"├ {esc(t)} · {code(c)}" for t, c in s["tools_7d"][:-1])
    if s["tools_7d"]:
        t, c = s["tools_7d"][-1]
        tools += f"\n└ {esc(t)} · {code(c)}"
    text = (f"📊 <b>Estadísticas</b>\n{DIV}\n"
            f"<b>Usuarios</b>\n"
            f"├ Total · {code(s['total'])}\n"
            f"├ Activos · {code(s['active'])}\n"
            f"├ Pendientes · {code(s['pending'])}\n"
            f"├ Bloqueados · {code(s['blocked'])}\n"
            f"└ Vistos en 24 h · {code(s['seen_24h'])}\n\n"
            f"<b>Herramientas más usadas · 7 días</b>\n{tools.strip() or '└ sin uso aún'}")
    await show_screen(cb, "admin.png", text, K.kb([("‹ Panel", "adm:home")]))


@router.callback_query(F.data.startswith("adm:list:"))
async def admin_list(cb: CallbackQuery):
    _, _, status, page = cb.data.split(":")
    page = int(page)
    filt = None if status == "all" else status
    users = await db.list_users(filt, page * PAGE, PAGE + 1)
    has_next = len(users) > PAGE
    users = users[:PAGE]
    total = await db.count_users(filt)
    title = {"all": "👥 Usuarios", "pending": "⏳ Pendientes", "blocked": "⛔️ Bloqueados",
             "active": "🟢 Activos"}.get(status, "Usuarios")
    caption = f"{title} · {total}\n{DIV}\n" + ("Toca un usuario para ver su ficha." if users else "No hay nadie aquí.")
    await cb.answer()
    await show_screen(cb, "admin.png", caption, K.admin_list(users, status, page, has_next))


@router.callback_query(F.data.startswith("adm:user:"))
async def admin_user(cb: CallbackQuery):
    await cb.answer()
    await render_user(cb, int(cb.data.split(":")[2]))


async def render_user(cb: CallbackQuery, uid: int):
    u = await db.get_user(uid)
    if not u:
        return await cb.message.answer("Usuario no encontrado.")
    uname = f"@{u['username']}" if u["username"] else "—"
    caption = (f"👤 <b>{esc(u['full_name'] or 'Sin nombre')}</b>\n{DIV}\n"
               f"├ Usuario · {esc(uname)}\n"
               f"├ ID · {code(u['id'])}\n"
               f"├ Estado · {STATUS_LABEL.get(u['status'], u['status'])}\n"
               f"├ Alta · {code(_date(u['joined_at']))}\n"
               f"├ Última actividad · {code(_date(u['last_seen']))}\n"
               f"└ Consultas · {code(u['queries'])}")
    await show_screen(cb, "admin.png", caption, K.admin_user(uid, u["status"]))


@router.callback_query(F.data.startswith("adm:set:"))
async def admin_set(cb: CallbackQuery, bot: Bot):
    _, _, uid, status = cb.data.split(":")
    uid = int(uid)
    if uid in settings.admin_ids:
        return await cb.answer("No puedes cambiar el estado de un administrador.", show_alert=True)
    before = await db.get_user(uid)
    await db.set_status(uid, status)
    await cb.answer(STATUS_LABEL.get(status, status))
    if status == "active" and before and before["status"] != "active":
        try:
            await bot.send_message(uid, T.APPROVED)
        except Exception:
            pass
    elif status == "blocked":
        try:
            await bot.send_message(uid, T.BLOCKED)
        except Exception:
            pass
    # Si vino de la alerta de "nuevo usuario" (mensaje de texto), actualiza ese mensaje
    if cb.message and not getattr(cb.message, "photo", None):
        try:
            await cb.message.edit_text(cb.message.html_text + f"\n\n<b>→ {STATUS_LABEL.get(status)}</b>",
                                       reply_markup=None)
        except Exception:
            pass
        return
    await render_user(cb, uid)


@router.callback_query(F.data == "adm:mode")
async def admin_mode(cb: CallbackQuery):
    mode = "approval" if await db.access_mode() == "open" else "open"
    await db.set_kv("access_mode", mode)
    await cb.answer("Acceso abierto: cualquiera puede usar el bot" if mode == "open"
                    else "Con aprobación: revisarás a cada usuario nuevo", show_alert=True)
    caption, pending, _ = await home_caption()
    await show_screen(cb, "admin.png", caption, K.admin_home(pending, mode))


# ── Difusión ────────────────────────────────────────────────────────────
@router.callback_query(F.data == "adm:bcast")
async def bcast_start(cb: CallbackQuery, state: FSMContext):
    await cb.answer()
    await state.set_state(Admin.broadcast)
    await cb.message.answer("📣 <b>Difusión</b>\n\nEscribe el mensaje para todos los usuarios activos.\n"
                            "<i>Admite negritas, cursivas y enlaces.</i>", reply_markup=K.kb([("✕ Cancelar", "adm:home")]))


@router.message(Admin.broadcast, F.text)
async def bcast_preview(message: Message, state: FSMContext):
    await state.update_data(bcast=message.html_text)
    n = len(await db.active_ids())
    await message.answer(f"<b>Vista previa</b>\n{DIV}\n{message.html_text}\n{DIV}\nSe enviará a {code(n)} usuarios.",
                         reply_markup=K.broadcast_confirm())


@router.callback_query(F.data == "adm:bcast_ok")
async def bcast_send(cb: CallbackQuery, bot: Bot, state: FSMContext):
    data = await state.get_data()
    text = data.get("bcast")
    await state.clear()
    if not text:
        return await cb.answer("No hay mensaje.", show_alert=True)
    await cb.answer("Enviando…")
    ok = fail = 0
    for uid in await db.active_ids():
        try:
            await bot.send_message(uid, f"📣 {text}")
            ok += 1
        except TelegramRetryAfter as e:
            await asyncio.sleep(e.retry_after)
            try:
                await bot.send_message(uid, f"📣 {text}")
                ok += 1
            except Exception:
                fail += 1
        except TelegramForbiddenError:
            fail += 1  # el usuario bloqueó al bot
        except Exception:
            fail += 1
        await asyncio.sleep(0.05)  # ~20 mensajes/s, bajo el límite de Telegram
    await cb.message.answer(f"✅ Difusión terminada\n├ Enviados · {code(ok)}\n└ Fallidos · {code(fail)}",
                            reply_markup=K.kb([("‹ Panel", "adm:home")]))
