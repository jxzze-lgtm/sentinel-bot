"""Ayudas compartidas por los handlers nuevos: límite de uso y descarga de archivos."""
from aiogram import Bot
from aiogram.types import Message

import texts as T
from config import settings
from database import db
from utils import RateLimiter

limiter = RateLimiter(settings.rate_limit_per_minute)


async def allowed(message: Message, tool: str, uid: int) -> bool:
    if not limiter.allow(uid):
        await message.answer(T.RATE_LIMITED)
        return False
    await db.log_usage(uid, tool)
    return True


async def grab(bot: Bot, message: Message) -> tuple[str, bytes] | None:
    """Descarga el documento o la foto del mensaje, respetando el límite de tamaño."""
    doc = message.document
    if doc:
        if (doc.file_size or 0) > settings.max_file_mb * 1024 * 1024:
            await message.answer(f"⚠️ El archivo supera {settings.max_file_mb} MB.")
            return None
        buf = await bot.download(doc)
        return doc.file_name or "archivo", buf.read()
    if message.photo:
        buf = await bot.download(message.photo[-1])
        return "foto.jpg", buf.read()
    return None


def is_pdf(data: bytes) -> bool:
    return data[:4] == b"%PDF"
