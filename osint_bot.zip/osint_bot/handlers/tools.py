"""Las herramientas OSINT: flujo de cada una, listas administrables y detección automática."""
import asyncio
import io
import re

from aiogram import Bot, F, Router
from aiogram.filters import StateFilter
from aiogram.fsm.context import FSMContext
from aiogram.types import BufferedInputFile, CallbackQuery, FSInputFile, InlineKeyboardButton, Message

import keyboards as K
import texts as T
from config import settings
from database import db
from services import archive, brand, breach, cve, domain, email_headers, file_scan, ip, metadata, url_scan
from states import Tool
from ui import finish, loading, send_long
from utils import CVE_RE, RateLimiter, code, esc, is_email, is_public_ip, normalize_domain, normalize_ip, \
    normalize_url

router = Router(name="tools")
limiter = RateLimiter(settings.rate_limit_per_minute)

MAX_CVE_KW, MAX_BRANDS, MAX_EMAILS = 10, 3, 5
URL_IN_TEXT = re.compile(r"(?:https?://|www\.)[^\s<>\"']+", re.I)

PROMPT_STATE = {
    "domain": Tool.domain, "ip": Tool.ip, "url": Tool.url, "file": Tool.file, "mail": Tool.mail,
    "cve": Tool.cve, "meta": Tool.meta, "archive": Tool.archive,
}


async def allowed(message: Message, tool: str, uid: int | None = None) -> bool:
    """Límite de uso + contador. Desde un callback, `message` es del bot: pasar uid del usuario."""
    uid = uid or message.from_user.id
    if not limiter.allow(uid):
        await message.answer(T.RATE_LIMITED)
        return False
    await db.log_usage(uid, tool)
    return True


def first_url(message: Message) -> str | None:
    """Toma el enlace de entidades (texto con hipervínculo, mensajes reenviados) o del texto."""
    text = message.text or message.caption or ""
    for ent in (message.entities or message.caption_entities or []):
        if ent.type == "text_link" and ent.url:
            return ent.url
        if ent.type == "url":
            return ent.extract_from(text)
    m = URL_IN_TEXT.search(text)
    return m.group(0) if m else (text.strip() or None)


# ══ Entrar a una herramienta ═════════════════════════════════════════════
@router.callback_query(F.data.startswith("tool:"))
async def open_tool(cb: CallbackQuery, state: FSMContext):
    name = cb.data.split(":", 1)[1]
    await cb.answer()
    await state.clear()
    if name in PROMPT_STATE:
        await state.set_state(PROMPT_STATE[name])
        await cb.message.answer(T.PROMPTS[name].format(mb=settings.max_file_mb), reply_markup=K.CANCEL)
    elif name == "cvesubs":
        await show_cve_subs(cb.message, cb.from_user.id)
    elif name == "brand":
        await show_brands(cb.message, cb.from_user.id)
    elif name == "breach":
        await show_emails(cb.message, cb.from_user.id)


# ══ 🌐 Dominio ═══════════════════════════════════════════════════════════
async def run_domain(message: Message, target: str):
    if not await allowed(message, "domain"):
        return
    status = await loading(message, f"Analizando {target}")
    await finish(status, await domain.analyze(target), K.after_result("domain"))


@router.message(Tool.domain, F.text)
async def domain_input(message: Message, state: FSMContext):
    target = normalize_domain(message.text)
    if not target:
        return await message.answer("⚠️ Eso no parece un dominio válido. Ejemplo: <code>ejemplo.com</code>",
                                    reply_markup=K.CANCEL)
    await state.clear()
    await run_domain(message, target)


# ══ 📍 IP ════════════════════════════════════════════════════════════════
async def run_ip(message: Message, target):
    if not await allowed(message, "ip"):
        return
    status = await loading(message, f"Analizando {target}")
    await finish(status, await ip.analyze(target), K.after_result("ip"))


@router.message(Tool.ip, F.text)
async def ip_input(message: Message, state: FSMContext):
    target = normalize_ip(message.text)
    if not target:
        return await message.answer("⚠️ IP no válida. Ejemplo: <code>8.8.8.8</code>", reply_markup=K.CANCEL)
    if not is_public_ip(target):
        return await message.answer("ℹ️ Es una IP privada o reservada; no tiene información pública.",
                                    reply_markup=K.CANCEL)
    await state.clear()
    await run_ip(message, target)


# ══ 🔗 Enlace ════════════════════════════════════════════════════════════
async def run_url(message: Message, target: str):
    if not await allowed(message, "url"):
        return
    status = await loading(message, "Revisando el enlace (puede tardar hasta 1 min)")
    text, shot = await url_scan.analyze(target)
    await finish(status, text, K.after_result("url"))
    if shot:
        try:
            await message.answer_photo(shot, caption="📸 <i>Captura de la página (urlscan.io)</i>")
        except Exception:
            pass


@router.message(Tool.url, F.text | F.caption)
async def url_input(message: Message, state: FSMContext):
    target = normalize_url(first_url(message) or "")
    if not target:
        return await message.answer("⚠️ No encontré un enlace público válido.", reply_markup=K.CANCEL)
    await state.clear()
    await run_url(message, target)


# ══ 📄 Archivo ═══════════════════════════════════════════════════════════
async def download(bot: Bot, message: Message) -> tuple[str, bytes] | None:
    doc = message.document
    if doc:
        if (doc.file_size or 0) > settings.max_file_mb * 1024 * 1024:
            await message.answer(f"⚠️ El archivo supera {settings.max_file_mb} MB.")
            return None
        buf = await bot.download(doc)
        return doc.file_name or "archivo", buf.read()
    if message.photo:
        buf = await bot.download(message.photo[-1])
        return "foto.jpg", buf.read()
    return None


async def run_file(message: Message, bot: Bot, state: FSMContext, name: str, data: bytes,
                   uid: int | None = None):
    if not await allowed(message, "file", uid):
        return
    status = await loading(message, "Revisando el archivo")
    text, offer = await file_scan.analyze(name, data)
    if offer and settings.virustotal_key and message.document:
        await state.set_state(None)
        await state.update_data(vt_file_id=message.document.file_id, vt_name=name)
        text += ("\n\n⬆️ <i>Puedo subirlo a VirusTotal para analizarlo. Ojo: quedará visible para la "
                 "comunidad de VT. No lo hagas con documentos confidenciales.</i>")
        await finish(status, text, K.vt_upload())
    else:
        await finish(status, text, K.after_result("file"))


@router.message(Tool.file, F.document | F.photo)
async def file_input(message: Message, bot: Bot, state: FSMContext):
    got = await download(bot, message)
    if not got:
        return
    await state.clear()
    await run_file(message, bot, state, *got)


@router.callback_query(F.data == "doc:vt")
async def vt_upload(cb: CallbackQuery, bot: Bot, state: FSMContext):
    data = await state.get_data()
    if "vt_file_id" not in data:
        return await cb.answer("El archivo ya no está disponible, envíalo de nuevo.", show_alert=True)
    await cb.answer("Subiendo…")
    buf = await bot.download(data["vt_file_id"])
    result = await file_scan.vt_upload(data["vt_name"], buf.read())
    await state.clear()
    await cb.message.answer(f"⬆️ {esc(result)}", reply_markup=K.after_result("file"))


# ══ ✉️ Correo ════════════════════════════════════════════════════════════
@router.message(Tool.mail, F.text)
async def mail_input(message: Message, state: FSMContext):
    await state.clear()
    if not await allowed(message, "mail"):
        return
    status = await loading(message, "Analizando encabezados")
    await finish(status, await email_headers.analyze(message.text), K.after_result("mail"))


@router.message(Tool.mail, F.document)
async def mail_file(message: Message, bot: Bot, state: FSMContext):
    """También acepta un archivo .eml o .txt con los encabezados."""
    got = await download(bot, message)
    if not got:
        return
    await state.clear()
    if not await allowed(message, "mail"):
        return
    raw = got[1].decode("utf-8", errors="replace")
    head = raw.split("\n\n", 1)[0] if "\n\n" in raw else raw
    status = await loading(message, "Analizando encabezados")
    await finish(status, await email_headers.analyze(head), K.after_result("mail"))


# ══ 🔎 CVE ═══════════════════════════════════════════════════════════════
async def run_cve(message: Message, cve_id: str):
    if not await allowed(message, "cve"):
        return
    status = await loading(message, f"Consultando {cve_id.upper()}")
    await finish(status, await cve.lookup(cve_id), K.after_result("cve"))


@router.message(Tool.cve, F.text)
async def cve_input(message: Message, state: FSMContext):
    t = message.text.strip()
    if not CVE_RE.match(t):
        return await message.answer("⚠️ Formato esperado: <code>CVE-2024-3400</code>", reply_markup=K.CANCEL)
    await state.clear()
    await run_cve(message, t)


async def show_cve_subs(message: Message, uid: int):
    kws = await db.cve_keywords(uid)
    body = "\n".join(f"├ {code(k)}" for k in kws[:-1]) + (f"\n└ {code(kws[-1])}" if kws else "")
    text = ("🛰 <b>Alertas CVE</b>\n\n"
            + (f"<b>Vigilando</b>\n{body.strip()}\n\n" if kws else "Aún no vigilas ningún producto.\n\n")
            + f"<i>Recibes el resumen cada día a las {settings.cve_digest_hour:02d}:00 (hora del servidor) "
              "solo si hay CVEs nuevas.</i>")
    markup = K.list_manager(kws, "cvek", "➕ Agregar producto", back="watch")
    if kws:
        markup.inline_keyboard.insert(-2, [InlineKeyboardButton(text="📨 Resumen de las últimas 24 h",
                                                                callback_data="cvek:now")])
    await message.answer(text, reply_markup=markup)


@router.callback_query(F.data.startswith("cvek:"))
async def cve_subs_cb(cb: CallbackQuery, state: FSMContext):
    _, action, *rest = cb.data.split(":")
    uid = cb.from_user.id
    kws = await db.cve_keywords(uid)
    if action == "add":
        if len(kws) >= MAX_CVE_KW:
            return await cb.answer(f"Máximo {MAX_CVE_KW} productos.", show_alert=True)
        await cb.answer()
        await state.set_state(Tool.cve_kw)
        return await cb.message.answer(T.PROMPTS["cve_kw"], reply_markup=K.CANCEL)
    if action == "del" and rest and rest[0].isdigit() and int(rest[0]) < len(kws):
        await db.del_cve_keyword(uid, kws[int(rest[0])])
        await cb.answer("Eliminado")
        return await show_cve_subs(cb.message, uid)
    if action == "now":
        await cb.answer()
        status = await loading(cb.message, "Buscando CVEs de las últimas 24 h")
        text = await cve.digest(kws, 24)
        return await finish(status, text or "🟢 Sin CVEs nuevas en las últimas 24 h para tus productos.",
                            K.kb([("‹ Mis alertas", "tool:cvesubs"), K.BACK_MAIN]))
    await cb.answer()


@router.message(Tool.cve_kw, F.text)
async def cve_kw_input(message: Message, state: FSMContext):
    kw = message.text.strip().lower()
    if not re.fullmatch(r"[\w .\-+]{2,40}", kw):
        return await message.answer("⚠️ Usa entre 2 y 40 caracteres (letras, números, espacios, - . +).",
                                    reply_markup=K.CANCEL)
    await state.clear()
    await db.add_cve_keyword(message.from_user.id, kw)
    await message.answer(f"✅ Ahora vigilo {code(kw)}.")
    await show_cve_subs(message, message.from_user.id)


# ══ 🛡 Marca ═════════════════════════════════════════════════════════════
async def show_brands(message: Message, uid: int):
    doms = await db.brands(uid)
    text = ("🛡 <b>Monitoreo de marca</b>\n\n"
            + ("Toca un dominio para escanearlo ahora.\n" if doms else "Aún no vigilas ningún dominio.\n")
            + f"<i>Reviso cada {settings.brand_scan_hours} h y te aviso si aparece un dominio parecido nuevo.</i>")
    await message.answer(text, reply_markup=K.list_manager(doms, "brand", "➕ Agregar dominio", back="watch",
                                                           action=("🔍", "scan")))


async def run_brand(message: Message, uid: int, target: str, save: bool):
    if not await allowed(message, "brand", uid):
        return
    status = await loading(message, f"Generando y revisando variantes de {target} (1–2 min)")
    result = await brand.scan(target)
    if save:
        await db.add_brand(uid, target, [r["domain"] for r in result["registered"]])
    text = brand.format_scan(result)
    if save:
        text += "\n\n✅ <b>Vigilancia activada.</b> Te aviso si aparece algo nuevo."
    await finish(status, text, K.kb([("‹ Mis dominios", "tool:brand"), K.BACK_MAIN]))


@router.callback_query(F.data.startswith("brand:"))
async def brand_cb(cb: CallbackQuery, state: FSMContext):
    _, action, *rest = cb.data.split(":")
    uid = cb.from_user.id
    doms = await db.brands(uid)
    idx = int(rest[0]) if rest and rest[0].isdigit() and int(rest[0]) < len(doms) else None
    if action == "add":
        if len(doms) >= MAX_BRANDS and uid not in settings.admin_ids:
            return await cb.answer(f"Máximo {MAX_BRANDS} dominios.", show_alert=True)
        await cb.answer()
        await state.set_state(Tool.brand)
        return await cb.message.answer(T.PROMPTS["brand"], reply_markup=K.CANCEL)
    if action == "del" and idx is not None:
        await db.del_brand(uid, doms[idx])
        await cb.answer("Eliminado")
        return await show_brands(cb.message, uid)
    if action == "scan" and idx is not None:
        await cb.answer()
        return await run_brand(cb.message, uid, doms[idx], save=False)
    await cb.answer()


@router.message(Tool.brand, F.text)
async def brand_input(message: Message, state: FSMContext):
    target = normalize_domain(message.text)
    if not target:
        return await message.answer("⚠️ Dominio no válido.", reply_markup=K.CANCEL)
    await state.clear()
    await run_brand(message, message.from_user.id, target, save=True)


# ══ 🔐 Filtraciones ══════════════════════════════════════════════════════
async def show_emails(message: Message, uid: int):
    if not settings.hibp_key:
        return await message.answer(T.MISSING_KEY.format(key="HIBP_API_KEY"),
                                    reply_markup=K.kb([("‹ Volver", "nav:privacy"), K.BACK_MAIN]))
    emails = await db.verified_emails(uid)
    text = ("🔐 <b>Auditoría de filtraciones</b>\n\n"
            + ("Toca un correo para revisarlo ahora.\n" if emails else "Agrega un correo tuyo para empezar.\n")
            + "<i>Reviso tus correos verificados cada día y te aviso si aparecen en una filtración nueva.</i>")
    await message.answer(text, reply_markup=K.list_manager(emails, "breach", "➕ Agregar correo", back="privacy",
                                                           action=("🔎", "check")))


async def run_breach(message: Message, uid: int, email: str):
    if not await allowed(message, "breach", uid):
        return
    status = await loading(message, "Consultando Have I Been Pwned")
    st, found = await breach.breaches_for(email)
    if st not in (200, 404):
        return await finish(status, f"⚠️ HIBP respondió con código {st}. Intenta más tarde.")
    await db.set_known_breaches(uid, email, [b["Name"] for b in found])
    await finish(status, breach.format_report(email, found),
                 K.kb([("‹ Mis correos", "tool:breach"), K.BACK_MAIN]))


@router.callback_query(F.data.startswith("breach:"))
async def breach_cb(cb: CallbackQuery, state: FSMContext):
    _, action, *rest = cb.data.split(":")
    uid = cb.from_user.id
    emails = await db.verified_emails(uid)
    idx = int(rest[0]) if rest and rest[0].isdigit() and int(rest[0]) < len(emails) else None
    if action == "add":
        if len(emails) >= MAX_EMAILS:
            return await cb.answer(f"Máximo {MAX_EMAILS} correos.", show_alert=True)
        if not settings.smtp_enabled and uid not in settings.admin_ids:
            return await cb.answer("La verificación por correo no está configurada. Contacta al administrador.",
                                   show_alert=True)
        await cb.answer()
        await state.set_state(Tool.breach_email)
        return await cb.message.answer(T.PROMPTS["breach"], reply_markup=K.CANCEL)
    if action == "del" and idx is not None:
        await db.del_email(uid, emails[idx])
        await cb.answer("Eliminado")
        return await show_emails(cb.message, uid)
    if action == "check" and idx is not None:
        await cb.answer()
        return await run_breach(cb.message, uid, emails[idx])
    await cb.answer()


@router.message(Tool.breach_email, F.text)
async def breach_email_input(message: Message, state: FSMContext):
    email = message.text.strip().lower()
    if not is_email(email):
        return await message.answer("⚠️ Correo no válido.", reply_markup=K.CANCEL)
    uid = message.from_user.id
    if not settings.smtp_enabled:
        # Sin SMTP solo los administradores pueden agregar (se asume que auditan correos propios)
        await state.clear()
        await db.mark_verified(uid, email)
        return await run_breach(message, uid, email)
    code_ = breach.new_code()
    await db.set_email_code(uid, email, code_)
    if not await breach.send_code(email, code_):
        await state.clear()
        return await message.answer("⚠️ No pude enviar el código. Revisa la configuración SMTP.")
    await state.set_state(Tool.breach_code)
    await message.answer(T.PROMPTS["breach_code"], reply_markup=K.CANCEL)


@router.message(Tool.breach_code, F.text)
async def breach_code_input(message: Message, state: FSMContext):
    uid = message.from_user.id
    email = await db.verify_email_code(uid, message.text.strip())
    if not email:
        return await message.answer("⚠️ Código incorrecto o vencido.", reply_markup=K.CANCEL)
    await state.clear()
    await message.answer(f"✅ {code(email)} verificado.")
    await run_breach(message, uid, email)


# ══ 🧹 Metadatos ═════════════════════════════════════════════════════════
async def run_meta(message: Message, name: str, data: bytes, compressed: bool, uid: int | None = None):
    if not await allowed(message, "meta", uid):
        return
    status = await loading(message, "Leyendo metadatos")
    try:
        report, cleaned, clean_name = await asyncio.to_thread(metadata.analyze_and_clean, name, data)
    except MemoryError:
        return await finish(status, "⚠️ La imagen es demasiado grande para este servidor. "
                                    "Prueba con una de menor resolución.", K.after_result("meta"))
    except Exception as e:  # noqa: BLE001
        return await finish(status, f"⚠️ No pude procesar el archivo ({esc(type(e).__name__)}). "
                                    "Verifica que no esté dañado.", K.after_result("meta"))
    if compressed:
        report = ("ℹ️ <i>La enviaste como foto: Telegram ya borró los metadatos al comprimirla. "
                  "Para ver los originales, envíala como archivo.</i>\n\n" + report)
    await finish(status, report, None if cleaned else K.after_result("meta"))
    if cleaned:
        await message.answer_document(BufferedInputFile(cleaned, filename=clean_name),
                                      caption="🧹 Copia limpia", reply_markup=K.after_result("meta"))


@router.message(Tool.meta, F.document | F.photo)
async def meta_input(message: Message, bot: Bot, state: FSMContext):
    got = await download(bot, message)
    if not got:
        return
    await state.clear()
    await run_meta(message, got[0], got[1], compressed=bool(message.photo))


# ══ 🗄 Evidencia ═════════════════════════════════════════════════════════
@router.message(Tool.archive, F.text)
async def archive_input(message: Message, state: FSMContext):
    target = normalize_url(first_url(message) or "")
    if not target:
        return await message.answer("⚠️ URL no válida.", reply_markup=K.CANCEL)
    await state.clear()
    if not await allowed(message, "archive"):
        return
    status = await loading(message, "Capturando y archivando (puede tardar 1–2 min)")
    text, html_path, receipt_path = await archive.capture(target, message.from_user.id)
    await finish(status, text, None if html_path else K.after_result("archive"))
    if html_path and receipt_path:
        await message.answer_document(FSInputFile(html_path))
        await message.answer_document(FSInputFile(receipt_path), caption="🧾 Recibo de integridad",
                                      reply_markup=K.after_result("archive"))


# ══ Entradas inválidas dentro de una herramienta ═════════════════════════
@router.message(StateFilter(Tool.file, Tool.meta))
async def expect_file(message: Message):
    await message.answer("📎 Envíame un archivo, o toca Cancelar.", reply_markup=K.CANCEL)


# ══ Detección automática (sin herramienta abierta) ═══════════════════════
@router.message(StateFilter(None), F.document | F.photo)
async def auto_document(message: Message, state: FSMContext):
    fid = message.document.file_id if message.document else message.photo[-1].file_id
    name = (message.document.file_name if message.document else "foto.jpg") or "archivo"
    await state.update_data(pending_file=fid, pending_name=name, pending_photo=bool(message.photo))
    await message.answer(f"📎 <b>{esc(name)}</b>\n¿Qué quieres hacer?", reply_markup=K.doc_choice())


@router.callback_query(F.data.in_({"doc:scan", "doc:meta"}))
async def auto_document_choice(cb: CallbackQuery, bot: Bot, state: FSMContext):
    data = await state.get_data()
    if "pending_file" not in data:
        return await cb.answer("Envía el archivo de nuevo.", show_alert=True)
    await cb.answer()
    await state.clear()
    raw = (await bot.download(data["pending_file"])).read()
    if cb.data == "doc:scan":
        await run_file(cb.message, bot, state, data["pending_name"], raw, uid=cb.from_user.id)
    else:
        await run_meta(cb.message, data["pending_name"], raw, compressed=data.get("pending_photo", False),
                       uid=cb.from_user.id)


@router.message(StateFilter(None), F.text & ~F.text.startswith("/"))
async def auto_detect(message: Message):
    t = message.text.strip()
    if "\n" in t and re.search(r"^(Received|From|Return-Path|Authentication-Results):", t, re.I | re.M):
        if await allowed(message, "mail"):
            status = await loading(message, "Detecté encabezados de correo, analizando")
            await finish(status, await email_headers.analyze(t), K.after_result("mail"))
        return
    if CVE_RE.match(t):
        return await run_cve(message, t)
    ip_ = normalize_ip(t)
    if ip_ is not None:
        if is_public_ip(ip_):
            return await run_ip(message, ip_)
        return await message.answer("ℹ️ Es una IP privada o reservada.")
    if re.match(r"^https?://", t, re.I) or message.entities and any(e.type in ("url", "text_link")
                                                                     for e in message.entities):
        url = normalize_url(first_url(message) or "")
        if url:
            return await run_url(message, url)
    dom = normalize_domain(t) if " " not in t else None
    if dom:
        return await run_domain(message, dom)
    await send_long(message, "🤔 No reconocí eso. Pega un dominio, IP, enlace o CVE, o usa /start para el menú.")


@router.message(StateFilter(None), F.text.startswith("/"))
async def unknown_command(message: Message):
    await message.answer("🤔 Comando no reconocido. Usa /start para abrir el menú.")
