"""Sección 📄 Documentos: firmar, marca de agua, proteger, comprimir y tablas → Excel."""
import asyncio

from aiogram import Bot, F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import BufferedInputFile, CallbackQuery, Message

import keyboards as K
import texts as T
from handlers.base import allowed, grab, is_pdf
from services import pdf_tools
from states import Doc
from ui import finish, loading
from utils import code, esc, human_size

router = Router(name="documents")

# tool: → estado que espera el PDF
OPEN = {
    "doc_sign": Doc.sign_file, "doc_wm": Doc.wm_file, "doc_protect": Doc.protect_file,
    "doc_unprotect": Doc.unprotect_file, "doc_compress": Doc.compress_file, "doc_tables": Doc.tables_file,
}


@router.callback_query(F.data.startswith("tool:"), F.data.func(lambda d: d.split(":", 1)[1] in OPEN))
async def open_doc(cb: CallbackQuery, state: FSMContext):
    name = cb.data.split(":", 1)[1]
    await cb.answer()
    await state.clear()
    await state.set_state(OPEN[name])
    await cb.message.answer(T.PROMPTS[name], reply_markup=K.CANCEL)


async def _need_pdf(message: Message, bot: Bot) -> tuple[str, bytes] | None:
    got = await grab(bot, message)
    if not got:
        return None
    if not is_pdf(got[1]):
        await message.answer("⚠️ Envía un archivo PDF (📎 → Archivo).", reply_markup=K.CANCEL)
        return None
    return got


# ── ✍️ Firmar ────────────────────────────────────────────────────────────
@router.message(Doc.sign_file, F.document)
async def sign_file(message: Message, bot: Bot, state: FSMContext):
    got = await _need_pdf(message, bot)
    if not got:
        return
    await state.update_data(pdf=message.document.file_id, name=got[0])
    await state.set_state(Doc.sign_name)
    await message.answer("✍️ ¿A nombre de quién va la firma?", reply_markup=K.CANCEL)


@router.message(Doc.sign_name, F.text)
async def sign_name(message: Message, bot: Bot, state: FSMContext):
    data = await state.get_data()
    await state.clear()
    if not await allowed(message, "doc_sign", message.from_user.id):
        return
    raw = (await bot.download(data["pdf"])).read()
    status = await loading(message, "Firmando")
    try:
        signed, folio = await asyncio.to_thread(pdf_tools.sign, raw, message.text.strip()[:40])
    except Exception as e:  # noqa: BLE001
        return await finish(status, f"⚠️ No se pudo firmar ({esc(type(e).__name__)}).",
                            K.kb([("‹ Documentos", "nav:documents"), K.BACK_MAIN]))
    out = (data["name"].rsplit(".", 1)[0] if "." in data["name"] else data["name"]) + "_firmado.pdf"
    await status.delete()
    await message.answer_document(BufferedInputFile(signed, out), caption=f"✅ Firmado · folio {code(folio)}",
                                  reply_markup=K.kb([("‹ Documentos", "nav:documents"), K.BACK_MAIN]))


# ── 💧 Marca de agua ─────────────────────────────────────────────────────
@router.message(Doc.wm_file, F.document)
async def wm_file(message: Message, bot: Bot, state: FSMContext):
    got = await _need_pdf(message, bot)
    if not got:
        return
    await state.update_data(pdf=message.document.file_id, name=got[0])
    await state.set_state(Doc.wm_text)
    await message.answer("💧 ¿Qué texto pongo de marca de agua? (ej. CONFIDENCIAL)", reply_markup=K.CANCEL)


@router.message(Doc.wm_text, F.text)
async def wm_text(message: Message, bot: Bot, state: FSMContext):
    data = await state.get_data()
    await state.clear()
    if not await allowed(message, "doc_wm", message.from_user.id):
        return
    raw = (await bot.download(data["pdf"])).read()
    status = await loading(message, "Aplicando marca de agua")
    try:
        out = await asyncio.to_thread(pdf_tools.watermark, raw, message.text.strip())
    except Exception as e:  # noqa: BLE001
        return await finish(status, f"⚠️ No se pudo ({esc(type(e).__name__)}).",
                            K.kb([("‹ Documentos", "nav:documents"), K.BACK_MAIN]))
    name = (data["name"].rsplit(".", 1)[0] if "." in data["name"] else data["name"]) + "_marca.pdf"
    await status.delete()
    await message.answer_document(BufferedInputFile(out, name), caption="✅ Listo",
                                  reply_markup=K.kb([("‹ Documentos", "nav:documents"), K.BACK_MAIN]))


# ── 🔒 Proteger / 🔓 Quitar contraseña ───────────────────────────────────
@router.message(Doc.protect_file, F.document)
async def protect_file(message: Message, bot: Bot, state: FSMContext):
    got = await _need_pdf(message, bot)
    if not got:
        return
    await state.update_data(pdf=message.document.file_id, name=got[0])
    await state.set_state(Doc.protect_pwd)
    await message.answer("🔒 Escribe la contraseña que quieres ponerle.", reply_markup=K.CANCEL)


@router.message(Doc.unprotect_file, F.document)
async def unprotect_file(message: Message, bot: Bot, state: FSMContext):
    got = await _need_pdf(message, bot)
    if not got:
        return
    await state.update_data(pdf=message.document.file_id, name=got[0])
    await state.set_state(Doc.unprotect_pwd)
    await message.answer("🔓 Escribe la contraseña actual del PDF.", reply_markup=K.CANCEL)


@router.message(Doc.protect_pwd, F.text)
async def protect_pwd(message: Message, bot: Bot, state: FSMContext):
    await _apply_pwd(message, bot, state, "doc_protect")


@router.message(Doc.unprotect_pwd, F.text)
async def unprotect_pwd(message: Message, bot: Bot, state: FSMContext):
    await _apply_pwd(message, bot, state, "doc_unprotect")


async def _apply_pwd(message: Message, bot: Bot, state: FSMContext, tool: str):
    data = await state.get_data()
    pwd = message.text.strip()
    try:
        await message.delete()  # oculta la contraseña del chat
    except Exception:
        pass
    await state.clear()
    if not await allowed(message, tool, message.from_user.id):
        return
    raw = (await bot.download(data["pdf"])).read()
    status = await message.answer("⏳ <i>Procesando…</i>")
    try:
        if tool == "doc_protect":
            out = await asyncio.to_thread(pdf_tools.protect, raw, pwd)
            cap, suffix = "✅ PDF protegido con contraseña", "_protegido.pdf"
        else:
            out = await asyncio.to_thread(pdf_tools.unprotect, raw, pwd)
            cap, suffix = "✅ Contraseña eliminada", "_abierto.pdf"
    except ValueError as e:
        return await finish(status, f"⚠️ {esc(str(e))}", K.kb([("‹ Documentos", "nav:documents"), K.BACK_MAIN]))
    except Exception as e:  # noqa: BLE001
        return await finish(status, f"⚠️ No se pudo ({esc(type(e).__name__)}).",
                            K.kb([("‹ Documentos", "nav:documents"), K.BACK_MAIN]))
    name = (data["name"].rsplit(".", 1)[0] if "." in data["name"] else data["name"]) + suffix
    await status.delete()
    await message.answer_document(BufferedInputFile(out, name), caption=cap,
                                  reply_markup=K.kb([("‹ Documentos", "nav:documents"), K.BACK_MAIN]))


# ── 🗜 Comprimir PDF ─────────────────────────────────────────────────────
@router.message(Doc.compress_file, F.document)
async def compress_pdf(message: Message, bot: Bot, state: FSMContext):
    got = await _need_pdf(message, bot)
    if not got:
        return
    await state.clear()
    if not await allowed(message, "doc_compress", message.from_user.id):
        return
    status = await loading(message, "Comprimiendo PDF")
    try:
        out = await asyncio.to_thread(pdf_tools.compress, got[1])
    except ValueError as e:
        return await finish(status, f"⚠️ {esc(str(e))}", K.kb([("‹ Documentos", "nav:documents"), K.BACK_MAIN]))
    except Exception as e:  # noqa: BLE001
        return await finish(status, f"⚠️ No se pudo ({esc(type(e).__name__)}).",
                            K.kb([("‹ Documentos", "nav:documents"), K.BACK_MAIN]))
    name = (got[0].rsplit(".", 1)[0] if "." in got[0] else got[0]) + "_comprimido.pdf"
    if len(out) >= len(got[1]):
        cap = f"ℹ️ Ya estaba optimizado ({human_size(len(got[1]))}); no se redujo."
    else:
        cap = f"✅ {human_size(len(got[1]))} → {human_size(len(out))}"
    await status.delete()
    await message.answer_document(BufferedInputFile(out, name), caption=cap,
                                  reply_markup=K.kb([("‹ Documentos", "nav:documents"), K.BACK_MAIN]))


# ── 📊 Tablas → Excel ────────────────────────────────────────────────────
@router.message(Doc.tables_file, F.document)
async def tables_file(message: Message, bot: Bot, state: FSMContext):
    got = await _need_pdf(message, bot)
    if not got:
        return
    await state.clear()
    if not await allowed(message, "doc_tables", message.from_user.id):
        return
    status = await loading(message, "Buscando y extrayendo tablas")
    try:
        xlsx, n = await asyncio.to_thread(pdf_tools.tables_to_xlsx, got[1])
    except ValueError as e:
        return await finish(status, f"⚠️ {esc(str(e))}", K.kb([("‹ Documentos", "nav:documents"), K.BACK_MAIN]))
    except Exception as e:  # noqa: BLE001
        return await finish(status, f"⚠️ No se pudo ({esc(type(e).__name__)}).",
                            K.kb([("‹ Documentos", "nav:documents"), K.BACK_MAIN]))
    name = (got[0].rsplit(".", 1)[0] if "." in got[0] else got[0]) + ".xlsx"
    await status.delete()
    await message.answer_document(BufferedInputFile(xlsx, name), caption=f"✅ {n} tabla(s) extraída(s)",
                                  reply_markup=K.kb([("‹ Documentos", "nav:documents"), K.BACK_MAIN]))


# ── Si mandan algo que no es archivo en un paso de archivo ───────────────
@router.message(Doc.sign_file)
@router.message(Doc.wm_file)
@router.message(Doc.protect_file)
@router.message(Doc.unprotect_file)
@router.message(Doc.compress_file)
@router.message(Doc.tables_file)
async def expect_pdf(message: Message):
    await message.answer("📎 Envíame el PDF como archivo (📎 → Archivo), o toca Cancelar.", reply_markup=K.CANCEL)
