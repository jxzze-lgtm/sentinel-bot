"""Sección 📌 Productividad: recordatorios, notas y acortador de enlaces."""
import re
import secrets
from datetime import datetime

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

import keyboards as K
import texts as T
from config import settings
from database import db
from handlers.base import allowed
from services import reminders as rem
from states import Prod
from utils import DIV, code, esc

router = Router(name="productivity")
BACK = [("‹ Productividad", "nav:productivity"), ("‹ Menú", "nav:main")]
MAX_REMINDERS, MAX_NOTES, MAX_SHORTS = 30, 100, 50
CODE_RE = re.compile(r"^[A-Za-z0-9_-]{3,12}$")


def _kb(items: list, prefix: str, add_label: str):
    rows = []
    for it in items[:12]:
        rows.append([(f"🗑 {it['label']}", f"{prefix}:del:{it['id']}")])
    rows.append([(add_label, f"{prefix}:add")])
    rows.append(BACK)
    return K.kb(*rows)


# ══ ⏰ Recordatorios ══════════════════════════════════════════════════════
@router.callback_query(F.data == "tool:reminders")
async def reminders_home(cb: CallbackQuery, state: FSMContext):
    await cb.answer()
    await state.clear()
    await show_reminders(cb.message, cb.from_user.id)


async def show_reminders(message: Message, uid: int):
    items = await db.reminders(uid)
    labels = [{"id": r["id"],
               "label": f"{datetime.fromtimestamp(r['due_ts']):%d/%m %H:%M} · {r['text'][:22]}"}
              for r in items]
    text = (f"⏰ <b>Recordatorios</b>\n{DIV}\n"
            + ("Tus recordatorios pendientes:" if items else "No tienes recordatorios pendientes."))
    await message.answer(text, reply_markup=_kb(labels, "rem", "➕ Nuevo recordatorio"))


@router.callback_query(F.data.startswith("rem:"))
async def rem_cb(cb: CallbackQuery, state: FSMContext):
    _, action, *rest = cb.data.split(":")
    uid = cb.from_user.id
    if action == "add":
        if len(await db.reminders(uid)) >= MAX_REMINDERS:
            return await cb.answer(f"Máximo {MAX_REMINDERS} recordatorios.", show_alert=True)
        await cb.answer()
        await state.set_state(Prod.reminder)
        return await cb.message.answer(T.PROMPTS["reminder"], reply_markup=K.CANCEL)
    if action == "del" and rest:
        await db.del_reminder(uid, int(rest[0]))
        await cb.answer("Eliminado")
        return await show_reminders(cb.message, uid)
    await cb.answer()


@router.message(Prod.reminder, F.text)
async def reminder_add(message: Message, state: FSMContext):
    parsed = rem.parse(message.text)
    if not parsed:
        return await message.answer("⚠️ No entendí la fecha. Ejemplos:\n"
                                    "<code>en 2h …</code> · <code>mañana 9:00 …</code> · "
                                    "<code>viernes 10:00 …</code>", reply_markup=K.CANCEL)
    due, body = parsed
    if not body:
        return await message.answer("⚠️ Falta qué recordarte. Ej.: <code>mañana 9:00 junta</code>",
                                    reply_markup=K.CANCEL)
    if due < datetime.now():
        return await message.answer("⚠️ Esa fecha ya pasó.", reply_markup=K.CANCEL)
    await state.clear()
    if not await allowed(message, "reminder", message.from_user.id):
        return
    await db.add_reminder(message.from_user.id, body, int(due.timestamp()))
    await message.answer(f"✅ Te recordaré <b>{esc(body)}</b>\nel {code(due.strftime('%d/%m/%Y %H:%M'))}.")
    await show_reminders(message, message.from_user.id)


# ══ 📝 Notas ══════════════════════════════════════════════════════════════
@router.callback_query(F.data == "tool:notes")
async def notes_home(cb: CallbackQuery, state: FSMContext):
    await cb.answer()
    await state.clear()
    await show_notes(cb.message, cb.from_user.id)


async def show_notes(message: Message, uid: int, query: str | None = None):
    items = await db.notes(uid, query)
    labels = [{"id": n["id"], "label": n["text"][:30]} for n in items]
    title = f"📝 <b>Notas</b>" + (f" · «{esc(query)}»" if query else "")
    text = (f"{title}\n{DIV}\n"
            + (f"{len(items)} nota(s):" if items else "No hay notas." if query else "Aún no tienes notas."))
    rows = []
    for it in labels[:12]:
        rows.append([(f"🗑 {it['label']}", f"note:del:{it['id']}")])
    rows.append([("➕ Nueva nota", "note:add"), ("🔎 Buscar", "note:search")])
    rows.append(BACK)
    await message.answer(text, reply_markup=K.kb(*rows))


@router.callback_query(F.data.startswith("note:"))
async def note_cb(cb: CallbackQuery, state: FSMContext):
    _, action, *rest = cb.data.split(":")
    uid = cb.from_user.id
    if action == "add":
        if len(await db.notes(uid)) >= MAX_NOTES:
            return await cb.answer(f"Máximo {MAX_NOTES} notas.", show_alert=True)
        await cb.answer()
        await state.set_state(Prod.note)
        return await cb.message.answer(T.PROMPTS["note"], reply_markup=K.CANCEL)
    if action == "search":
        await cb.answer()
        await state.set_state(Prod.note_search)
        return await cb.message.answer(T.PROMPTS["note_search"], reply_markup=K.CANCEL)
    if action == "del" and rest:
        await db.del_note(uid, int(rest[0]))
        await cb.answer("Eliminada")
        return await show_notes(cb.message, uid)
    await cb.answer()


@router.message(Prod.note, F.text)
async def note_add(message: Message, state: FSMContext):
    await state.clear()
    if not await allowed(message, "note", message.from_user.id):
        return
    await db.add_note(message.from_user.id, message.text.strip()[:1000])
    await message.answer("✅ Nota guardada.")
    await show_notes(message, message.from_user.id)


@router.message(Prod.note_search, F.text)
async def note_search(message: Message, state: FSMContext):
    await state.clear()
    await show_notes(message, message.from_user.id, message.text.strip())


# ══ 🔗 Acortador ══════════════════════════════════════════════════════════
@router.callback_query(F.data == "tool:short")
async def short_home(cb: CallbackQuery, state: FSMContext):
    await cb.answer()
    await state.clear()
    await show_shorts(cb.message, cb.from_user.id)


async def show_shorts(message: Message, uid: int):
    if not settings.shortener_enabled:
        return await message.answer(
            "🔗 <b>Acortador de enlaces</b>\n" + DIV +
            "\n⚠️ Aún no está activado. El administrador debe definir <code>SHORTENER_BASE_URL</code> "
            "en el .env y abrir el puerto. (Está explicado en el README.)",
            reply_markup=K.kb(BACK))
    items = await db.shorts(uid)
    base = settings.shortener_base_url
    lines = [f"├ {base}/{code(s['code'])} · {s['clicks']} clics" for s in items[:10]]
    text = (f"🔗 <b>Acortador de enlaces</b>\n{DIV}\n"
            + ("Tus enlaces:\n" + "\n".join(lines) if items else "Aún no has creado enlaces."))
    rows = [[(f"🗑 /{s['code']}", f"short:del:{s['code']}")] for s in items[:10]]
    rows.append([("➕ Acortar enlace", "short:add")])
    rows.append(BACK)
    await message.answer(text, reply_markup=K.kb(*rows), disable_web_page_preview=True)


@router.callback_query(F.data.startswith("short:"))
async def short_cb(cb: CallbackQuery, state: FSMContext):
    _, action, *rest = cb.data.split(":")
    uid = cb.from_user.id
    if action == "add":
        if not settings.shortener_enabled:
            return await cb.answer("El acortador no está activado.", show_alert=True)
        if len(await db.shorts(uid)) >= MAX_SHORTS:
            return await cb.answer(f"Máximo {MAX_SHORTS} enlaces.", show_alert=True)
        await cb.answer()
        await state.set_state(Prod.short)
        return await cb.message.answer(T.PROMPTS["short"], reply_markup=K.CANCEL)
    if action == "del" and rest:
        await db.del_short(uid, rest[0])
        await cb.answer("Eliminado")
        return await show_shorts(cb.message, uid)
    await cb.answer()


@router.message(Prod.short, F.text)
async def short_add(message: Message, state: FSMContext):
    url = message.text.strip()
    if not re.match(r"^https?://", url, re.I):
        return await message.answer("⚠️ Pega un enlace que empiece con http:// o https://", reply_markup=K.CANCEL)
    await state.clear()
    if not await allowed(message, "short", message.from_user.id):
        return
    code_ = secrets.token_urlsafe(4).replace("_", "").replace("-", "")[:6]
    await db.add_short(code_, message.from_user.id, url)
    short_url = f"{settings.shortener_base_url}/{code_}"
    await message.answer(f"✅ Enlace corto creado:\n{code(short_url)}\n\n<i>Cópialo y compártelo.</i>",
                         disable_web_page_preview=True)
    await show_shorts(message, message.from_user.id)
