"""Inicio, navegación entre secciones, ayuda y cancelar."""
from aiogram import F, Router
from aiogram.filters import Command, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

import keyboards as K
import texts as T
from ui import send_screen, show_screen

router = Router(name="common")


@router.message(CommandStart())
@router.message(Command("menu"))
async def start(message: Message, state: FSMContext, is_admin: bool):
    await state.clear()
    await send_screen(message.bot, message.chat.id, "welcome.png", T.WELCOME, K.main_menu(is_admin))


@router.message(Command("help"))
async def help_cmd(message: Message):
    await message.answer(T.HELP, reply_markup=K.HELP_KB)


@router.message(Command("cancel"))
async def cancel_cmd(message: Message, state: FSMContext, is_admin: bool):
    await state.clear()
    await message.answer("✕ Acción cancelada.", reply_markup=K.main_menu(is_admin))


@router.callback_query(F.data == "cancel")
async def cancel_cb(cb: CallbackQuery, state: FSMContext, is_admin: bool):
    await state.clear()
    await cb.answer("Cancelado")
    await show_screen(cb, "welcome.png", T.WELCOME, K.main_menu(is_admin))


@router.callback_query(F.data.startswith("nav:"))
async def navigate(cb: CallbackQuery, state: FSMContext, is_admin: bool):
    await state.clear()
    target = cb.data.split(":", 1)[1]
    await cb.answer()
    if target == "main":
        await show_screen(cb, "welcome.png", T.WELCOME, K.main_menu(is_admin))
    elif target == "help":
        await show_screen(cb, "welcome.png", T.HELP, K.HELP_KB)
    elif target in T.SECTIONS:
        image, caption = T.SECTIONS[target]
        await show_screen(cb, image, caption, K.SECTION_KB[target])
