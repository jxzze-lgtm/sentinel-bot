"""Tareas programadas: resumen de CVEs, vigilancia de marca y de filtraciones."""
import asyncio
import logging

from aiogram import Bot
from aiogram.types import LinkPreviewOptions
from apscheduler.schedulers.asyncio import AsyncIOScheduler

from config import settings
from database import db
from services import brand, breach, cve
from utils import split_message

log = logging.getLogger(__name__)


async def _send(bot: Bot, uid: int, text: str):
    for part in split_message(text):
        try:
            await bot.send_message(uid, part, link_preview_options=LinkPreviewOptions(is_disabled=True))
        except Exception as e:  # noqa: BLE001
            log.warning("No pude enviar a %s: %s", uid, e)
            return
        await asyncio.sleep(0.05)


async def cve_digest_job(bot: Bot):
    subs = await db.cve_subscribers()
    log.info("Resumen CVE para %d usuarios", len(subs))
    for uid, keywords in subs.items():
        try:
            text = await cve.digest(keywords, 24)
        except Exception as e:  # noqa: BLE001
            log.exception("Error en resumen CVE: %s", e)
            continue
        if text:
            await _send(bot, uid, text)


async def brand_watch_job(bot: Bot):
    watches = await db.all_brands()
    log.info("Vigilancia de marca: %d dominios", len(watches))
    for w in watches:
        try:
            result = await brand.scan(w["domain"])
        except Exception as e:  # noqa: BLE001
            log.exception("Error escaneando %s: %s", w["domain"], e)
            continue
        current = {r["domain"] for r in result["registered"]}
        new = current - set(w["known"])
        await db.add_brand(w["user_id"], w["domain"], sorted(current | set(w["known"])))
        if new:
            text = "🚨 <b>Alerta de marca</b>\n\n" + brand.format_scan(result, new_only=new)
            await _send(bot, w["user_id"], text)
        await asyncio.sleep(2)


async def breach_watch_job(bot: Bot):
    if not settings.hibp_key:
        return
    rows = await db.all_verified_emails()
    log.info("Vigilancia de filtraciones: %d correos", len(rows))
    for row in rows:
        st, found = await breach.breaches_for(row["email"])
        if st in (200, 404):
            names = {b["Name"] for b in found}
            new = [b for b in found if b["Name"] not in set(row["known_breaches"])]
            await db.set_known_breaches(row["user_id"], row["email"], sorted(names))
            if new:
                text = "🚨 <b>Nueva filtración detectada</b>\n\n" + breach.format_report(row["email"], new)
                await _send(bot, row["user_id"], text)
        await asyncio.sleep(7)  # respeta el límite de la API de HIBP


def setup(bot: Bot) -> AsyncIOScheduler:
    sch = AsyncIOScheduler()
    sch.add_job(cve_digest_job, "cron", hour=settings.cve_digest_hour, minute=0, args=[bot],
                id="cve_digest", misfire_grace_time=3600)
    sch.add_job(brand_watch_job, "interval", hours=settings.brand_scan_hours, args=[bot],
                id="brand_watch", misfire_grace_time=3600)
    sch.add_job(breach_watch_job, "cron", hour=(settings.cve_digest_hour + 1) % 24, minute=15, args=[bot],
                id="breach_watch", misfire_grace_time=3600)
    sch.start()
    return sch
