"""Negocio: recibos/cotizaciones en PDF y cadenas para QR de Wi-Fi, contacto (vCard) y pago."""
import re
from datetime import datetime


# ── Recibo / Cotización ─────────────────────────────────────────────────
def parse_document(text: str) -> dict:
    """Interpreta el texto pegado por el usuario.

    Formato esperado (las líneas de conceptos son: descripción | cantidad | precio):
        Negocio: Mi Empresa
        Cliente: Juan Pérez
        Café | 2 | 90
        Pan dulce | 5 | 12.50
        IVA: 16
    """
    meta = {"negocio": "", "cliente": "", "fecha": datetime.now().strftime("%Y-%m-%d"),
            "nota": "", "iva": 0.0}
    items = []
    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            continue
        low = line.lower()
        matched = False
        for key in ("negocio", "cliente", "fecha", "nota"):
            if low.startswith(key + ":"):
                meta[key] = line.split(":", 1)[1].strip()
                matched = True
                break
        if matched:
            continue
        if low.startswith("iva:"):
            try:
                meta["iva"] = float(re.sub(r"[^\d.]", "", line.split(":", 1)[1]))
            except ValueError:
                pass
            continue
        if "|" in line:
            parts = [p.strip() for p in line.split("|")]
            desc = parts[0]
            qty = float(re.sub(r"[^\d.]", "", parts[1]) or 1) if len(parts) > 1 else 1
            price = float(re.sub(r"[^\d.]", "", parts[2]) or 0) if len(parts) > 2 else 0
            items.append({"desc": desc, "qty": qty, "price": price})
    meta["items"] = items
    return meta


def make_document(data: dict, kind: str = "recibo") -> bytes:
    from fpdf import FPDF

    titulo = "RECIBO" if kind == "recibo" else "COTIZACIÓN"
    folio = f"{datetime.now():%Y%m%d-%H%M}"
    items = data["items"]
    subtotal = sum(i["qty"] * i["price"] for i in items)
    iva_amt = subtotal * data["iva"] / 100
    total = subtotal + iva_amt

    pdf = FPDF(unit="mm", format="A4")
    pdf.add_page()
    pdf.set_auto_page_break(True, margin=20)
    W = pdf.w - 20  # margen derecho

    # Encabezado
    pdf.set_fill_color(11, 15, 20)
    pdf.rect(0, 0, pdf.w, 34, style="F")
    pdf.set_xy(14, 9)
    pdf.set_text_color(236, 240, 244)
    pdf.set_font("helvetica", "B", 20)
    pdf.cell(0, 10, data["negocio"] or "Mi negocio")
    pdf.set_xy(14, 21)
    pdf.set_text_color(57, 208, 180)
    pdf.set_font("helvetica", "B", 11)
    pdf.cell(0, 6, titulo)
    pdf.set_text_color(139, 150, 164)
    pdf.set_font("helvetica", "", 10)
    pdf.set_xy(W - 60, 21)
    pdf.cell(60, 6, f"Folio {folio}", align="R")

    # Datos
    pdf.set_xy(14, 42)
    pdf.set_text_color(40, 44, 52)
    pdf.set_font("helvetica", "", 11)
    pdf.cell(0, 7, f"Cliente: {data['cliente'] or '-'}", ln=1)
    pdf.set_x(14)
    pdf.cell(0, 7, f"Fecha: {data['fecha']}", ln=1)
    pdf.ln(4)

    # Tabla
    pdf.set_x(14)
    pdf.set_fill_color(11, 15, 20)
    pdf.set_text_color(255, 255, 255)
    pdf.set_font("helvetica", "B", 10)
    widths = [W - 14 - 30 - 35 - 35, 30, 35, 35]
    for txt, w, al in zip(("Concepto", "Cant.", "P. unit.", "Importe"), widths, ("L", "C", "R", "R")):
        pdf.cell(w, 9, txt, border=0, align=al, fill=True)
    pdf.ln(9)

    pdf.set_text_color(40, 44, 52)
    pdf.set_font("helvetica", "", 10)
    fill = False
    for it in items:
        if fill:
            pdf.set_fill_color(243, 245, 247)
        imp = it["qty"] * it["price"]
        pdf.set_x(14)
        pdf.cell(widths[0], 8, it["desc"][:45], align="L", fill=fill)
        pdf.cell(widths[1], 8, f"{it['qty']:g}", align="C", fill=fill)
        pdf.cell(widths[2], 8, f"${it['price']:,.2f}", align="R", fill=fill)
        pdf.cell(widths[3], 8, f"${imp:,.2f}", align="R", fill=fill)
        pdf.ln(8)
        fill = not fill

    # Totales
    pdf.ln(3)
    tx = 14 + widths[0] + widths[1]
    for label, value, bold in (("Subtotal", subtotal, False),
                               (f"IVA {data['iva']:g}%", iva_amt, False) if data["iva"] else (None, 0, False),
                               ("TOTAL", total, True)):
        if label is None:
            continue
        pdf.set_x(tx)
        pdf.set_font("helvetica", "B" if bold else "", 11 if bold else 10)
        if bold:
            pdf.set_text_color(57, 160, 140)
        pdf.cell(widths[2], 8, label, align="R")
        pdf.cell(widths[3], 8, f"${value:,.2f}", align="R")
        pdf.ln(8)

    if data["nota"]:
        pdf.ln(6)
        pdf.set_x(14)
        pdf.set_text_color(139, 150, 164)
        pdf.set_font("helvetica", "I", 9)
        pdf.multi_cell(W - 14, 5, f"Nota: {data['nota']}")

    pdf.set_y(-18)
    pdf.set_text_color(170, 175, 182)
    pdf.set_font("helvetica", "", 8)
    pdf.cell(0, 6, f"Generado con Sentinel OSINT · {datetime.now():%Y-%m-%d %H:%M}", align="C")

    return bytes(pdf.output())


# ── Cadenas para QR ──────────────────────────────────────────────────────
def _esc(s: str) -> str:
    return s.replace("\\", "\\\\").replace(";", "\\;").replace(",", "\\,").replace(":", "\\:").replace('"', '\\"')


def qr_wifi(ssid: str, password: str, auth: str = "WPA") -> str:
    if not password:
        auth = "nopass"
    return f"WIFI:T:{auth};S:{_esc(ssid)};P:{_esc(password)};;"


def qr_vcard(nombre: str, telefono: str = "", email: str = "", empresa: str = "", url: str = "") -> str:
    lines = ["BEGIN:VCARD", "VERSION:3.0", f"FN:{nombre}", f"N:{nombre};;;;"]
    if empresa:
        lines.append(f"ORG:{empresa}")
    if telefono:
        lines.append(f"TEL;TYPE=CELL:{telefono}")
    if email:
        lines.append(f"EMAIL:{email}")
    if url:
        lines.append(f"URL:{url}")
    lines.append("END:VCARD")
    return "\n".join(lines)
