"""Utilidades generales: contraseñas, conversor de unidades/monedas, traductor y security.txt."""
import re
import secrets
import string

from services import http
from utils import DIV, block, code, esc, header, join_blocks

# ── Generador de contraseñas ────────────────────────────────────────────
WORDS = ("sol luna mar rio monte cielo fuego tierra viento nube piedra arbol flor hoja rayo "
         "tigre lobo aguila zorro oso gato perro halcon puma lince ")  # base para frases
WORDLIST = sorted(set(WORDS.split()))


def gen_password(length: int = 16, symbols: bool = True) -> str:
    length = max(8, min(length, 64))
    alpha = string.ascii_letters + string.digits + ("!@#$%&*?-_" if symbols else "")
    while True:
        pwd = "".join(secrets.choice(alpha) for _ in range(length))
        if (any(c.islower() for c in pwd) and any(c.isupper() for c in pwd)
                and any(c.isdigit() for c in pwd)):
            return pwd


def gen_passphrase(words: int = 4) -> str:
    words = max(3, min(words, 8))
    chosen = [secrets.choice(WORDLIST).capitalize() for _ in range(words)]
    return "-".join(chosen) + str(secrets.randbelow(90) + 10)


def passwords_block() -> str:
    rows = [f"🔐 {code(gen_password(16))}",
            f"🔐 {code(gen_password(20))}",
            f"🗝 {code(gen_passphrase(4))}  <i>(fácil de recordar)</i>"]
    return join_blocks(header("🔑", "Contraseñas generadas"),
                       "\n".join(rows),
                       "<i>Se generan en el servidor con un generador seguro y no se guardan. "
                       "Guárdalas en un gestor de contraseñas.</i>")


# ── Conversor de unidades ───────────────────────────────────────────────
# factor hacia la unidad base de cada familia
LENGTH = {"m": 1, "km": 1000, "cm": 0.01, "mm": 0.001, "mi": 1609.344, "milla": 1609.344,
          "millas": 1609.344, "ft": 0.3048, "pie": 0.3048, "pies": 0.3048, "in": 0.0254,
          "pulgada": 0.0254, "pulgadas": 0.0254, "yd": 0.9144}
MASS = {"kg": 1, "g": 0.001, "mg": 1e-6, "ton": 1000, "tonelada": 1000, "lb": 0.45359237,
        "libra": 0.45359237, "libras": 0.45359237, "oz": 0.0283495, "onza": 0.0283495}
VOLUME = {"l": 1, "litro": 1, "litros": 1, "ml": 0.001, "gal": 3.78541, "galon": 3.78541,
          "galón": 3.78541, "taza": 0.24, "tazas": 0.24}
FAMILIES = {"longitud": LENGTH, "masa": MASS, "volumen": VOLUME}
UNIT_RE = re.compile(r"^\s*(-?\d+(?:[.,]\d+)?)\s*([a-zA-Z°áéíóú]+)\s*(?:a|to|en|->)\s*([a-zA-Z°áéíóú]+)\s*$", re.I)


def convert_units(text: str) -> str | None:
    m = UNIT_RE.match(text)
    if not m:
        return None
    value = float(m.group(1).replace(",", "."))
    src, dst = m.group(2).lower(), m.group(3).lower()

    # Temperatura (no es lineal con factor)
    temp = {"c", "°c", "celsius", "f", "°f", "fahrenheit", "k", "kelvin"}
    if src in temp and dst in temp:
        s = src.lstrip("°")[0]
        d = dst.lstrip("°")[0]
        c = value if s == "c" else (value - 32) * 5 / 9 if s == "f" else value - 273.15
        out = c if d == "c" else c * 9 / 5 + 32 if d == "f" else c + 273.15
        return f"🔁 <b>{value:g}°{s.upper()}</b> = <b>{out:.2f}°{d.upper()}</b>"

    for fam in FAMILIES.values():
        if src in fam and dst in fam:
            out = value * fam[src] / fam[dst]
            return f"🔁 <b>{value:g} {src}</b> = <b>{out:,.4g} {dst}</b>"
    return "⚠️ No reconozco esas unidades. Ejemplos: <code>100 km a mi</code>, <code>5 kg a lb</code>, <code>30 C a F</code>."


# ── Conversor de monedas (frankfurter.app, tasas del BCE, sin llave) ─────
async def convert_currency(text: str) -> str | None:
    m = UNIT_RE.match(text)
    if not m:
        return None
    amount = float(m.group(1).replace(",", "."))
    src, dst = m.group(2).upper(), m.group(3).upper()
    if len(src) != 3 or len(dst) != 3:
        return None
    st, data = await http.get_json("https://api.frankfurter.app/latest",
                                   params={"amount": amount, "from": src, "to": dst})
    if st != 200 or not isinstance(data, dict) or "rates" not in data or dst not in data.get("rates", {}):
        return None
    out = data["rates"][dst]
    return (f"💱 <b>{amount:,.2f} {src}</b> = <b>{out:,.2f} {dst}</b>\n"
            f"<i>Tasa del {data.get('date', '')} · Banco Central Europeo</i>")


# ── Traductor (MyMemory, gratis, sin llave) ──────────────────────────────
async def translate(text: str, target: str, source: str = "autodetect") -> str:
    text = text.strip()[:450]
    pair = f"{source}|{target}" if source != "autodetect" else f"es|{target}" if target != "es" else "en|es"
    st, data = await http.get_json("https://api.mymemory.translated.net/get",
                                   params={"q": text, "langpair": pair})
    if st != 200 or not isinstance(data, dict):
        return "⚠️ El traductor no respondió. Intenta más tarde."
    out = (data.get("responseData") or {}).get("translatedText")
    if not out:
        return "⚠️ No se pudo traducir."
    return join_blocks(header("🌐", f"Traducción → {target.upper()}"),
                       f"<b>Original</b>\n{esc(text)}",
                       f"<b>Traducción</b>\n{esc(out)}")


# ── Verificador de security.txt ──────────────────────────────────────────
async def security_txt(domain: str) -> str:
    head = header("📋", "security.txt", domain)
    for path in (f"https://{domain}/.well-known/security.txt", f"https://{domain}/security.txt"):
        res = await http.safe_fetch(path)
        if res.get("error") or res.get("status") != 200:
            continue
        body = res["body"].decode("utf-8", "ignore")
        if "<html" in body[:400].lower() or ":" not in body:
            continue
        fields = {}
        for line in body.splitlines():
            if line.strip().startswith("#") or ":" not in line:
                continue
            k, _, v = line.partition(":")
            fields.setdefault(k.strip().title(), v.strip())
        rows = [(k, v[:60]) for k, v in fields.items()
                if k in ("Contact", "Expires", "Encryption", "Policy", "Preferred-Languages", "Canonical")]
        return join_blocks(head, "🟢 <b>Tiene security.txt</b>", block("Campos", rows),
                           block("Ubicación", [code(path)]))
    return join_blocks(head, "🟠 <b>No encontré security.txt</b>",
                       "Es un archivo que indica a investigadores a dónde reportar fallos de seguridad.\n"
                       "Colócalo en <code>/.well-known/security.txt</code> con al menos un campo "
                       "<code>Contact:</code>.")
