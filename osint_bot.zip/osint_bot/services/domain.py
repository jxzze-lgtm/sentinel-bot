"""Análisis de dominios: WHOIS, DNS, correo (SPF/DMARC), certificados y cabeceras."""
import asyncio
from datetime import datetime, timezone

import dns.asyncresolver
import dns.exception
import whois

from services import http
from utils import block, header, join_blocks, code

SECURITY_HEADERS = {
    "strict-transport-security": "HSTS",
    "content-security-policy": "CSP",
    "x-frame-options": "X-Frame-Options",
    "x-content-type-options": "X-Content-Type-Options",
    "referrer-policy": "Referrer-Policy",
}

resolver = dns.asyncresolver.Resolver()
resolver.lifetime = 6
resolver.timeout = 3


async def dns_records(name: str, rtype: str) -> list[str]:
    try:
        ans = await resolver.resolve(name, rtype)
        return [r.to_text().strip('"') for r in ans]
    except (dns.exception.DNSException, Exception):
        return []


def _first(v):
    if isinstance(v, list):
        return v[0] if v else None
    return v


def _date(v) -> str | None:
    v = _first(v)
    if isinstance(v, datetime):
        return v.strftime("%Y-%m-%d")
    return str(v) if v else None


async def get_whois(domain: str) -> dict:
    try:
        w = await asyncio.wait_for(asyncio.to_thread(whois.whois, domain), timeout=20)
    except Exception:
        return {}
    created = _first(w.get("creation_date"))
    age_days = None
    if isinstance(created, datetime):
        c = created if created.tzinfo else created.replace(tzinfo=timezone.utc)
        age_days = (datetime.now(timezone.utc) - c).days
    return {
        "registrar": _first(w.get("registrar")),
        "created": _date(w.get("creation_date")),
        "expires": _date(w.get("expiration_date")),
        "updated": _date(w.get("updated_date")),
        "country": _first(w.get("country")),
        "org": _first(w.get("org")),
        "age_days": age_days,
    }


async def crtsh_subdomains(domain: str, limit: int = 25) -> tuple[int, list[str]]:
    status, data = await http.get_json(
        "https://crt.sh/", params={"q": f"%.{domain}", "output": "json"}, timeout=30
    )
    if status != 200 or not isinstance(data, list):
        return -1, []
    names: set[str] = set()
    for row in data:
        for n in str(row.get("name_value", "")).split("\n"):
            n = n.strip().lower().lstrip("*.")
            if n.endswith(domain) and n != domain:
                names.add(n)
    ordered = sorted(names)
    return len(ordered), ordered[:limit]


async def http_profile(domain: str) -> dict:
    res = await http.safe_fetch(f"https://{domain}", read_body=False)
    if res.get("error"):
        res = await http.safe_fetch(f"http://{domain}", read_body=False)
    if res.get("error"):
        return {"error": res["error"]}
    h = {k.lower(): v for k, v in res["headers"].items()}
    present = [label for key, label in SECURITY_HEADERS.items() if key in h]
    missing = [label for key, label in SECURITY_HEADERS.items() if key not in h]
    return {
        "status": res["status"],
        "final_url": res["final_url"],
        "server": h.get("server"),
        "powered_by": h.get("x-powered-by"),
        "present": present,
        "missing": missing,
        "https": res["final_url"].startswith("https://"),
    }


async def analyze(domain: str) -> str:
    who, a, aaaa, mx, ns, txt, dmarc, caa, crt, web = await asyncio.gather(
        get_whois(domain),
        dns_records(domain, "A"),
        dns_records(domain, "AAAA"),
        dns_records(domain, "MX"),
        dns_records(domain, "NS"),
        dns_records(domain, "TXT"),
        dns_records(f"_dmarc.{domain}", "TXT"),
        dns_records(domain, "CAA"),
        crtsh_subdomains(domain),
        http_profile(domain),
    )

    spf = next((t for t in txt if t.lower().startswith("v=spf1")), None)
    dmarc_rec = next((t for t in dmarc if t.lower().startswith("v=dmarc1")), None)
    dmarc_policy = None
    if dmarc_rec:
        for part in dmarc_rec.split(";"):
            k, _, v = part.strip().partition("=")
            if k.lower() == "p":
                dmarc_policy = v

    # Señales de alerta
    flags = []
    if who.get("age_days") is not None and who["age_days"] < 30:
        flags.append(f"⚠️ Dominio muy nuevo ({who['age_days']} días)")
    if not a and not aaaa:
        flags.append("⚠️ No resuelve a ninguna IP")
    if mx and not spf:
        flags.append("⚠️ Recibe correo pero no tiene SPF")
    if mx and not dmarc_rec:
        flags.append("⚠️ Sin DMARC: es fácil suplantar sus correos")
    elif dmarc_policy == "none":
        flags.append("ℹ️ DMARC en modo monitor (p=none)")
    if isinstance(web, dict) and web.get("status") and not web.get("https"):
        flags.append("⚠️ El sitio no fuerza HTTPS")

    reg = block("Registro", [
        ("Registrador", who.get("registrar")),
        ("Creado", who.get("created")),
        ("Expira", who.get("expires")),
        ("Antigüedad", f"{who['age_days']} días" if who.get("age_days") is not None else None),
        ("País", who.get("country")),
    ]) or block("Registro", ["<i>WHOIS no disponible (privacidad o TLD sin WHOIS)</i>"])

    dns_block = block("DNS", [
        ("A", ", ".join(a[:4])) if a else None,
        ("AAAA", ", ".join(aaaa[:2])) if aaaa else None,
        ("NS", ", ".join(n.rstrip(".") for n in ns[:4])) if ns else None,
        ("MX", ", ".join(m.split()[-1].rstrip(".") for m in mx[:3])) if mx else None,
        ("CAA", ", ".join(caa[:2])) if caa else None,
    ])

    mail = block("Correo", [
        ("SPF", spf[:80] if spf else "no configurado"),
        ("DMARC", f"p={dmarc_policy}" if dmarc_policy else "no configurado"),
    ])

    if isinstance(web, dict) and not web.get("error"):
        web_block = block("Web", [
            ("Estado", web["status"]),
            ("Servidor", web.get("server")),
            ("Tecnología", web.get("powered_by")),
            ("Seguridad", " ".join(f"✓{p}" for p in web["present"]) or "ninguna cabecera"),
            ("Faltan", ", ".join(web["missing"]) if web["missing"] else None),
        ])
    else:
        web_block = block("Web", ["<i>Sin respuesta HTTP</i>"])

    total, subs = crt
    if total == -1:
        crt_block = block("Certificados (crt.sh)", ["<i>crt.sh no respondió, intenta más tarde</i>"])
    elif total == 0:
        crt_block = block("Certificados (crt.sh)", ["Sin subdominios registrados"])
    else:
        rows = [code(s) for s in subs]
        if total > len(subs):
            rows.append(f"<i>… y {total - len(subs)} más</i>")
        crt_block = block(f"Subdominios en certificados · {total}", rows)

    alerts = block("Observaciones", flags) if flags else "🟢 <b>Sin observaciones relevantes</b>"

    return join_blocks(header("🌐", "Análisis de dominio", domain), reg, dns_block, mail, web_block,
                       crt_block, alerts)
