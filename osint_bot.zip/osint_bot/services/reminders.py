"""Interpreta expresiones de fecha/hora en español para los recordatorios.

Trabaja en hora local del servidor (systemd fija TZ=America/Hermosillo) y devuelve
un timestamp epoch, que es independiente de zona horaria.
"""
import re
from datetime import datetime, timedelta

WEEKDAYS = {"lunes": 0, "martes": 1, "miercoles": 2, "miércoles": 2, "jueves": 3,
            "viernes": 4, "sabado": 5, "sábado": 5, "domingo": 6}
REL_UNITS = {"m": "minutes", "min": "minutes", "minuto": "minutes", "minutos": "minutes",
             "h": "hours", "hora": "hours", "horas": "hours",
             "d": "days", "dia": "days", "día": "days", "dias": "days", "días": "days",
             "semana": "weeks", "semanas": "weeks"}


def _time(s: str, default=(9, 0)) -> tuple[int, int]:
    m = re.search(r"(\d{1,2})[:\.h](\d{2})", s)
    if m:
        return int(m.group(1)), int(m.group(2))
    m = re.search(r"\b(\d{1,2})\s*(am|pm)\b", s, re.I)
    if m:
        h = int(m.group(1)) % 12 + (12 if m.group(2).lower() == "pm" else 0)
        return h, 0
    return default


def parse(text: str) -> tuple[datetime, str] | None:
    """Devuelve (fecha_hora, texto_del_recordatorio) o None si no reconoce la fecha."""
    text = text.strip()
    now = datetime.now()
    low = text.lower()

    # "en 30m ..." / "en 2 horas ..."
    m = re.match(r"^en\s+(\d+)\s*([a-záí]+)\s+(.+)$", low, re.I)
    if m:
        qty, unit = int(m.group(1)), m.group(2)
        key = REL_UNITS.get(unit)
        if key:
            due = now + timedelta(**{key: qty})
            body = text[m.end(2):].strip()
            return due, body

    # "mañana [hora] ..." / "hoy [hora] ..."
    m = re.match(r"^(mañana|manana|hoy|pasado mañana|pasado manana)\s+(.+)$", low, re.I)
    if m:
        word = m.group(1)
        offset = 0 if word == "hoy" else 2 if "pasado" in word else 1
        h, mi = _time(low)
        due = (now + timedelta(days=offset)).replace(hour=h, minute=mi, second=0, microsecond=0)
        body = re.sub(r"^\S+\s+(\d{1,2}[:\.h]\d{2}\s+|\d{1,2}\s*(am|pm)\s+)?", "", text, flags=re.I)
        return due, body.strip()

    # día de la semana: "viernes 9:00 ..."
    m = re.match(r"^(" + "|".join(WEEKDAYS) + r")\s+(.+)$", low, re.I)
    if m:
        target = WEEKDAYS[m.group(1)]
        delta = (target - now.weekday()) % 7
        delta = delta or 7  # el próximo, no hoy
        h, mi = _time(low)
        due = (now + timedelta(days=delta)).replace(hour=h, minute=mi, second=0, microsecond=0)
        body = re.sub(r"^\S+\s+(\d{1,2}[:\.h]\d{2}\s+|\d{1,2}\s*(am|pm)\s+)?", "", text, flags=re.I)
        return due, body.strip()

    # fecha explícita "2026-10-25 09:00 ..." o "25/10 14:00 ..."
    m = re.match(r"^(\d{4})-(\d{2})-(\d{2})\s+(.+)$", text)
    if m:
        y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
        h, mi = _time(m.group(4))
        try:
            due = datetime(y, mo, d, h, mi)
        except ValueError:
            return None
        body = re.sub(r"^\d{1,2}[:\.h]\d{2}\s+", "", m.group(4)).strip()
        return due, body
    m = re.match(r"^(\d{1,2})/(\d{1,2})(?:/(\d{2,4}))?\s+(.+)$", text)
    if m:
        d, mo = int(m.group(1)), int(m.group(2))
        y = int(m.group(3) or now.year)
        y += 2000 if y < 100 else 0
        h, mi = _time(m.group(4))
        try:
            due = datetime(y, mo, d, h, mi)
        except ValueError:
            return None
        if due < now:
            due = due.replace(year=due.year + 1)
        body = re.sub(r"^\d{1,2}[:\.h]\d{2}\s+", "", m.group(4)).strip()
        return due, body

    return None
