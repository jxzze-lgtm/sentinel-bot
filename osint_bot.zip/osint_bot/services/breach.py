"""Auditoría de filtraciones (Have I Been Pwned) para correos verificados del propio usuario."""
import asyncio
import random
import smtplib
from email.message import EmailMessage

from config import settings
from services import http
from utils import block, code, esc, header, join_blocks

HIBP = "https://haveibeenpwned.com/api/v3"


async def breaches_for(email: str) -> tuple[int, list[dict]]:
    """Devuelve (status, filtraciones). status 404 = sin filtraciones."""
    st, data = await http.get_json(
        f"{HIBP}/breachedaccount/{email}",
        headers={"hibp-api-key": settings.hibp_key, "user-agent": "SentinelOSINT"},
        params={"truncateResponse": "false"},
    )
    if st == 404:
        return 404, []
    if st == 200 and isinstance(data, list):
        return 200, data
    return st, []


def format_report(email: str, breaches: list[dict]) -> str:
    if not breaches:
        return join_blocks(header("🔐", "Auditoría de filtraciones", email),
                           "🟢 <b>No aparece en filtraciones conocidas.</b>")
    breaches = sorted(breaches, key=lambda b: b.get("BreachDate", ""), reverse=True)
    exposed: set[str] = set()
    rows = []
    for b in breaches[:15]:
        exposed.update(b.get("DataClasses", []))
        rows.append(f"{code(b.get('BreachDate', '')[:7])} <b>{esc(b.get('Title', b.get('Name')))}</b>"
                    f" · {esc(', '.join(b.get('DataClasses', [])[:3]))}")
    if len(breaches) > 15:
        rows.append(f"<i>… y {len(breaches) - 15} más</i>")
    tips = ["Cambia la contraseña en esos servicios y en cualquiera donde la hayas repetido",
            "Activa verificación en dos pasos (de preferencia con app, no SMS)",
            "Usa un gestor de contraseñas para tener una distinta por sitio"]
    if "Passwords" in exposed:
        tips.insert(0, "⚠️ Se filtraron contraseñas: cámbialas hoy mismo")
    return join_blocks(
        header("🔐", "Auditoría de filtraciones", email),
        f"🔴 <b>Aparece en {len(breaches)} filtraciones</b>",
        block("Filtraciones", rows),
        block("Datos expuestos", [esc(", ".join(sorted(exposed)))]),
        block("Qué hacer", tips),
    )


def new_code() -> str:
    return f"{random.SystemRandom().randint(0, 999999):06d}"


def _send_code_sync(email: str, code_: str) -> None:
    msg = EmailMessage()
    msg["Subject"] = f"Tu código de verificación Sentinel: {code_}"
    msg["From"] = settings.smtp_from or settings.smtp_user
    msg["To"] = email
    msg.set_content(
        f"Tu código es: {code_}\n\n"
        "Lo pediste desde el bot Sentinel OSINT para confirmar que este correo es tuyo.\n"
        "Si no fuiste tú, ignora este mensaje."
    )
    with smtplib.SMTP(settings.smtp_host, settings.smtp_port, timeout=20) as s:
        s.starttls()
        s.login(settings.smtp_user, settings.smtp_password)
        s.send_message(msg)


async def send_code(email: str, code_: str) -> bool:
    try:
        await asyncio.to_thread(_send_code_sync, email, code_)
        return True
    except Exception:
        return False
