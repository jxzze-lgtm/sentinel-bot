"""Análisis de IPs públicas: red, puertos expuestos, listas negras y reputación."""
import asyncio
import ipaddress

import dns.reversename

from config import settings
from services import http
from services.domain import dns_records
from utils import block, header, join_blocks, verdict

DNSBLS = {
    "bl.spamcop.net": "SpamCop",
    "b.barracudacentral.org": "Barracuda",
    "zen.spamhaus.org": "Spamhaus",
}


async def geo(ip: str) -> dict:
    status, data = await http.get_json(f"https://ipinfo.io/{ip}/json")
    return data if status == 200 and isinstance(data, dict) else {}


async def internetdb(ip: str) -> dict:
    """Shodan InternetDB: gratuito y sin llave."""
    status, data = await http.get_json(f"https://internetdb.shodan.io/{ip}")
    return data if status == 200 and isinstance(data, dict) else {}


async def reverse_dns(ip: str) -> str | None:
    rev = dns.reversename.from_address(ip).to_text()
    res = await dns_records(rev, "PTR")
    return res[0].rstrip(".") if res else None


async def dnsbl(ip: ipaddress.IPv4Address) -> list[str]:
    if ip.version != 4:
        return []
    rev = ".".join(reversed(str(ip).split(".")))

    async def check(zone: str, name: str) -> str | None:
        res = await dns_records(f"{rev}.{zone}", "A")
        # 127.255.255.x = respuesta de error de Spamhaus (resolver público), no es listado
        hits = [r for r in res if r.startswith("127.") and not r.startswith("127.255.255.")]
        return name if hits else None

    results = await asyncio.gather(*(check(z, n) for z, n in DNSBLS.items()))
    return [r for r in results if r]


async def abuseipdb(ip: str) -> dict:
    if not settings.abuseipdb_key:
        return {}
    status, data = await http.get_json(
        "https://api.abuseipdb.com/api/v2/check",
        headers={"Key": settings.abuseipdb_key, "Accept": "application/json"},
        params={"ipAddress": ip, "maxAgeInDays": 90},
    )
    return (data or {}).get("data", {}) if status == 200 else {}


async def analyze(ip: ipaddress._BaseAddress) -> str:
    s = str(ip)
    g, idb, ptr, bl, abuse = await asyncio.gather(geo(s), internetdb(s), reverse_dns(s), dnsbl(ip), abuseipdb(s))

    net = block("Red", [
        ("ASN / Org", g.get("org")),
        ("Ubicación aprox.", ", ".join(x for x in (g.get("city"), g.get("region"), g.get("country")) if x)),
        ("rDNS", ptr),
        ("Hostnames", ", ".join(idb.get("hostnames", [])[:4]) if idb.get("hostnames") else None),
    ])

    ports = idb.get("ports", [])
    vulns = idb.get("vulns", [])
    exposure = block("Exposición (Shodan InternetDB)", [
        ("Puertos", ", ".join(map(str, ports[:20])) if ports else "ninguno visto"),
        ("Etiquetas", ", ".join(idb.get("tags", []))) if idb.get("tags") else None,
        ("CVEs asociadas", ", ".join(vulns[:8]) + (f" (+{len(vulns) - 8})" if len(vulns) > 8 else ""))
        if vulns else None,
    ])

    rep_rows = [("Listas negras", ", ".join(bl) if bl else "no listada")]
    if abuse:
        rep_rows.append(("AbuseIPDB", f"{abuse.get('abuseConfidenceScore', 0)}% · "
                                      f"{abuse.get('totalReports', 0)} reportes"))
    reputation = block("Reputación", rep_rows)

    score = len(bl) * 2 + (2 if vulns else 0) + (abuse.get("abuseConfidenceScore", 0) // 25 if abuse else 0)
    level = "ok" if score == 0 else "low" if score <= 2 else "mid" if score <= 4 else "high"

    return join_blocks(header("📍", "Análisis de IP", s), net, exposure, reputation, verdict(level))
