"""Monitoreo de marca: dominios parecidos (typosquatting) y certificados recién emitidos."""
import asyncio
from datetime import datetime, timedelta, timezone

from services import http
from services.domain import dns_records
from utils import block, code, header, join_blocks

KEYBOARD = {
    "q": "wa", "w": "qes", "e": "wrd", "r": "etf", "t": "ryg", "y": "tuh", "u": "yij", "i": "uok",
    "o": "ipl", "p": "o", "a": "qsz", "s": "awdz", "d": "sefx", "f": "drgc", "g": "fthv", "h": "gyjb",
    "j": "hukn", "k": "jilm", "l": "kop", "z": "asx", "x": "zsdc", "c": "xdfv", "v": "cfgb", "b": "vghn",
    "n": "bhjm", "m": "njk",
}
HOMOGLYPHS = {"o": "0", "l": "1i", "i": "1l", "e": "3", "a": "4", "s": "5", "m": "rn", "w": "vv", "g": "q"}
TLDS = ["com", "net", "org", "co", "io", "app", "info", "online", "site", "shop", "xyz", "mx", "com.mx"]
WORDS = ["login", "secure", "app", "online", "soporte", "support", "pay", "cuenta", "verify"]


def permutations(domain: str, max_items: int = 300) -> list[str]:
    name, _, tld = domain.partition(".")
    out: set[str] = set()

    def add(n: str, t: str = tld):
        if n and n != name and len(n) > 1 and not n.startswith("-") and not n.endswith("-"):
            out.add(f"{n}.{t}")

    for i in range(len(name)):
        add(name[:i] + name[i + 1:])                                  # omisión
        add(name[:i] + name[i] + name[i:])                            # repetición
        if i < len(name) - 1:
            add(name[:i] + name[i + 1] + name[i] + name[i + 2:])      # transposición
            add(name[:i + 1] + "-" + name[i + 1:])                    # guion
        for c in KEYBOARD.get(name[i], ""):
            add(name[:i] + c + name[i + 1:])                          # tecla vecina
        for c in HOMOGLYPHS.get(name[i], ""):
            add(name[:i] + c + name[i + 1:])                          # homoglifo
    for t in TLDS:
        if t != tld:
            out.add(f"{name}.{t}")                                    # cambio de TLD
    for w in WORDS:
        add(f"{name}-{w}")
        add(f"{w}-{name}")
    out.discard(domain)
    return sorted(out)[:max_items]


async def resolve_candidates(candidates: list[str], concurrency: int = 40) -> list[dict]:
    sem = asyncio.Semaphore(concurrency)

    async def check(d: str) -> dict | None:
        async with sem:
            a = await dns_records(d, "A")
            if not a:
                return None
            mx = await dns_records(d, "MX")
            return {"domain": d, "ip": a[0], "mx": bool(mx)}

    res = await asyncio.gather(*(check(c) for c in candidates))
    return [r for r in res if r]


async def recent_certs(keyword: str, own_domain: str, days: int = 7) -> list[str]:
    st, data = await http.get_json("https://crt.sh/", params={"q": f"%{keyword}%", "output": "json"},
                                   timeout=45)
    if st != 200 or not isinstance(data, list):
        return []
    since = datetime.now(timezone.utc) - timedelta(days=days)
    names: set[str] = set()
    for row in data:
        try:
            nb = datetime.fromisoformat(row["not_before"]).replace(tzinfo=timezone.utc)
        except Exception:
            continue
        if nb < since:
            continue
        for n in str(row.get("name_value", "")).split("\n"):
            n = n.strip().lower().lstrip("*.")
            if n and not (n == own_domain or n.endswith("." + own_domain)):
                names.add(n)
    return sorted(names)[:30]


async def scan(domain: str) -> dict:
    keyword = domain.split(".")[0]
    candidates = permutations(domain)
    registered, certs = await asyncio.gather(resolve_candidates(candidates), recent_certs(keyword, domain))
    return {"domain": domain, "checked": len(candidates), "registered": registered, "certs": certs}


def format_scan(result: dict, new_only: set[str] | None = None) -> str:
    reg = result["registered"]
    if new_only is not None:
        reg = [r for r in reg if r["domain"] in new_only]
    rows = [f"{code(r['domain'])} → {code(r['ip'])}" + (" · 📬 recibe correo" if r["mx"] else "")
            for r in reg[:25]]
    if len(reg) > 25:
        rows.append(f"<i>… y {len(reg) - 25} más</i>")
    certs = [code(c) for c in result["certs"][:15]]
    title = "Nuevos dominios parecidos" if new_only is not None else f"Dominios parecidos activos · {len(reg)}"
    return join_blocks(
        header("🛡", "Monitoreo de marca", result["domain"]),
        block("Escaneo", [("Variantes revisadas", result["checked"]), ("Registradas", len(result["registered"]))]),
        block(title, rows) if rows else "🟢 Ninguna variante registrada.",
        block("Certificados recientes con tu nombre (7 días)", certs) if certs else "",
        "<i>📬 = tiene MX, puede usarse para enviar phishing por correo. "
        "Analiza cualquiera con 🌐 Dominio.</i>" if rows else "",
    )
