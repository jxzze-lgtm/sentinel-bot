"""Archivado de evidencia: copia local con hash SHA-256 y sello de tiempo UTC + Wayback Machine."""
import hashlib
import json
import re
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlparse

import aiohttp

from config import settings
from services import http
from utils import block, code, header, human_size, join_blocks


async def wayback_save(url: str) -> str | None:
    try:
        async with http.session().get(f"https://web.archive.org/save/{url}", allow_redirects=False,
                                      timeout=aiohttp.ClientTimeout(total=90)) as r:
            loc = r.headers.get("Content-Location") or r.headers.get("Location")
            if loc:
                return loc if loc.startswith("http") else f"https://web.archive.org{loc}"
    except Exception:
        pass
    # Respaldo: última copia disponible
    st, data = await http.get_json("https://archive.org/wayback/available", params={"url": url})
    snap = (data or {}).get("archived_snapshots", {}).get("closest", {})
    return snap.get("url") if st == 200 else None


async def capture(url: str, user_id: int) -> tuple[str, Path | None, Path | None]:
    """Devuelve (reporte, ruta_html, ruta_recibo)."""
    now = datetime.now(timezone.utc)
    res = await http.safe_fetch(url, max_bytes=15 * 1024 * 1024)
    wayback = await wayback_save(url)

    if res.get("error"):
        text = join_blocks(header("🗄", "Archivo de evidencia", url[:120]),
                           block("Copia local", [f"<i>No se pudo descargar: {res['error']}</i>"]),
                           block("Wayback Machine", [wayback or "no disponible"]))
        return text, None, None

    body: bytes = res["body"]
    digest = hashlib.sha256(body).hexdigest()
    host = re.sub(r"[^a-z0-9.-]", "_", (urlparse(url).hostname or "sitio"))
    stamp = now.strftime("%Y%m%dT%H%M%SZ")
    folder = settings.evidence_dir / str(user_id)
    folder.mkdir(parents=True, exist_ok=True)
    html_path = folder / f"{stamp}_{host}.html"
    html_path.write_bytes(body)

    receipt = {
        "requested_url": url,
        "final_url": res["final_url"],
        "redirect_chain": res["chain"],
        "http_status": res["status"],
        "captured_at_utc": now.isoformat(),
        "sha256": digest,
        "size_bytes": len(body),
        "response_headers": res["headers"],
        "wayback_snapshot": wayback,
        "tool": "Sentinel OSINT",
    }
    receipt_path = folder / f"{stamp}_{host}_recibo.json"
    receipt_path.write_text(json.dumps(receipt, indent=2, ensure_ascii=False), encoding="utf-8")

    text = join_blocks(
        header("🗄", "Evidencia archivada", url[:120]),
        block("Captura", [
            ("Fecha UTC", now.strftime("%Y-%m-%d %H:%M:%S")),
            ("Estado HTTP", res["status"]),
            ("Tamaño", human_size(len(body))),
            ("URL final", res["final_url"][:80]) if res["final_url"] != url else None,
        ]),
        block("Integridad", [f"SHA-256 {code(digest)}"]),
        block("Wayback Machine", [f'<a href="{wayback}">Ver copia pública</a>' if wayback else "no disponible"]),
        "<i>Guarda el HTML y el recibo juntos: si el hash coincide, la copia no fue alterada.</i>",
    )
    return text, html_path, receipt_path
