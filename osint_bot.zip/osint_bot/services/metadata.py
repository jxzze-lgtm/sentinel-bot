"""Lectura y limpieza de metadatos en imágenes, PDF y documentos Word."""
import io

from PIL import ExifTags, Image, ImageOps
from pypdf import PdfReader, PdfWriter

from utils import block, header, human_size, join_blocks

INTERESTING_EXIF = {"Make", "Model", "Software", "DateTime", "DateTimeOriginal", "Artist", "Copyright",
                    "LensModel", "BodySerialNumber", "HostComputer", "ImageDescription", "OwnerName"}
LABELS = {"Make": "Marca", "Model": "Modelo", "Software": "Software", "DateTime": "Fecha",
          "DateTimeOriginal": "Fecha de captura", "Artist": "Autor", "Copyright": "Copyright",
          "LensModel": "Lente", "BodySerialNumber": "N.º de serie", "HostComputer": "Equipo",
          "ImageDescription": "Descripción", "OwnerName": "Propietario"}


def _gps_to_deg(values, ref) -> float | None:
    try:
        d, m, s = (float(x) for x in values)
        deg = d + m / 60 + s / 3600
        return -deg if ref in ("S", "W") else deg
    except Exception:
        return None


def image_meta(data: bytes) -> dict:
    img = Image.open(io.BytesIO(data))
    exif = img.getexif()
    found = {}
    for tag_id, value in exif.items():
        name = ExifTags.TAGS.get(tag_id, str(tag_id))
        if name in INTERESTING_EXIF:
            found[LABELS.get(name, name)] = str(value)[:60]
    try:
        sub = exif.get_ifd(ExifTags.IFD.Exif)
        for tag_id, value in sub.items():
            name = ExifTags.TAGS.get(tag_id, str(tag_id))
            if name in INTERESTING_EXIF:
                found[LABELS.get(name, name)] = str(value)[:60]
    except Exception:
        pass
    gps = None
    try:
        g = exif.get_ifd(ExifTags.IFD.GPSInfo)
        if g:
            lat = _gps_to_deg(g.get(2), g.get(1))
            lon = _gps_to_deg(g.get(4), g.get(3))
            if lat is not None and lon is not None:
                gps = (round(lat, 6), round(lon, 6))
    except Exception:
        pass
    return {"format": img.format, "size": f"{img.width}×{img.height}", "fields": found, "gps": gps,
            "total_tags": len(exif)}


MAX_DECODE_PIXELS = 30_000_000  # ~30 MP: por encima, decodificar podría agotar la RAM del servidor

# Segmentos JPEG que se conservan: APP0 (JFIF), APP2 solo si es perfil de color ICC, APP14 (Adobe)
_KEEP_APP = {0xE0, 0xEE}


def _orientation_exif(orientation: int) -> bytes:
    """Bloque EXIF mínimo con solo la orientación (para que la foto no salga girada)."""
    ex = Image.Exif()
    ex[0x0112] = orientation
    payload = ex.tobytes()
    if not payload.startswith(b"Exif\x00\x00"):
        payload = b"Exif\x00\x00" + payload
    return b"\xff\xe1" + (len(payload) + 2).to_bytes(2, "big") + payload


def strip_jpeg(data: bytes, orientation: int = 1) -> bytes:
    """Quita EXIF, GPS, XMP, IPTC y comentarios de un JPEG SIN decodificar la imagen.

    Copia los bytes comprimidos tal cual: sin pérdida de calidad y casi sin usar memoria.
    """
    if not data.startswith(b"\xff\xd8"):
        raise ValueError("No es un JPEG válido")
    out = bytearray(b"\xff\xd8")
    if orientation and orientation != 1:
        out += _orientation_exif(orientation)
    i, n = 2, len(data)
    while i < n:
        if data[i] != 0xFF:
            raise ValueError("Estructura JPEG inesperada")
        while i < n and data[i] == 0xFF:  # bytes de relleno
            i += 1
        marker = data[i]
        i += 1
        if marker == 0xD9:  # EOI
            out += b"\xff\xd9"
            break
        if marker == 0x01 or 0xD0 <= marker <= 0xD7:  # marcadores sin longitud
            out += bytes((0xFF, marker))
            continue
        length = int.from_bytes(data[i:i + 2], "big")
        segment = data[i + 2:i + length]
        if marker == 0xDA:  # SOS: a partir de aquí son los datos de la imagen, se copian completos
            out += bytes((0xFF, marker)) + data[i:]
            break
        keep = (
            marker in _KEEP_APP
            or (marker == 0xE2 and segment.startswith(b"ICC_PROFILE"))
            or not (0xE0 <= marker <= 0xEF or marker == 0xFE)  # tablas, SOF, DHT, DQT, etc.
        )
        if keep:
            out += bytes((0xFF, marker)) + data[i:i + length]
        i += length
    return bytes(out)


def clean_image(data: bytes, fmt: str) -> bytes:
    img = Image.open(io.BytesIO(data))  # perezoso: todavía no decodifica píxeles
    orientation = img.getexif().get(0x0112, 1)
    if fmt == "JPEG":
        return strip_jpeg(data, orientation)

    if img.width * img.height > MAX_DECODE_PIXELS:
        raise MemoryError("Imagen demasiado grande para procesarla en este servidor")
    if orientation != 1:
        img = ImageOps.exif_transpose(img)
    if img.mode not in ("RGB", "RGBA", "L", "LA"):
        img = img.convert("RGBA" if "A" in img.getbands() or img.mode == "P" else "RGB")
    clean = Image.frombytes(img.mode, img.size, img.tobytes())  # solo píxeles, cero metadatos
    del img
    out = io.BytesIO()
    clean.save(out, fmt if fmt in ("PNG", "WEBP") else "PNG")
    return out.getvalue()


def pdf_meta(data: bytes) -> dict:
    r = PdfReader(io.BytesIO(data))
    info = r.metadata or {}
    fields = {k.lstrip("/"): str(v)[:60] for k, v in info.items() if v}
    xmp = "/Metadata" in r.trailer["/Root"]
    return {"pages": len(r.pages), "fields": fields, "xmp": xmp}


def clean_pdf(data: bytes) -> bytes:
    r = PdfReader(io.BytesIO(data))
    w = PdfWriter()
    for page in r.pages:
        w.add_page(page)
    w.add_metadata({"/Producer": ""})
    out = io.BytesIO()
    w.write(out)
    return out.getvalue()


def docx_meta(data: bytes) -> dict:
    from docx import Document
    cp = Document(io.BytesIO(data)).core_properties
    fields = {
        "Autor": cp.author, "Última edición por": cp.last_modified_by, "Creado": cp.created,
        "Modificado": cp.modified, "Revisión": cp.revision, "Título": cp.title,
        "Comentarios": cp.comments, "Empresa/Categoría": cp.category,
    }
    return {"fields": {k: str(v)[:60] for k, v in fields.items() if v}}


def clean_docx(data: bytes) -> bytes:
    from datetime import datetime

    from docx import Document
    doc = Document(io.BytesIO(data))
    cp = doc.core_properties
    for attr in ("author", "last_modified_by", "title", "subject", "comments", "category",
                 "keywords", "content_status", "identifier", "language", "version"):
        setattr(cp, attr, "")
    cp.revision = 1
    epoch = datetime(2000, 1, 1)
    cp.created = epoch
    cp.modified = epoch
    cp.last_printed = epoch
    out = io.BytesIO()
    doc.save(out)
    return out.getvalue()


def kind_of(filename: str, data: bytes) -> str | None:
    name = filename.lower()
    if data.startswith(b"%PDF"):
        return "pdf"
    if name.endswith(".docx") and data.startswith(b"PK"):
        return "docx"
    try:
        Image.open(io.BytesIO(data)).verify()
        return "image"
    except Exception:
        return None


def analyze_and_clean(filename: str, data: bytes) -> tuple[str, bytes | None, str]:
    """Devuelve (reporte, archivo_limpio|None, nombre_limpio)."""
    kind = kind_of(filename, data)
    base = filename.rsplit(".", 1)[0] if "." in filename else filename
    ext = filename.rsplit(".", 1)[-1] if "." in filename else "bin"
    clean_name = f"{base}_limpio.{ext}"

    if kind == "image":
        m = image_meta(data)
        rows = [(k, v) for k, v in m["fields"].items()]
        gps_row = None
        if m["gps"]:
            lat, lon = m["gps"]
            gps_row = (f"📍 <b>Contiene ubicación GPS</b>: "
                       f"<a href=\"https://maps.google.com/?q={lat},{lon}\">{lat}, {lon}</a>")
        cleaned = clean_image(data, m["format"] or "PNG")
        if (m["format"] or "PNG") not in ("JPEG", "PNG", "WEBP"):
            clean_name = f"{base}_limpio.png"
        report = join_blocks(
            header("🧹", "Metadatos de imagen", filename[:60]),
            block("Archivo", [("Formato", m["format"]), ("Dimensiones", m["size"]),
                              ("Etiquetas EXIF", m["total_tags"])]),
            block("Datos encontrados", rows) if rows else "",
            gps_row or "",
            "✅ Te devuelvo una copia <b>sin metadatos</b>." if m["total_tags"] else "🟢 No tenía metadatos EXIF.",
        )
        return report, cleaned if m["total_tags"] else None, clean_name

    if kind == "pdf":
        m = pdf_meta(data)
        cleaned = clean_pdf(data)
        report = join_blocks(
            header("🧹", "Metadatos de PDF", filename[:60]),
            block("Archivo", [("Páginas", m["pages"]), ("Tamaño", human_size(len(data))),
                              ("XMP incrustado", "sí" if m["xmp"] else "no")]),
            block("Datos encontrados", list(m["fields"].items())) if m["fields"] else "Sin campos de información.",
            "✅ Te devuelvo una copia <b>sin metadatos</b>.",
        )
        return report, cleaned, clean_name

    if kind == "docx":
        m = docx_meta(data)
        cleaned = clean_docx(data)
        report = join_blocks(
            header("🧹", "Metadatos de Word", filename[:60]),
            block("Datos encontrados", list(m["fields"].items())) if m["fields"] else "Sin propiedades.",
            "✅ Te devuelvo una copia con las propiedades borradas.\n"
            "<i>Revisa también comentarios y control de cambios dentro del documento.</i>",
        )
        return report, cleaned, clean_name

    return ("⚠️ Formato no compatible. Envía una imagen (JPG, PNG, WebP, TIFF), un PDF o un .docx "
            "<b>como archivo</b> (📎 → Archivo) para que Telegram no lo comprima."), None, clean_name
