"""CVEs: consulta puntual y resumen diario por palabras clave (NVD + CISA KEV + EPSS)."""
import time
from datetime import datetime, timedelta, timezone

from config import settings
from services import http
from utils import block, code, esc, header, join_blocks

NVD = "https://services.nvd.nist.gov/rest/json/cves/2.0"
KEV_URL = "https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json"
_kev_cache: dict = {"ts": 0, "data": {}}

SEV_EMOJI = {"CRITICAL": "🔴", "HIGH": "🟠", "MEDIUM": "🟡", "LOW": "🟢"}


def _headers() -> dict:
    return {"apiKey": settings.nvd_key} if settings.nvd_key else {}


async def kev() -> dict:
    if time.time() - _kev_cache["ts"] > 6 * 3600 or not _kev_cache["data"]:
        st, data = await http.get_json(KEV_URL, timeout=40)
        if st == 200 and isinstance(data, dict):
            _kev_cache["data"] = {v["cveID"]: v for v in data.get("vulnerabilities", [])}
            _kev_cache["ts"] = time.time()
    return _kev_cache["data"]


async def epss(ids: list[str]) -> dict:
    if not ids:
        return {}
    st, data = await http.get_json("https://api.first.org/data/v1/epss", params={"cve": ",".join(ids[:50])})
    if st != 200 or not data:
        return {}
    return {row["cve"]: float(row["epss"]) for row in data.get("data", [])}


def _parse(item: dict) -> dict:
    c = item["cve"]
    desc = next((d["value"] for d in c.get("descriptions", []) if d["lang"] == "en"), "")
    score, sev = None, None
    for key in ("cvssMetricV40", "cvssMetricV31", "cvssMetricV30", "cvssMetricV2"):
        if c.get("metrics", {}).get(key):
            m = c["metrics"][key][0]
            score = m["cvssData"].get("baseScore")
            sev = m["cvssData"].get("baseSeverity") or m.get("baseSeverity")
            break
    return {
        "id": c["id"],
        "desc": desc,
        "score": score,
        "severity": (sev or "N/D").upper(),
        "published": c.get("published", "")[:10],
        "refs": [r["url"] for r in c.get("references", [])[:3]],
    }


async def lookup(cve_id: str) -> str:
    cve_id = cve_id.upper()
    st, data = await http.get_json(NVD, params={"cveId": cve_id}, headers=_headers(), timeout=40)
    if st != 200 or not data or not data.get("vulnerabilities"):
        return f"⚠️ No encontré {code(cve_id)} en NVD (código {st})."
    c = _parse(data["vulnerabilities"][0])
    k = (await kev()).get(cve_id)
    e = (await epss([cve_id])).get(cve_id)

    risk = block("Riesgo", [
        ("CVSS", f"{c['score']} · {c['severity']}" if c["score"] else "sin puntuación aún"),
        ("EPSS (prob. de explotación 30 días)", f"{e * 100:.2f}%" if e is not None else None),
        ("CISA KEV", f"⚠️ EXPLOTADA ACTIVAMENTE desde {k['dateAdded']}" if k else "no listada"),
        ("Ransomware", "sí" if k and k.get("knownRansomwareCampaignUse") == "Known" else None),
    ])
    refs = block("Referencias", [f'<a href="{esc(u)}">{esc(u[:60])}</a>' for u in c["refs"]])
    return join_blocks(
        header(SEV_EMOJI.get(c["severity"], "⚪️"), c["id"], f"Publicada {c['published']}"),
        risk,
        f"<b>Descripción</b>\n{esc(c['desc'][:900])}",
        refs,
    )


async def recent(keyword: str, hours: int = 24, limit: int = 8) -> list[dict]:
    end = datetime.now(timezone.utc)
    start = end - timedelta(hours=hours)
    fmt = "%Y-%m-%dT%H:%M:%S.000"
    st, data = await http.get_json(NVD, params={
        "keywordSearch": keyword,
        "pubStartDate": start.strftime(fmt),
        "pubEndDate": end.strftime(fmt),
        "resultsPerPage": 50,
    }, headers=_headers(), timeout=40)
    if st != 200 or not data:
        return []
    items = [_parse(v) for v in data.get("vulnerabilities", [])]
    items.sort(key=lambda x: x["score"] or 0, reverse=True)
    return items[:limit]


async def digest(keywords: list[str], hours: int = 24) -> str | None:
    """Resumen para un usuario. Devuelve None si no hay novedades."""
    kev_data = await kev()
    sections = []
    for kw in keywords:
        items = await recent(kw, hours)
        if not items:
            continue
        rows = []
        for c in items:
            tag = " · ⚠️KEV" if c["id"] in kev_data else ""
            rows.append(f"{SEV_EMOJI.get(c['severity'], '⚪️')} {code(c['id'])} "
                        f"{c['score'] or '—'}{tag}\n   {esc(c['desc'][:110])}…")
        sections.append(block(f"{kw} · {len(items)}", rows))
        if not settings.nvd_key:
            import asyncio
            await asyncio.sleep(6)  # NVD sin llave: máx. 5 peticiones / 30 s
    if not sections:
        return None
    return join_blocks(header("🛰", "Resumen de CVEs", f"Últimas {hours} h"), *sections,
                       "<i>Toca 🔎 Buscar CVE y pega un ID para ver el detalle.</i>")
