"""Automatización de PDF: firmar/sellar, marca de agua, proteger, comprimir y tablas → Excel."""
import io
import secrets
from datetime import datetime

from pypdf import PdfReader, PdfWriter


def _overlay(w: float, h: float, draw) -> bytes:
    """Crea un PDF de una página del tamaño (w,h) en puntos y ejecuta draw(pdf)."""
    from fpdf import FPDF
    pdf = FPDF(unit="pt", format=(w, h))
    pdf.add_page()
    pdf.set_auto_page_break(False)
    draw(pdf)
    return bytes(pdf.output())


def _stamp(reader: PdfReader, make_overlay) -> bytes:
    writer = PdfWriter()
    for page in reader.pages:
        w = float(page.mediabox.width)
        h = float(page.mediabox.height)
        overlay_bytes = make_overlay(w, h)
        if overlay_bytes:
            ov = PdfReader(io.BytesIO(overlay_bytes)).pages[0]
            page.merge_page(ov)
        writer.add_page(page)
    out = io.BytesIO()
    writer.write(out)
    return out.getvalue()


def new_folio() -> str:
    return f"{datetime.now():%Y%m%d}-{secrets.token_hex(3).upper()}"


def sign(data: bytes, signer: str, folio: str | None = None) -> tuple[bytes, str]:
    """Sella cada página con firma, fecha/hora y un folio único (abajo a la derecha)."""
    folio = folio or new_folio()
    stamp = f"Firmado por: {signer}"
    when = datetime.now().strftime("%Y-%m-%d %H:%M")

    def draw(w, h):
        def _d(pdf):
            bw, bh = 230, 56
            x, y = w - bw - 24, h - bh - 24
            pdf.set_fill_color(11, 15, 20)
            pdf.set_draw_color(57, 208, 180)
            pdf.set_line_width(1.2)
            pdf.rect(x, y, bw, bh, style="DF")
            pdf.set_text_color(236, 240, 244)
            pdf.set_font("helvetica", "B", 9)
            pdf.text(x + 12, y + 18, stamp[:40])
            pdf.set_font("helvetica", "", 8)
            pdf.set_text_color(139, 150, 164)
            pdf.text(x + 12, y + 33, f"Fecha: {when}")
            pdf.text(x + 12, y + 46, f"Folio: {folio}")
        return _overlay(w, h, _d)

    return _stamp(PdfReader(io.BytesIO(data)), draw), folio


def watermark(data: bytes, text: str) -> bytes:
    """Marca de agua diagonal, repetida y semitransparente, en todas las páginas."""
    def draw(w, h):
        def _d(pdf):
            pdf.set_font("helvetica", "B", 44)
            pdf.set_text_color(150, 150, 150)
            try:
                pdf.set_alpha(0.18)  # fpdf2 >= 2.7
            except Exception:
                pass
            step = 260
            for gy in range(0, int(h) + step, step):
                for gx in range(-int(h), int(w) + step, step):
                    with pdf.rotation(45, gx, gy):
                        pdf.text(gx, gy, text[:28])
        return _overlay(w, h, _d)

    return _stamp(PdfReader(io.BytesIO(data)), draw)


def protect(data: bytes, password: str) -> bytes:
    reader = PdfReader(io.BytesIO(data))
    if reader.is_encrypted:
        raise ValueError("El PDF ya tiene contraseña.")
    writer = PdfWriter()
    for page in reader.pages:
        writer.add_page(page)
    writer.encrypt(password, algorithm="AES-256")
    out = io.BytesIO()
    writer.write(out)
    return out.getvalue()


def unprotect(data: bytes, password: str) -> bytes:
    reader = PdfReader(io.BytesIO(data))
    if not reader.is_encrypted:
        raise ValueError("El PDF no tiene contraseña.")
    if reader.decrypt(password) == 0:
        raise ValueError("Contraseña incorrecta.")
    writer = PdfWriter()
    for page in reader.pages:
        writer.add_page(page)
    out = io.BytesIO()
    writer.write(out)
    return out.getvalue()


def compress(data: bytes) -> bytes:
    reader = PdfReader(io.BytesIO(data))
    if reader.is_encrypted:
        raise ValueError("Primero quita la contraseña del PDF.")
    writer = PdfWriter()
    for page in reader.pages:
        try:
            page.compress_content_streams()
        except Exception:
            pass
        writer.add_page(page)
    try:
        writer.compress_identical_objects()
    except Exception:
        pass
    out = io.BytesIO()
    writer.write(out)
    return out.getvalue()


def tables_to_xlsx(data: bytes, max_pages: int = 30) -> tuple[bytes, int]:
    """Extrae tablas de un PDF y las vuelca en un Excel (una hoja por tabla)."""
    import pdfplumber
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill

    wb = Workbook()
    wb.remove(wb.active)
    count = 0
    header_fill = PatternFill("solid", fgColor="0B0F14")
    header_font = Font(color="FFFFFF", bold=True)

    with pdfplumber.open(io.BytesIO(data)) as pdf:
        for pi, page in enumerate(pdf.pages[:max_pages], 1):
            for ti, table in enumerate(page.extract_tables(), 1):
                if not table or not any(any(c for c in row) for row in table):
                    continue
                count += 1
                ws = wb.create_sheet(f"P{pi}-T{ti}"[:31])
                for r, row in enumerate(table, 1):
                    for c, val in enumerate(row, 1):
                        cell = ws.cell(r, c, (val or "").replace("\n", " ") if isinstance(val, str) else val)
                        if r == 1:
                            cell.fill = header_fill
                            cell.font = header_font
                # Ancho de columnas
                for col in ws.columns:
                    width = min(max((len(str(c.value)) for c in col if c.value), default=8) + 2, 50)
                    ws.column_dimensions[col[0].column_letter].width = width
    if count == 0:
        raise ValueError("No encontré tablas en el PDF. Debe tener tablas con líneas reconocibles.")
    out = io.BytesIO()
    wb.save(out)
    return out.getvalue(), count
