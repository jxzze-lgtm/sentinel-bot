"""Decodifica un QR recibido como imagen y analiza su contenido (anti-fraude por QR)."""
import io

from services import message_scan
from utils import DIV, code, esc, header, join_blocks


def decode(data: bytes) -> list[str]:
    """Devuelve la lista de textos contenidos en el/los QR de la imagen."""
    from PIL import Image
    import pyzbar.pyzbar as zbar
    img = Image.open(io.BytesIO(data))
    results = zbar.decode(img)
    if not results:
        # segundo intento: a escala de grises y aumentada
        g = img.convert("L")
        if max(g.size) < 600:
            g = g.resize((g.width * 2, g.height * 2))
        results = zbar.decode(g)
    out = []
    for r in results:
        try:
            out.append(r.data.decode("utf-8"))
        except UnicodeDecodeError:
            out.append(r.data.decode("latin-1", "replace"))
    return list(dict.fromkeys(out))


def _kind(content: str) -> str:
    low = content.lower()
    if low.startswith("wifi:"):
        return "Red Wi-Fi"
    if low.startswith("begin:vcard"):
        return "Contacto (vCard)"
    if low.startswith(("http://", "https://")):
        return "Enlace web"
    if low.startswith(("bitcoin:", "ethereum:", "0x")):
        return "⚠️ Dirección de criptomonedas"
    if low.startswith("mailto:"):
        return "Correo"
    if low.startswith(("tel:", "smsto:")):
        return "Teléfono / SMS"
    return "Texto"


async def analyze(data: bytes) -> str:
    try:
        contents = decode(data)
    except Exception as e:  # noqa: BLE001
        return f"⚠️ No pude procesar la imagen ({esc(type(e).__name__)})."
    if not contents:
        return ("🔍 <b>No encontré ningún código QR</b> en la imagen.\n"
                "Envía una foto nítida y de frente, como archivo para que no se comprima.")

    blocks = []
    for content in contents[:3]:
        kind = _kind(content)
        head = f"📷 <b>QR detectado</b> · {kind}\n{code(content[:150])}"
        if content.lower().startswith(("http://", "https://")):
            # Analiza el enlace como si fuera un mensaje sospechoso
            detail = await message_scan.analyze(content)
            blocks.append(head + "\n\n" + detail)
        else:
            blocks.append(head)
    note = ("\n\n<i>⚠️ Los QR no muestran a dónde llevan. Nunca inicies sesión ni pagues desde un QR "
            "que no esperabas (volantes, correos, estacionamientos).</i>")
    return join_blocks(header("📷", "Análisis de código QR"), *blocks) + note
