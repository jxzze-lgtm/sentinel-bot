"""Analiza un mensaje, SMS o correo pegado y estima el riesgo de estafa/phishing."""
import asyncio
import re
from urllib.parse import urlparse

from services import http
from services.domain import get_whois
from utils import block, code, esc, header, join_blocks, verdict

PRESSURE = [
    "urgente", "inmediat", "suspendid", "bloquead", "verifica", "confirma", "último aviso", "ultimo aviso",
    "24 horas", "48 horas", "premio", "ganaste", "felicidades", "herencia", "reembolso", "paquete",
    "aduana", "multa", "deuda", "haz clic", "da clic", "actualiza tus datos", "acceso no autorizado",
    "tu cuenta será", "transferencia", "verificación", "sorteo",
]
SENSITIVE = ["código de verificación", "codigo de verificacion", "contraseña", "nip", "cvv", "pin ",
             "número de tarjeta", "numero de tarjeta", "clave dinámica", "clave dinamica"]
BRANDS = ["paypal", "apple", "google", "microsoft", "amazon", "netflix", "bbva", "santander", "bancolombia",
          "nequi", "davivienda", "dhl", "fedex", "correos", "mercadolibre", "mercadopago", "whatsapp",
          "instagram", "facebook", "banorte", "bancomer", "banamex", "hsbc", "telcel", "claro", "movistar",
          "binance", "coinbase", "uber", "sat", "oxxo", "spei"]
SHORTENERS = {"bit.ly", "tinyurl.com", "t.co", "goo.gl", "ow.ly", "is.gd", "cutt.ly", "rebrand.ly",
              "shorturl.at", "tiny.cc", "buff.ly", "rb.gy", "t.ly", "acortar.link"}
RISKY_TLDS = {"xyz", "top", "click", "live", "icu", "buzz", "work", "support", "rest", "cfd", "sbs",
              "vip", "tk", "ml", "ga", "cf", "gq", "link", "online", "site", "shop", "zip", "mov"}
SLD_COMPOUND = {"com", "net", "org", "gob", "gov", "edu", "co", "ac"}

URL_RE = re.compile(r"(?:https?://|www\.)[^\s<>\"')]+", re.I)
CRYPTO_RE = re.compile(r"\b(?:bc1[a-z0-9]{25,60}|[13][a-km-zA-HJ-NP-Z1-9]{25,34}|0x[a-fA-F0-9]{40})\b")


def _registrable(host: str) -> str:
    p = host.lower().strip(".").split(".")
    if len(p) >= 3 and len(p[-1]) == 2 and p[-2] in SLD_COMPOUND:
        return ".".join(p[-3:])
    return ".".join(p[-2:])


async def _analyze_url(url: str) -> tuple[str, list[str]]:
    u = url if "://" in url else "http://" + url
    parsed = urlparse(u)
    host = (parsed.hostname or "").lower()
    reg = _registrable(host)
    signals, final_host = [], host

    if reg in SHORTENERS or host in SHORTENERS:
        signals.append("acortador de enlaces (oculta el destino real)")
        res = await http.safe_fetch(u, read_body=False)
        final = res.get("final_url")
        if final and final != u:
            fh = (urlparse(final).hostname or "").lower()
            if fh and _registrable(fh) != reg:
                final_host, host, reg = fh, fh, _registrable(fh)
                signals.append(f"lleva a {code(fh)}")
    if re.fullmatch(r"[\d.]+", host):
        signals.append("usa una IP en lugar de un dominio")
    if "xn--" in host:
        signals.append("dominio con punycode (puede imitar otra marca)")
    if "@" in parsed.netloc:
        signals.append("contiene '@' para disfrazar el destino")
    if u.startswith("http://"):
        signals.append("no usa HTTPS")
    if reg.rsplit(".", 1)[-1] in RISKY_TLDS:
        signals.append(f"extensión .{reg.rsplit('.', 1)[-1]} frecuente en estafas")
    tokens = set(re.split(r"[.\-_]", host))
    for brand in BRANDS:
        if brand in tokens and reg.split(".")[0] != brand:
            signals.append(f"menciona '{brand}' pero el dominio real es {reg}")
            break
    if host.count(".") >= 4:
        signals.append("demasiados subdominios encadenados")
    who = await get_whois(reg)
    if who.get("age_days") is not None and who["age_days"] < 30:
        signals.append(f"dominio registrado hace {who['age_days']} días")
    return reg, signals


async def analyze(text: str) -> str:
    if len(text.strip()) < 5:
        return "⚠️ Pega el texto del mensaje o SMS sospechoso."

    urls = []
    seen = set()
    for raw in URL_RE.findall(text):
        u = raw.rstrip(".,;:!?)")
        key = re.sub(r"^(?:https?://)?(?:www\.)?", "", u.lower())
        if key not in seen:
            seen.add(key)
            urls.append(u)
    urls = urls[:6]

    low = text.lower()
    pressure = [p for p in PRESSURE if p in low]
    sensitive = [p.strip() for p in SENSITIVE if p in low]
    crypto = CRYPTO_RE.findall(text)
    phones = [t.strip() for t in re.findall(r"\+?\d[\d\s().-]{7,}\d", text) if sum(c.isdigit() for c in t) >= 9][:4]

    score = 0
    blocks = []
    if urls:
        analyses = await asyncio.gather(*(_analyze_url(u) for u in urls))
        rows = []
        for url, (reg, signals) in zip(urls, analyses):
            rows.append(f"🔗 {code(url[:60])}")
            if signals:
                score += 2 * min(len(signals), 3)
                rows += [f"   ⚠️ {s}" for s in signals]
            else:
                rows.append(f"   🟢 sin señales evidentes en {code(reg)}")
        blocks.append(block("Enlaces", rows))
    else:
        blocks.append(block("Enlaces", ["ninguno"]))

    extra = []
    if pressure:
        score += 2 if len(pressure) >= 3 else 1
        extra.append(("Lenguaje de presión", ", ".join(pressure[:8])))
    if sensitive:
        score += 2
        extra.append(("⚠️ Pide datos sensibles", ", ".join(sensitive)))
    if crypto:
        score += 3
        extra.append(("⚠️ Cripto", ", ".join(c[:16] + "…" for c in crypto[:3])))
    if phones:
        extra.append(("Teléfonos", ", ".join(phones)))
    if extra:
        blocks.append(block("Otros indicios", extra))

    level = "ok" if score < 3 else "mid" if score < 6 else "high"
    advice = block("Qué hacer", [
        "No abras enlaces ni compartas códigos o contraseñas",
        "Verifica con la empresa por su app o teléfono oficial",
        "Bloquea y reporta al remitente",
    ])
    return join_blocks(header("💬", "Análisis de mensaje"), *blocks, verdict(level), advice)
