"""Revisión de archivos sospechosos por hash (sin subirlos salvo que el usuario lo pida)."""
import hashlib

import aiohttp

from config import settings
from services import http
from utils import block, code, header, human_size, join_blocks, verdict

MAGIC = [
    (b"MZ", "Ejecutable de Windows (PE)"),
    (b"\x7fELF", "Ejecutable Linux (ELF)"),
    (b"%PDF", "PDF"),
    (b"PK\x03\x04", "ZIP / Office moderno / APK"),
    (b"\xd0\xcf\x11\xe0", "Office antiguo (OLE) — puede llevar macros"),
    (b"Rar!", "RAR"),
    (b"7z\xbc\xaf", "7-Zip"),
    (b"\x89PNG", "Imagen PNG"),
    (b"\xff\xd8\xff", "Imagen JPEG"),
    (b"#!", "Script"),
]
RISKY_EXT = {"exe", "scr", "js", "vbs", "bat", "cmd", "ps1", "hta", "lnk", "iso", "img", "msi", "jar",
             "docm", "xlsm", "pptm", "apk", "dll"}


def detect_type(data: bytes) -> str:
    for sig, name in MAGIC:
        if data.startswith(sig):
            return name
    return "Desconocido"


def hashes(data: bytes) -> dict:
    return {
        "md5": hashlib.md5(data).hexdigest(),
        "sha1": hashlib.sha1(data).hexdigest(),
        "sha256": hashlib.sha256(data).hexdigest(),
    }


async def vt_lookup(sha256: str) -> dict | None:
    if not settings.virustotal_key:
        return None
    st, data = await http.get_json(f"https://www.virustotal.com/api/v3/files/{sha256}",
                                   headers={"x-apikey": settings.virustotal_key})
    if st == 404:
        return {"unknown": True}
    if st != 200 or not data:
        return {"error": f"VirusTotal respondió {st}"}
    a = data["data"]["attributes"]
    return {
        "stats": a.get("last_analysis_stats", {}),
        "label": (a.get("popular_threat_classification") or {}).get("suggested_threat_label"),
        "names": a.get("names", [])[:3],
        "first_seen": a.get("first_submission_date"),
    }


async def vt_upload(filename: str, data: bytes) -> str:
    """Sube el archivo a VirusTotal. OJO: el archivo queda visible para la comunidad de VT."""
    if not settings.virustotal_key:
        return "Falta la llave de VirusTotal."
    form = aiohttp.FormData()
    form.add_field("file", data, filename=filename)
    st, res = await http.post_json("https://www.virustotal.com/api/v3/files", data=form,
                                   headers={"x-apikey": settings.virustotal_key}, timeout=120)
    if st != 200 or not res:
        return f"No se pudo subir (código {st})."
    return "Archivo enviado. Vuelve a mandarlo en 2–3 minutos para ver el resultado."


async def analyze(filename: str, data: bytes) -> tuple[str, bool]:
    """Devuelve (texto, ofrecer_subida)."""
    h = hashes(data)
    ftype = detect_type(data)
    ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
    vt = await vt_lookup(h["sha256"])

    flags = []
    if ext in RISKY_EXT:
        flags.append(f"Extensión de riesgo (.{ext})")
    if filename.count(".") >= 2 and ext in RISKY_EXT:
        flags.append("Doble extensión (ej. factura.pdf.exe)")
    if ftype.startswith("Ejecutable") and ext not in ("exe", "dll", "msi", "scr", ""):
        flags.append("Es un ejecutable disfrazado con otra extensión")

    info = block("Archivo", [
        ("Nombre", filename[:60]),
        ("Tamaño", human_size(len(data))),
        ("Tipo real", ftype),
    ])
    hash_block = block("Hashes", [f"MD5    {code(h['md5'])}", f"SHA1   {code(h['sha1'])}",
                                  f"SHA256 {code(h['sha256'])}"])

    offer_upload = False
    score = len(flags)
    if vt is None:
        vt_block = block("VirusTotal", ["<i>Configura VIRUSTOTAL_API_KEY para consultar 70+ antivirus</i>"])
        level = "na" if not flags else "mid"
    elif vt.get("unknown"):
        vt_block = block("VirusTotal", ["Nunca antes visto en VirusTotal"])
        offer_upload = True
        level = "na" if not flags else "mid"
    elif vt.get("error"):
        vt_block = block("VirusTotal", [vt["error"]])
        level = "na"
    else:
        m, s = vt["stats"].get("malicious", 0), vt["stats"].get("suspicious", 0)
        total = sum(vt["stats"].values())
        vt_block = block("VirusTotal", [
            ("Detecciones", f"{m} maliciosos · {s} sospechosos / {total}"),
            ("Familia", vt.get("label")),
            ("También conocido", ", ".join(vt["names"])) if vt.get("names") else None,
        ])
        score += m * 2 + s
        level = "ok" if score == 0 else "low" if score <= 2 else "mid" if score <= 6 else "high"

    text = join_blocks(header("📄", "Revisión de archivo"), info, hash_block, vt_block,
                       block("Señales", flags) if flags else "", verdict(level))
    return text, offer_upload
