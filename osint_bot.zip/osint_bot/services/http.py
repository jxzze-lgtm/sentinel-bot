"""Sesión HTTP compartida (aiohttp) con tiempos de espera razonables."""
import aiohttp

USER_AGENT = "SentinelOSINT/1.0 (+defensive security bot)"
_session: aiohttp.ClientSession | None = None


def session() -> aiohttp.ClientSession:
    global _session
    if _session is None or _session.closed:
        _session = aiohttp.ClientSession(
            timeout=aiohttp.ClientTimeout(total=30, connect=10),
            headers={"User-Agent": USER_AGENT},
        )
    return _session


async def close() -> None:
    if _session and not _session.closed:
        await _session.close()


async def get_json(url: str, *, headers: dict | None = None, params: dict | None = None,
                   timeout: int = 30) -> tuple[int, dict | list | None]:
    """GET que devuelve (status, json|None) sin lanzar excepción por códigos HTTP."""
    try:
        async with session().get(url, headers=headers, params=params,
                                 timeout=aiohttp.ClientTimeout(total=timeout)) as r:
            if r.content_type and "json" in r.content_type:
                return r.status, await r.json()
            text = await r.text()
            try:
                import json
                return r.status, json.loads(text)
            except ValueError:
                return r.status, None
    except Exception:
        return 0, None


async def host_is_public(host: str) -> bool:
    """Resuelve el host y confirma que TODAS sus IPs son públicas (anti-SSRF)."""
    import asyncio
    import ipaddress
    import socket
    try:
        infos = await asyncio.get_running_loop().getaddrinfo(host, None, type=socket.SOCK_STREAM)
    except OSError:
        return False
    if not infos:
        return False
    for info in infos:
        ip = ipaddress.ip_address(info[4][0])
        if not ip.is_global or ip.is_multicast:
            return False
    return True


async def safe_fetch(url: str, *, max_redirects: int = 8, max_bytes: int = 10 * 1024 * 1024,
                     read_body: bool = True) -> dict:
    """Descarga una URL siguiendo redirecciones manualmente y validando cada salto.

    Devuelve: {chain: [(status, url)], status, final_url, headers, body, error}
    """
    from urllib.parse import urljoin, urlparse

    chain: list[tuple[int, str]] = []
    current = url
    for _ in range(max_redirects + 1):
        host = urlparse(current).hostname or ""
        if not await host_is_public(host):
            return {"chain": chain, "error": f"Destino no permitido o no resuelve: {host}"}
        try:
            async with session().get(current, allow_redirects=False,
                                     timeout=aiohttp.ClientTimeout(total=25)) as r:
                chain.append((r.status, current))
                if r.status in (301, 302, 303, 307, 308) and "Location" in r.headers:
                    current = urljoin(current, r.headers["Location"])
                    continue
                body = b""
                if read_body:
                    body = await r.content.read(max_bytes)
                return {"chain": chain, "status": r.status, "final_url": current,
                        "headers": dict(r.headers), "body": body, "error": None}
        except Exception as e:  # noqa: BLE001
            return {"chain": chain, "error": f"{type(e).__name__}: {e}"[:200]}
    return {"chain": chain, "error": "Demasiadas redirecciones"}


async def post_json(url: str, *, json_body: dict | None = None, data=None,
                    headers: dict | None = None, timeout: int = 30) -> tuple[int, dict | None]:
    try:
        async with session().post(url, json=json_body, data=data, headers=headers,
                                  timeout=aiohttp.ClientTimeout(total=timeout)) as r:
            try:
                return r.status, await r.json(content_type=None)
            except Exception:
                return r.status, None
    except Exception:
        return 0, None
