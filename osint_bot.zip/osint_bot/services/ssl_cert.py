"""Revisión del certificado SSL/TLS de un sitio, con aviso de caducidad."""
import asyncio
import socket
import ssl
from datetime import datetime, timezone

from utils import block, header, join_blocks, verdict


def _check(host: str, port: int = 443) -> dict:
    ctx = ssl.create_default_context()
    try:
        with socket.create_connection((host, port), timeout=10) as s:
            with ctx.wrap_socket(s, server_hostname=host) as ss:
                return {"cert": ss.getpeercert(), "version": ss.version()}
    except ssl.SSLCertVerificationError as e:
        return {"invalid": getattr(e, "verify_message", str(e))}
    except (OSError, ssl.SSLError) as e:
        return {"error": f"No se pudo conectar por TLS con {host}:{port} ({type(e).__name__})"}


async def analyze(host: str, port: int = 443) -> str:
    res = await asyncio.to_thread(_check, host, port)
    head = header("🔒", "Certificado SSL/TLS", f"{host}:{port}")
    if res.get("error"):
        return join_blocks(head, res["error"])
    if res.get("invalid"):
        return join_blocks(head, f"🔴 <b>El certificado NO es válido</b>\n{res['invalid']}")

    cert, version = res["cert"], res["version"]
    subject = dict(x[0] for x in cert.get("subject", ()))
    issuer = dict(x[0] for x in cert.get("issuer", ()))
    since = datetime.strptime(cert["notBefore"], "%b %d %H:%M:%S %Y %Z").replace(tzinfo=timezone.utc)
    until = datetime.strptime(cert["notAfter"], "%b %d %H:%M:%S %Y %Z").replace(tzinfo=timezone.utc)
    days = (until - datetime.now(timezone.utc)).days
    sans = [v for k, v in cert.get("subjectAltName", ()) if k == "DNS"]

    info = block("Certificado", [
        ("Emitido para", subject.get("commonName", "—")),
        ("Emitido por", issuer.get("organizationName", issuer.get("commonName", "—"))),
        ("Protocolo", version),
        ("Válido desde", since.strftime("%Y-%m-%d")),
        ("Vence", f"{until:%Y-%m-%d} · {'quedan ' + str(days) + ' días' if days >= 0 else 'VENCIDO'}"),
    ])
    names = block(f"Nombres cubiertos · {len(sans)}", [", ".join(sans[:12]) + (" …" if len(sans) > 12 else "")]) \
        if sans else ""

    if days < 0:
        level, note = "high", "🔴 <b>El certificado está vencido.</b> El navegador mostrará una alerta a tus visitantes."
    elif days < 7:
        level, note = "high", f"🔴 <b>Vence en {days} días.</b> Renuévalo ya."
    elif days < 30:
        level, note = "mid", f"🟠 Vence en {days} días. Prográmate para renovarlo."
    else:
        level, note = "ok", None

    return join_blocks(head, info, names, verdict(level), note or "")
