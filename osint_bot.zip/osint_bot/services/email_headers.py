"""Análisis de encabezados de correo para detectar phishing y suplantación."""
import ipaddress
import re
from email.parser import HeaderParser
from email.utils import getaddresses, parseaddr

from services.domain import dns_records
from utils import block, code, header, join_blocks, verdict

IP_RE = re.compile(r"\[?((?:\d{1,3}\.){3}\d{1,3})\]?")
AUTH_RE = re.compile(r"\b(spf|dkim|dmarc|arc)\s*=\s*([a-z]+)", re.I)


def _domain(addr: str) -> str:
    return addr.rsplit("@", 1)[-1].lower().strip(">") if "@" in addr else ""


def _org(domain: str) -> str:
    """Aproxima el dominio organizacional (example.co.uk → example.co.uk, mail.x.com → x.com)."""
    parts = domain.split(".")
    if len(parts) >= 3 and len(parts[-1]) == 2 and parts[-2] in ("co", "com", "org", "net", "gob", "gov", "edu"):
        return ".".join(parts[-3:])
    return ".".join(parts[-2:])


def parse(raw: str) -> dict:
    msg = HeaderParser().parsestr(raw.strip() + "\n\n")
    from_name, from_addr = parseaddr(msg.get("From", ""))
    _, return_path = parseaddr(msg.get("Return-Path", ""))
    reply_to = [a for _, a in getaddresses(msg.get_all("Reply-To", []))]

    auth: dict[str, str] = {}
    for h in msg.get_all("Authentication-Results", []) + msg.get_all("ARC-Authentication-Results", []):
        for k, v in AUTH_RE.findall(h):
            auth.setdefault(k.lower(), v.lower())
    rspf = msg.get("Received-SPF", "")
    if "spf" not in auth and rspf:
        auth["spf"] = rspf.split()[0].lower()

    hops = []
    for rec in reversed(msg.get_all("Received", [])):  # del más antiguo al más reciente
        m_from = re.search(r"from\s+(\S+)", rec, re.I)
        ips = [ip for ip in IP_RE.findall(rec)]
        public = []
        for ip in ips:
            try:
                if ipaddress.ip_address(ip).is_global:
                    public.append(ip)
            except ValueError:
                pass
        hops.append({"from": m_from.group(1) if m_from else "?", "ip": public[0] if public else None})

    origin_ip = next((h["ip"] for h in hops if h["ip"]), None)

    return {
        "subject": msg.get("Subject", ""),
        "date": msg.get("Date", ""),
        "from_name": from_name,
        "from_addr": from_addr,
        "return_path": return_path,
        "reply_to": reply_to,
        "message_id": msg.get("Message-ID", ""),
        "auth": auth,
        "hops": hops,
        "origin_ip": origin_ip,
        "mailer": msg.get("X-Mailer", "") or msg.get("User-Agent", ""),
    }


def flags_for(d: dict) -> tuple[list[str], int]:
    flags, score = [], 0
    fdom = _domain(d["from_addr"])
    for key in ("spf", "dkim", "dmarc"):
        val = d["auth"].get(key)
        if val in ("fail", "softfail", "permerror"):
            flags.append(f"❌ {key.upper()} = {val}")
            score += 3 if key == "dmarc" else 2
        elif val is None or val == "none":
            flags.append(f"❔ Sin {key.upper()}" + (" (no firmado / sin registro)" if val == "none" else ""))
            score += 1
    if d["return_path"] and fdom and _org(_domain(d["return_path"])) != _org(fdom):
        flags.append(f"Return-Path ({_domain(d['return_path'])}) distinto al remitente ({fdom})")
        score += 1
    for r in d["reply_to"]:
        if fdom and _org(_domain(r)) != _org(fdom):
            flags.append(f"Las respuestas irían a otro dominio: {r}")
            score += 2
    name_mail = re.search(r"[\w.+-]+@[\w.-]+", d["from_name"] or "")
    if name_mail and _domain(name_mail.group(0)) != fdom:
        flags.append("El nombre visible contiene un correo de otro dominio (suplantación clásica)")
        score += 3
    if d["message_id"] and fdom and fdom not in d["message_id"].lower():
        flags.append("Message-ID generado por otro dominio")
    return flags, score


async def analyze(raw: str) -> str:
    d = parse(raw)
    if not d["from_addr"] and not d["hops"]:
        return ("⚠️ No encontré encabezados válidos.\n\n"
                "En Gmail: ⋮ → <b>Mostrar original</b> → copia todo el texto.\n"
                "En Outlook: Archivo → Propiedades → <b>Encabezados de Internet</b>.")

    flags, score = flags_for(d)
    fdom = _domain(d["from_addr"])
    dmarc_policy = None
    if fdom:
        rec = await dns_records(f"_dmarc.{fdom}", "TXT")
        m = re.search(r"\bp=(\w+)", " ".join(rec))
        dmarc_policy = m.group(1) if m else "sin DMARC"

    who = block("Remitente", [
        ("Nombre", d["from_name"]),
        ("Correo", d["from_addr"]),
        ("Return-Path", d["return_path"]),
        ("Reply-To", ", ".join(d["reply_to"])) if d["reply_to"] else None,
        ("Asunto", d["subject"][:70]),
        ("Cliente", d["mailer"][:50]) if d["mailer"] else None,
    ])
    auth = block("Autenticación", [
        ("SPF", d["auth"].get("spf", "—")),
        ("DKIM", d["auth"].get("dkim", "—")),
        ("DMARC", d["auth"].get("dmarc", "—")),
        ("Política DMARC de " + fdom, dmarc_policy) if fdom else None,
    ])
    route_rows = [f"{i + 1}. {code(h['from'][:45])}" + (f" · {code(h['ip'])}" if h["ip"] else "")
                  for i, h in enumerate(d["hops"][:8])]
    route = block(f"Ruta · {len(d['hops'])} saltos", route_rows)
    origin = block("Origen", [("IP del servidor emisor", d["origin_ip"]),
                              "Analízala en 📍 IP para ver su reputación" if d["origin_ip"] else None])

    level = "ok" if score == 0 else "low" if score <= 2 else "mid" if score <= 5 else "high"
    return join_blocks(header("✉️", "Análisis de correo"), who, auth, route, origin,
                       block("Señales", flags) if flags else "", verdict(level))
