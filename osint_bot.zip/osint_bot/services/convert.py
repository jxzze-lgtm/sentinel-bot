"""Utilidades de automatización: conversión de archivos, QR y decodificador.

Todo se procesa en archivos temporales que se borran al terminar, con límites de
tamaño y de páginas para no agotar la memoria de un servidor pequeño.
"""
import asyncio
import base64
import binascii
import io
import json
import shutil
import tempfile
from html import escape
from pathlib import Path

from PIL import Image

# ── Conversión de imágenes ──────────────────────────────────────────────
IMG_FORMATS = {"jpg": "JPEG", "jpeg": "JPEG", "png": "PNG", "webp": "WEBP", "bmp": "BMP", "tiff": "TIFF"}
MAX_IMG_PIXELS = 50_000_000


def _open_image(data: bytes) -> Image.Image:
    img = Image.open(io.BytesIO(data))
    if img.width * img.height > MAX_IMG_PIXELS:
        raise MemoryError("Imagen demasiado grande")
    return img


def image_convert(data: bytes, target_ext: str) -> bytes:
    fmt = IMG_FORMATS[target_ext]
    img = _open_image(data)
    if fmt == "JPEG" and img.mode in ("RGBA", "P", "LA"):
        bg = Image.new("RGB", img.size, (255, 255, 255))
        img = img.convert("RGBA")
        bg.paste(img, mask=img.split()[-1])
        img = bg
    elif img.mode == "P":
        img = img.convert("RGB")
    out = io.BytesIO()
    img.save(out, fmt, quality=90)
    return out.getvalue()


def images_to_pdf(images: list[bytes]) -> bytes:
    pages = []
    for data in images:
        img = _open_image(data)
        pages.append(img.convert("RGB"))
    out = io.BytesIO()
    pages[0].save(out, "PDF", save_all=True, append_images=pages[1:])
    return out.getvalue()


def compress_image(data: bytes, quality: int = 60, max_side: int = 2000) -> bytes:
    img = _open_image(data).convert("RGB")
    if max(img.size) > max_side:
        img.thumbnail((max_side, max_side))
    out = io.BytesIO()
    img.save(out, "JPEG", quality=quality, optimize=True)
    return out.getvalue()


# ── PDF ─────────────────────────────────────────────────────────────────
MAX_PDF_PAGES_RENDER = 30


def pdf_to_images(data: bytes, dpi: int = 150) -> list[bytes]:
    import pypdfium2 as pdfium
    pdf = pdfium.PdfDocument(data)
    total = len(pdf)
    n = min(total, MAX_PDF_PAGES_RENDER)
    out = []
    scale = dpi / 72
    for i in range(n):
        page = pdf[i]
        bmp = page.render(scale=scale)
        img = bmp.to_pil()
        buf = io.BytesIO()
        img.save(buf, "PNG")
        out.append(buf.getvalue())
        bmp.close()
        page.close()
    pdf.close()
    return out, total


def merge_pdfs(pdfs: list[bytes]) -> bytes:
    from pypdf import PdfReader, PdfWriter
    w = PdfWriter()
    for data in pdfs:
        for page in PdfReader(io.BytesIO(data)).pages:
            w.add_page(page)
    out = io.BytesIO()
    w.write(out)
    return out.getvalue()


def split_pdf(data: bytes) -> list[tuple[str, bytes]]:
    """Separa un PDF en una página por archivo."""
    from pypdf import PdfReader, PdfWriter
    reader = PdfReader(io.BytesIO(data))
    files = []
    for i, page in enumerate(reader.pages[:50], 1):
        w = PdfWriter()
        w.add_page(page)
        buf = io.BytesIO()
        w.write(buf)
        files.append((f"pagina_{i:02d}.pdf", buf.getvalue()))
    return files


def pdf_page_count(data: bytes) -> int:
    from pypdf import PdfReader
    return len(PdfReader(io.BytesIO(data)).pages)


# ── Office → PDF (LibreOffice headless) ─────────────────────────────────
OFFICE_EXT = {"docx", "doc", "odt", "rtf", "xlsx", "xls", "ods", "pptx", "ppt", "odp", "txt", "csv"}


def libreoffice_available() -> bool:
    return bool(shutil.which("soffice") or shutil.which("libreoffice"))


def office_to_pdf(filename: str, data: bytes) -> bytes:
    exe = shutil.which("soffice") or shutil.which("libreoffice")
    if not exe:
        raise RuntimeError("LibreOffice no está instalado en el servidor.")
    safe = Path(filename).name or "documento"
    with tempfile.TemporaryDirectory() as tmp:
        src = Path(tmp) / safe
        src.write_bytes(data)
        profile = Path(tmp) / "profile"
        import subprocess
        proc = subprocess.run(
            [exe, "--headless", "--norestore", f"-env:UserInstallation=file://{profile}",
             "--convert-to", "pdf", "--outdir", tmp, str(src)],
            capture_output=True, timeout=120,
        )
        pdfs = list(Path(tmp).glob("*.pdf"))
        if not pdfs:
            raise RuntimeError(f"LibreOffice no pudo convertir el archivo ({proc.returncode}).")
        return pdfs[0].read_bytes()


async def office_to_pdf_async(filename: str, data: bytes) -> bytes:
    return await asyncio.to_thread(office_to_pdf, filename, data)


# ── Generador de QR ─────────────────────────────────────────────────────
def make_qr(text: str) -> bytes:
    import segno
    qr = segno.make(text, error="m")
    out = io.BytesIO()
    qr.save(out, kind="png", scale=10, border=3, dark="#0b0f14", light="#ffffff")
    return out.getvalue()


# ── Decodificador de analista ───────────────────────────────────────────
def defang(text: str) -> str:
    """Desarma enlaces e IPs para compartirlos sin que sean clicables."""
    import re
    text = re.sub(r"https?://", lambda m: m.group(0).replace("http", "hxxp"), text, flags=re.I)
    text = re.sub(r"\.(?=[a-z0-9])", "[.]", text, flags=re.I)
    text = text.replace("@", "[@]")
    return text


def refang(text: str) -> str:
    return (text.replace("[.]", ".").replace("[@]", "@")
            .replace("hxxps", "https").replace("hxxp", "http").replace("(.)", "."))


def decode_jwt(token: str) -> str:
    parts = token.strip().split(".")
    if len(parts) < 2:
        raise ValueError("No parece un JWT (deben ser 3 partes separadas por puntos).")

    def b64(seg: str) -> str:
        seg += "=" * (-len(seg) % 4)
        return base64.urlsafe_b64decode(seg).decode("utf-8", "replace")

    header = escape(json.dumps(json.loads(b64(parts[0])), indent=2, ensure_ascii=False))
    payload = escape(json.dumps(json.loads(b64(parts[1])), indent=2, ensure_ascii=False))
    return (f"<b>Header</b>\n<code>{header}</code>\n\n<b>Payload</b>\n<code>{payload}</code>")


def smart_decode(text: str) -> str:
    """Intenta varias decodificaciones y devuelve las que dan texto legible."""
    text = text.strip()
    results = []

    # JWT
    if text.count(".") == 2 and text.startswith("ey"):
        try:
            return decode_jwt(text)
        except Exception:
            pass

    # Base64
    try:
        raw = base64.b64decode(text + "=" * (-len(text) % 4), validate=True)
        dec = raw.decode("utf-8")
        if dec.isprintable():
            results.append(("Base64", dec))
    except (binascii.Error, ValueError, UnicodeDecodeError):
        pass

    # Hexadecimal
    cleaned = text.replace(" ", "").replace("0x", "")
    if len(cleaned) % 2 == 0 and all(c in "0123456789abcdefABCDEF" for c in cleaned) and cleaned:
        try:
            dec = bytes.fromhex(cleaned).decode("utf-8")
            if dec.isprintable():
                results.append(("Hexadecimal", dec))
        except (ValueError, UnicodeDecodeError):
            pass

    # URL encoding
    from urllib.parse import unquote
    if "%" in text:
        dec = unquote(text)
        if dec != text:
            results.append(("URL", dec))

    # Defang / refang
    if any(m in text for m in ("[.]", "hxxp", "[@]", "(.)")):
        results.append(("Refang (enlace restaurado)", refang(text)))

    if not results:
        return ("🤔 No reconocí ninguna codificación común.\n"
                "Acepto Base64, hexadecimal, URL-encoding, JWT y enlaces 'defanged'.")
    out = []
    for name, value in results:
        out.append(f"<b>{name}</b>\n<code>{escape(value[:1500])}</code>")
    return "\n\n".join(out)
