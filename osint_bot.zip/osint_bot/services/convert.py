"""Utilidades de automatización: conversión de archivos, QR y decodificador.

Todo se procesa en archivos temporales que se borran al terminar, con límites de
tamaño y de páginas para no agotar la memoria de un servidor pequeño.
"""
import asyncio
import base64
import binascii
import io
import json
import shutil
import tempfile
from html import escape
from pathlib import Path

from PIL import Image

# ── Conversión de imágenes ──────────────────────────────────────────────
IMG_FORMATS = {"jpg": "JPEG", "jpeg": "JPEG", "png": "PNG", "webp": "WEBP", "bmp": "BMP", "tiff": "TIFF"}
MAX_IMG_PIXELS = 50_000_000


def _open_image(data: bytes) -> Image.Image:
    img = Image.open(io.BytesIO(data))
    if img.width * img.height > MAX_IMG_PIXELS:
        raise MemoryError("Imagen demasiado grande")
    return img


def image_convert(data: bytes, target_ext: str) -> bytes:
    fmt = IMG_FORMATS[target_ext]
    img = _open_image(data)
    if fmt == "JPEG" and img.mode in ("RGBA", "P", "LA"):
        bg = Image.new("RGB", img.size, (255, 255, 255))
        img = img.convert("RGBA")
        bg.paste(img, mask=img.split()[-1])
        img = bg
    elif img.mode == "P":
        img = img.convert("RGB")
    out = io.BytesIO()
    img.save(out, fmt, quality=90)
    return out.getvalue()


def images_to_pdf(images: list[bytes]) -> bytes:
    pages = []
    for data in images:
        img = _open_image(data)
        pages.append(img.convert("RGB"))
    out = io.BytesIO()
    pages[0].save(out, "PDF", save_all=True, append_images=pages[1:])
    return out.getvalue()


def images_collage(images: list[bytes], vertical: bool = True) -> bytes:
    """Une varias imágenes en una sola (apiladas en vertical por defecto)."""
    imgs = [_open_image(d).convert("RGB") for d in images]
    if vertical:
        width = max(i.width for i in imgs)
        scaled = [i.resize((width, round(i.height * width / i.width))) for i in imgs]
        height = sum(i.height for i in scaled)
        canvas = Image.new("RGB", (width, height), (255, 255, 255))
        y = 0
        for i in scaled:
            canvas.paste(i, (0, y)); y += i.height
    else:
        height = max(i.height for i in imgs)
        scaled = [i.resize((round(i.width * height / i.height), height)) for i in imgs]
        width = sum(i.width for i in scaled)
        canvas = Image.new("RGB", (width, height), (255, 255, 255))
        x = 0
        for i in scaled:
            canvas.paste(i, (x, 0)); x += i.width
    out = io.BytesIO()
    canvas.save(out, "JPEG", quality=90)
    return out.getvalue()


def compress_image(data: bytes, quality: int = 60, max_side: int = 2000) -> bytes:
    img = _open_image(data).convert("RGB")
    if max(img.size) > max_side:
        img.thumbnail((max_side, max_side))
    out = io.BytesIO()
    img.save(out, "JPEG", quality=quality, optimize=True)
    return out.getvalue()


# ── PDF ─────────────────────────────────────────────────────────────────
MAX_PDF_PAGES_RENDER = 30


def pdf_to_images(data: bytes, dpi: int = 150) -> list[bytes]:
    import pypdfium2 as pdfium
    pdf = pdfium.PdfDocument(data)
    total = len(pdf)
    n = min(total, MAX_PDF_PAGES_RENDER)
    out = []
    scale = dpi / 72
    for i in range(n):
        page = pdf[i]
        bmp = page.render(scale=scale)
        img = bmp.to_pil()
        buf = io.BytesIO()
        img.save(buf, "PNG")
        out.append(buf.getvalue())
        bmp.close()
        page.close()
    pdf.close()
    return out, total


def merge_pdfs(pdfs: list[bytes]) -> bytes:
    from pypdf import PdfReader, PdfWriter
    w = PdfWriter()
    for data in pdfs:
        for page in PdfReader(io.BytesIO(data)).pages:
            w.add_page(page)
    out = io.BytesIO()
    w.write(out)
    return out.getvalue()


def split_pdf(data: bytes) -> list[tuple[str, bytes]]:
    """Separa un PDF en una página por archivo."""
    from pypdf import PdfReader, PdfWriter
    reader = PdfReader(io.BytesIO(data))
    files = []
    for i, page in enumerate(reader.pages[:50], 1):
        w = PdfWriter()
        w.add_page(page)
        buf = io.BytesIO()
        w.write(buf)
        files.append((f"pagina_{i:02d}.pdf", buf.getvalue()))
    return files


def pdf_page_count(data: bytes) -> int:
    from pypdf import PdfReader
    return len(PdfReader(io.BytesIO(data)).pages)


# ── Office → PDF (LibreOffice headless) ─────────────────────────────────
OFFICE_EXT = {"docx", "doc", "odt", "rtf", "xlsx", "xls", "ods", "pptx", "ppt", "odp", "txt", "csv"}


def libreoffice_available() -> bool:
    return bool(shutil.which("soffice") or shutil.which("libreoffice"))


def office_to_pdf(filename: str, data: bytes) -> bytes:
    exe = shutil.which("soffice") or shutil.which("libreoffice")
    if not exe:
        raise RuntimeError("LibreOffice no está instalado en el servidor.")
    safe = Path(filename).name or "documento"
    with tempfile.TemporaryDirectory() as tmp:
        src = Path(tmp) / safe
        src.write_bytes(data)
        profile = Path(tmp) / "profile"
        import subprocess
        proc = subprocess.run(
            [exe, "--headless", "--norestore", f"-env:UserInstallation=file://{profile}",
             "--convert-to", "pdf", "--outdir", tmp, str(src)],
            capture_output=True, timeout=120,
        )
        pdfs = list(Path(tmp).glob("*.pdf"))
        if not pdfs:
            raise RuntimeError(f"LibreOffice no pudo convertir el archivo ({proc.returncode}).")
        return pdfs[0].read_bytes()


async def office_to_pdf_async(filename: str, data: bytes) -> bytes:
    return await asyncio.to_thread(office_to_pdf, filename, data)


# ── Generador de QR ─────────────────────────────────────────────────────
_FONTS = Path(__file__).resolve().parent.parent / "assets" / "fonts"


def _font(name: str, size: int):
    from PIL import ImageFont
    try:
        return ImageFont.truetype(str(_FONTS / name), size)
    except Exception:
        return ImageFont.load_default()


def make_qr(text: str) -> bytes:
    """Genera un QR sobre una tarjeta con la marca. Pensado para enviarse SIN comprimir.

    Los módulos van en negro puro sobre blanco (máximo contraste) y con corrección de
    errores alta, para que escanee siempre aunque la tarjeta lleve diseño alrededor.
    """
    import segno
    from PIL import Image, ImageDraw

    qr = segno.make(text, error="h")  # corrección alta (~30%)
    buf = io.BytesIO()
    qr.save(buf, kind="png", scale=12, border=4, dark="#000000", light="#ffffff")
    buf.seek(0)
    code = Image.open(buf).convert("RGB")

    # Colores de marca
    BG, ACCENT, TEXT, MUTED = (11, 15, 20), (57, 208, 180), (236, 240, 244), (139, 150, 164)
    pad, top, bottom = 70, 150, 150
    panel = 40  # margen blanco alrededor del QR dentro de la tarjeta blanca

    qr_size = code.width
    card_w = qr_size + panel * 2
    W = card_w + pad * 2
    H = top + card_w + bottom

    img = Image.new("RGB", (W, H), BG)
    d = ImageDraw.Draw(img)

    # Rejilla de puntos sutil
    for x in range(30, W, 34):
        for y in range(30, H, 34):
            d.point((x, y), fill=(28, 34, 43))

    # Encabezado
    d.rectangle((pad, 54, pad + 5, 54 + 30), fill=ACCENT)
    d.text((pad + 20, 54), "SENTINEL OSINT", font=_font("DejaVuSansMono.ttf", 24), fill=MUTED)
    d.text((pad, 92), "Código QR", font=_font("Inter-Bold.otf", 40), fill=TEXT)

    # Tarjeta blanca con el QR
    card_x, card_y = pad, top
    d.rounded_rectangle((card_x, card_y, card_x + card_w, card_y + card_w), radius=28, fill="#ffffff")
    img.paste(code, (card_x + panel, card_y + panel))

    # Texto codificado (truncado) abajo
    shown = text if len(text) <= 52 else text[:51] + "…"
    ty = card_y + card_w + 40
    d.text((pad, ty), shown, font=_font("DejaVuSansMono.ttf", 26), fill=TEXT)
    d.text((pad, ty + 40), "Escanéalo con la cámara de tu teléfono",
           font=_font("Inter-Regular.otf", 22), fill=MUTED)

    out = io.BytesIO()
    img.save(out, "PNG")
    return out.getvalue()


# ── Decodificador de analista ───────────────────────────────────────────
def defang(text: str) -> str:
    """Desarma enlaces e IPs para compartirlos sin que sean clicables."""
    import re
    text = re.sub(r"https?://", lambda m: m.group(0).replace("http", "hxxp"), text, flags=re.I)
    text = re.sub(r"\.(?=[a-z0-9])", "[.]", text, flags=re.I)
    text = text.replace("@", "[@]")
    return text


def refang(text: str) -> str:
    return (text.replace("[.]", ".").replace("[@]", "@")
            .replace("hxxps", "https").replace("hxxp", "http").replace("(.)", "."))


def decode_jwt(token: str) -> str:
    parts = token.strip().split(".")
    if len(parts) < 2:
        raise ValueError("No parece un JWT (deben ser 3 partes separadas por puntos).")

    def b64(seg: str) -> str:
        seg += "=" * (-len(seg) % 4)
        return base64.urlsafe_b64decode(seg).decode("utf-8", "replace")

    header = escape(json.dumps(json.loads(b64(parts[0])), indent=2, ensure_ascii=False))
    payload = escape(json.dumps(json.loads(b64(parts[1])), indent=2, ensure_ascii=False))
    return (f"<b>Header</b>\n<code>{header}</code>\n\n<b>Payload</b>\n<code>{payload}</code>")


def smart_decode(text: str) -> str:
    """Intenta varias decodificaciones y devuelve las que dan texto legible."""
    text = text.strip()
    results = []

    # JWT
    if text.count(".") == 2 and text.startswith("ey"):
        try:
            return decode_jwt(text)
        except Exception:
            pass

    # Base64
    try:
        raw = base64.b64decode(text + "=" * (-len(text) % 4), validate=True)
        dec = raw.decode("utf-8")
        if dec.isprintable():
            results.append(("Base64", dec))
    except (binascii.Error, ValueError, UnicodeDecodeError):
        pass

    # Hexadecimal
    cleaned = text.replace(" ", "").replace("0x", "")
    if len(cleaned) % 2 == 0 and all(c in "0123456789abcdefABCDEF" for c in cleaned) and cleaned:
        try:
            dec = bytes.fromhex(cleaned).decode("utf-8")
            if dec.isprintable():
                results.append(("Hexadecimal", dec))
        except (ValueError, UnicodeDecodeError):
            pass

    # URL encoding
    from urllib.parse import unquote
    if "%" in text:
        dec = unquote(text)
        if dec != text:
            results.append(("URL", dec))

    # Defang / refang
    if any(m in text for m in ("[.]", "hxxp", "[@]", "(.)")):
        results.append(("Refang (enlace restaurado)", refang(text)))

    if not results:
        return ("🤔 No reconocí ninguna codificación común.\n"
                "Acepto Base64, hexadecimal, URL-encoding, JWT y enlaces 'defanged'.")
    out = []
    for name, value in results:
        out.append(f"<b>{name}</b>\n<code>{escape(value[:1500])}</code>")
    return "\n\n".join(out)
