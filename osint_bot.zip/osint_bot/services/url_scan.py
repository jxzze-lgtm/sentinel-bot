"""Revisión de enlaces sospechosos sin que el usuario tenga que abrirlos."""
import asyncio
import base64
import re
from urllib.parse import urlparse

from config import settings
from services import http
from services.domain import get_whois
from utils import block, code, header, join_blocks, verdict

SHORTENERS = {"bit.ly", "tinyurl.com", "t.co", "goo.gl", "is.gd", "ow.ly", "cutt.ly", "rebrand.ly",
              "shorturl.at", "rb.gy", "t.ly", "s.id", "tiny.cc"}
RISKY_TLDS = {"zip", "mov", "xyz", "top", "click", "country", "gq", "tk", "ml", "cf", "ga", "work",
              "rest", "cam", "support", "quest"}
LURE_WORDS = ("login", "verify", "verifica", "secure", "account", "cuenta", "update", "banco", "bank",
              "wallet", "password", "signin", "confirm", "pago", "factura", "invoice")


def heuristics(url: str) -> list[str]:
    p = urlparse(url)
    host = p.hostname or ""
    flags = []
    if re.fullmatch(r"[\d.]+", host) or ":" in host:
        flags.append("Usa una IP en lugar de dominio")
    if "xn--" in host:
        flags.append("Dominio con caracteres internacionales (posible homógrafo)")
    if "@" in p.netloc:
        flags.append("Contiene @ en la dirección (truco para ocultar el destino)")
    if host.count(".") >= 4:
        flags.append("Demasiados subdominios")
    if len(url) > 150:
        flags.append("URL inusualmente larga")
    if host.split(".")[-1] in RISKY_TLDS:
        flags.append(f"TLD de uso frecuente en abuso (.{host.split('.')[-1]})")
    if host in SHORTENERS:
        flags.append("Acortador de enlaces")
    if p.scheme == "http":
        flags.append("Sin HTTPS")
    lures = [w for w in LURE_WORDS if w in url.lower()]
    if lures:
        flags.append("Palabras gancho: " + ", ".join(lures[:4]))
    return flags


async def virustotal(url: str) -> dict | None:
    if not settings.virustotal_key:
        return None
    h = {"x-apikey": settings.virustotal_key}
    url_id = base64.urlsafe_b64encode(url.encode()).decode().strip("=")
    status, data = await http.get_json(f"https://www.virustotal.com/api/v3/urls/{url_id}", headers=h)
    if status == 404:
        st, sub = await http.post_json("https://www.virustotal.com/api/v3/urls", data={"url": url}, headers=h)
        if st != 200 or not sub:
            return {"error": "No se pudo enviar a VirusTotal"}
        analysis_id = sub["data"]["id"]
        for _ in range(6):
            await asyncio.sleep(5)
            st, an = await http.get_json(f"https://www.virustotal.com/api/v3/analyses/{analysis_id}", headers=h)
            if st == 200 and an and an["data"]["attributes"]["status"] == "completed":
                return {"stats": an["data"]["attributes"]["stats"]}
        return {"error": "Análisis en cola, intenta en un minuto"}
    if status != 200 or not data:
        return {"error": f"VirusTotal respondió {status}"}
    return {"stats": data["data"]["attributes"].get("last_analysis_stats", {})}


async def safebrowsing(url: str) -> list[str] | None:
    if not settings.safebrowsing_key:
        return None
    body = {
        "client": {"clientId": "sentinel-osint", "clientVersion": "1.0"},
        "threatInfo": {
            "threatTypes": ["MALWARE", "SOCIAL_ENGINEERING", "UNWANTED_SOFTWARE", "POTENTIALLY_HARMFUL_APPLICATION"],
            "platformTypes": ["ANY_PLATFORM"],
            "threatEntryTypes": ["URL"],
            "threatEntries": [{"url": url}],
        },
    }
    st, data = await http.post_json(
        f"https://safebrowsing.googleapis.com/v4/threatMatches:find?key={settings.safebrowsing_key}",
        json_body=body)
    if st != 200:
        return None
    return sorted({m["threatType"] for m in (data or {}).get("matches", [])})


async def urlscan(url: str) -> dict | None:
    if not settings.urlscan_key:
        return None
    st, sub = await http.post_json(
        "https://urlscan.io/api/v1/scan/",
        json_body={"url": url, "visibility": "unlisted"},
        headers={"API-Key": settings.urlscan_key},
    )
    if st != 200 or not sub:
        return {"error": f"urlscan respondió {st}"}
    uuid = sub["uuid"]
    for _ in range(10):
        await asyncio.sleep(6)
        st, res = await http.get_json(f"https://urlscan.io/api/v1/result/{uuid}/")
        if st == 200 and res:
            v = res.get("verdicts", {}).get("overall", {})
            page = res.get("page", {})
            return {
                "malicious": v.get("malicious", False),
                "score": v.get("score", 0),
                "ip": page.get("ip"),
                "country": page.get("country"),
                "title": page.get("title"),
                "screenshot": f"https://urlscan.io/screenshots/{uuid}.png",
                "report": f"https://urlscan.io/result/{uuid}/",
            }
    return {"error": "urlscan tardó demasiado"}


async def analyze(url: str) -> tuple[str, str | None]:
    """Devuelve (texto, url_de_captura|None)."""
    fetch_task = http.safe_fetch(url, read_body=False)
    host = urlparse(url).hostname or ""
    fetched, vt, sb, us, who = await asyncio.gather(
        fetch_task, virustotal(url), safebrowsing(url), urlscan(url), get_whois(host))

    flags = heuristics(url)
    final_url = fetched.get("final_url") or url
    if final_url != url:
        flags += [f for f in heuristics(final_url) if f not in flags]
    if who.get("age_days") is not None and who["age_days"] < 30:
        flags.append(f"Dominio registrado hace {who['age_days']} días")

    chain = fetched.get("chain", [])
    chain_rows = [f"{code(s)} {code(u[:70] + ('…' if len(u) > 70 else ''))}" for s, u in chain[:6]]
    if fetched.get("error"):
        chain_rows.append(f"<i>{fetched['error']}</i>")
    redirects = block("Ruta de redirecciones", chain_rows)

    score = len(flags)
    engines = []
    if vt is not None:
        if "stats" in vt:
            m, s = vt["stats"].get("malicious", 0), vt["stats"].get("suspicious", 0)
            total = sum(vt["stats"].values()) or 0
            engines.append(("VirusTotal", f"{m} maliciosos · {s} sospechosos / {total}"))
            score += m * 3 + s
        else:
            engines.append(("VirusTotal", vt["error"]))
    if sb is not None:
        engines.append(("Safe Browsing", ", ".join(sb) if sb else "limpio"))
        score += 6 if sb else 0
    shot = None
    if us is not None:
        if "error" in us:
            engines.append(("urlscan.io", us["error"]))
        else:
            engines.append(("urlscan.io", f"{'malicioso' if us['malicious'] else 'sin veredicto'} · "
                                          f"IP {us.get('ip')} {us.get('country') or ''}"))
            if us.get("title"):
                engines.append(("Título", us["title"][:60]))
            score += 6 if us["malicious"] else 0
            shot = us["screenshot"]
    if not engines:
        engines.append("<i>Configura llaves de VirusTotal, urlscan o Safe Browsing para más motores</i>")

    level = "ok" if score == 0 else "low" if score <= 2 else "mid" if score <= 5 else "high"
    text = join_blocks(
        header("🔗", "Revisión de enlace", url[:120]),
        redirects,
        block("Motores", engines),
        block("Señales", flags) if flags else "",
        verdict(level),
        f"🔎 <a href=\"{us['report']}\">Ver reporte completo</a>" if us and "report" in us else "",
    )
    return text, shot
