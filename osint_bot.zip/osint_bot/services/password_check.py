"""Comprueba si una contraseña apareció en filtraciones, sin que salga del servidor.

Usa el modelo de k-anonimato de Pwned Passwords: solo se envían los primeros
5 caracteres del hash SHA-1; la contraseña completa nunca viaja por la red.
"""
import hashlib

from services import http
from utils import DIV

HIBP_RANGE = "https://api.pwnedpasswords.com/range/"


async def times_pwned(password: str) -> int | None:
    """Número de veces que la contraseña aparece en filtraciones. None si falla la consulta."""
    sha1 = hashlib.sha1(password.encode("utf-8")).hexdigest().upper()
    prefix, suffix = sha1[:5], sha1[5:]
    status, body = await http.get_text(HIBP_RANGE + prefix, headers={"Add-Padding": "true"})
    if status != 200 or not body:
        return None
    for line in body.splitlines():
        h, _, count = line.partition(":")
        if h.strip() == suffix:
            try:
                return int(count.strip())
            except ValueError:
                return 0
    return 0


def _strength_notes(password: str) -> list[str]:
    notes = []
    if len(password) < 12:
        notes.append("Tiene menos de 12 caracteres: alárgala.")
    classes = sum(bool(f(password)) for f in (
        lambda p: any(c.islower() for c in p),
        lambda p: any(c.isupper() for c in p),
        lambda p: any(c.isdigit() for c in p),
        lambda p: any(not c.isalnum() for c in p),
    ))
    if classes < 3:
        notes.append("Combina mayúsculas, minúsculas, números y símbolos.")
    return notes


def format_result(n: int | None, password: str) -> str:
    head = f"🔑 <b>Comprobación de contraseña</b>\n{DIV}\n"
    if n is None:
        return head + "⚠️ El servicio no respondió. Intenta más tarde."
    if n == 0:
        body = ("🟢 <b>No aparece</b> en las filtraciones conocidas.\n"
                "<i>Que no aparezca no garantiza que sea fuerte.</i>")
    else:
        veces = f"{n:,}".replace(",", ".")
        body = (f"🔴 <b>Apareció {veces} veces</b> en filtraciones.\n"
                "<b>No la uses</b> en ningún sitio y cámbiala donde la tengas.")
    notes = _strength_notes(password)
    if notes:
        lines = [f"├ {t}" for t in notes[:-1]] + [f"└ {notes[-1]}"]
        body += "\n\n<b>Además</b>\n" + "\n".join(lines)
    tip = ("\n\n🔒 <i>Tu contraseña no salió del servidor: solo se consultó un fragmento "
           "de su huella (k-anonimato de HIBP).</i>")
    return head + body + tip
