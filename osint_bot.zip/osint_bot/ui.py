"""Helpers de presentación: pantallas con imagen y envío de resultados largos."""
from aiogram import Bot
from aiogram.exceptions import TelegramBadRequest
from aiogram.types import (CallbackQuery, FSInputFile, InlineKeyboardMarkup, InputMediaPhoto, LinkPreviewOptions,
                           Message)

from config import settings
from utils import split_message

NO_PREVIEW = LinkPreviewOptions(is_disabled=True)
_file_ids: dict[str, str] = {}  # caché: nombre de imagen → file_id de Telegram (evita re-subir)


def _photo(name: str):
    return _file_ids.get(name) or FSInputFile(settings.img_dir / name)


def _remember(name: str, msg) -> None:
    if isinstance(msg, Message) and msg.photo:
        _file_ids[name] = msg.photo[-1].file_id


async def send_screen(bot: Bot, chat_id: int, image: str, caption: str, markup: InlineKeyboardMarkup) -> None:
    msg = await bot.send_photo(chat_id, _photo(image), caption=caption, reply_markup=markup)
    _remember(image, msg)


async def show_screen(cb: CallbackQuery, image: str, caption: str, markup: InlineKeyboardMarkup) -> None:
    """Cambia la pantalla editando el mismo mensaje (navegación fluida).
    Si el mensaje no tiene foto (p. ej. un resultado), envía uno nuevo."""
    msg = cb.message
    if isinstance(msg, Message) and msg.photo:
        try:
            res = await msg.edit_media(InputMediaPhoto(media=_photo(image), caption=caption), reply_markup=markup)
            _remember(image, res)
            return
        except TelegramBadRequest as e:
            if "not modified" in str(e):
                return
    await send_screen(cb.bot, cb.from_user.id, image, caption, markup)


async def send_long(message: Message, text: str, markup: InlineKeyboardMarkup | None = None) -> None:
    parts = split_message(text)
    for i, part in enumerate(parts):
        await message.answer(part, reply_markup=markup if i == len(parts) - 1 else None,
                             link_preview_options=NO_PREVIEW)


async def loading(message: Message, label: str = "Analizando") -> Message:
    return await message.answer(f"⏳ <i>{label}…</i>")


async def finish(status: Message, text: str, markup: InlineKeyboardMarkup | None = None) -> None:
    """Reemplaza el mensaje de carga por el resultado."""
    parts = split_message(text)
    if len(parts) == 1:
        try:
            await status.edit_text(parts[0], reply_markup=markup, link_preview_options=NO_PREVIEW)
            return
        except TelegramBadRequest:
            pass
    try:
        await status.delete()
    except TelegramBadRequest:
        pass
    await send_long(status, text, markup)
