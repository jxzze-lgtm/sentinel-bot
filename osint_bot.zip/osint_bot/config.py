"""Configuración central. Todo se lee de variables de entorno (.env)."""
import os
from dataclasses import dataclass, field
from pathlib import Path

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")


def _list_int(value: str) -> list[int]:
    return [int(x) for x in value.replace(" ", "").split(",") if x.strip().isdigit()]


@dataclass(frozen=True)
class Settings:
    bot_token: str = os.getenv("BOT_TOKEN", "")
    admin_ids: list[int] = field(default_factory=lambda: _list_int(os.getenv("ADMIN_IDS", "")))

    # open = cualquiera usa el bot | approval = un admin aprueba a cada usuario nuevo
    access_mode: str = os.getenv("ACCESS_MODE", "approval").lower()

    # Llaves de API (todas opcionales; la herramienta avisa si falta alguna)
    virustotal_key: str = os.getenv("VIRUSTOTAL_API_KEY", "")
    urlscan_key: str = os.getenv("URLSCAN_API_KEY", "")
    safebrowsing_key: str = os.getenv("GOOGLE_SAFEBROWSING_KEY", "")
    hibp_key: str = os.getenv("HIBP_API_KEY", "")
    nvd_key: str = os.getenv("NVD_API_KEY", "")
    abuseipdb_key: str = os.getenv("ABUSEIPDB_API_KEY", "")

    # SMTP para verificar que un correo es tuyo antes de auditar filtraciones
    smtp_host: str = os.getenv("SMTP_HOST", "")
    smtp_port: int = int(os.getenv("SMTP_PORT", "587"))
    smtp_user: str = os.getenv("SMTP_USER", "")
    smtp_password: str = os.getenv("SMTP_PASSWORD", "")
    smtp_from: str = os.getenv("SMTP_FROM", "")

    # Límites
    rate_limit_per_minute: int = int(os.getenv("RATE_LIMIT_PER_MINUTE", "8"))
    max_file_mb: int = int(os.getenv("MAX_FILE_MB", "20"))

    # Horarios (hora del servidor, formato 24 h)
    cve_digest_hour: int = int(os.getenv("CVE_DIGEST_HOUR", "8"))
    brand_scan_hours: int = int(os.getenv("BRAND_SCAN_EVERY_HOURS", "12"))

    # Acortador de enlaces (necesita un puerto abierto y una URL pública)
    shortener_base_url: str = os.getenv("SHORTENER_BASE_URL", "").rstrip("/")
    shortener_port: int = int(os.getenv("SHORTENER_PORT", "8080"))

    db_path: Path = BASE_DIR / "data" / "sentinel.db"
    evidence_dir: Path = BASE_DIR / "data" / "evidence"
    img_dir: Path = BASE_DIR / "assets" / "img"

    @property
    def smtp_enabled(self) -> bool:
        return bool(self.smtp_host and self.smtp_user and self.smtp_password)

    @property
    def shortener_enabled(self) -> bool:
        return bool(self.shortener_base_url)


settings = Settings()
settings.evidence_dir.mkdir(parents=True, exist_ok=True)
settings.db_path.parent.mkdir(parents=True, exist_ok=True)
