from aiogram.fsm.state import State, StatesGroup


class Tool(StatesGroup):
    domain = State()
    ip = State()
    url = State()
    file = State()
    mail = State()
    cve = State()
    cve_kw = State()
    brand = State()
    breach_email = State()
    breach_code = State()
    meta = State()
    archive = State()
    # Nuevas defensivas
    password = State()
    message = State()
    ssl = State()


class Convert(StatesGroup):
    office_pdf = State()
    img_pdf = State()      # acumula varias imágenes
    pdf_img = State()
    merge = State()        # acumula varios PDF
    split = State()
    img_format = State()
    compress = State()
    qr = State()
    decode = State()


class Admin(StatesGroup):
    broadcast = State()
