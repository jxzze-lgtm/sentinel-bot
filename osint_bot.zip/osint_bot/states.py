from aiogram.fsm.state import State, StatesGroup


class Tool(StatesGroup):
    domain = State()
    ip = State()
    url = State()
    file = State()
    mail = State()
    cve = State()
    cve_kw = State()
    brand = State()
    breach_email = State()
    breach_code = State()
    meta = State()
    archive = State()


class Admin(StatesGroup):
    broadcast = State()
