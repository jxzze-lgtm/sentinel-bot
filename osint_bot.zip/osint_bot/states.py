from aiogram.fsm.state import State, StatesGroup


class Tool(StatesGroup):
    domain = State()
    ip = State()
    url = State()
    file = State()
    mail = State()
    cve = State()
    cve_kw = State()
    brand = State()
    breach_email = State()
    breach_code = State()
    meta = State()
    archive = State()
    # Nuevas defensivas
    password = State()
    message = State()
    ssl = State()
    securitytxt = State()


class Convert(StatesGroup):
    office_pdf = State()
    img_pdf = State()      # acumula varias imágenes
    pdf_img = State()
    merge = State()        # acumula varios PDF
    split = State()
    img_format = State()
    compress = State()
    qr = State()
    decode = State()
    # Utilidades añadidas
    convert_any = State()  # unidades o monedas
    translate = State()    # espera el texto tras elegir idioma
    qr_scan = State()      # analizar un QR recibido
    collage = State()      # acumula imágenes para unirlas en una


class Doc(StatesGroup):
    sign_file = State(); sign_name = State()
    wm_file = State(); wm_text = State()
    protect_file = State(); protect_pwd = State()
    unprotect_file = State(); unprotect_pwd = State()
    compress_file = State()
    tables_file = State()


class Biz(StatesGroup):
    receipt = State()
    quote = State()
    wifi = State()
    vcard = State()
    payment = State()


class Prod(StatesGroup):
    reminder = State()
    note = State()
    note_search = State()
    short = State()


class Poll(StatesGroup):
    create = State()


class Admin(StatesGroup):
    broadcast = State()
