"""
Genera las imágenes (banners) del bot con un estilo minimalista.

Uso:  python scripts/generate_assets.py
Salida: assets/img/*.png  (1280x640, formato ideal para Telegram)
"""
from pathlib import Path

from PIL import Image, ImageDraw, ImageFilter, ImageFont

ROOT = Path(__file__).resolve().parent.parent
FONTS = ROOT / "assets" / "fonts"
OUT = ROOT / "assets" / "img"
OUT.mkdir(parents=True, exist_ok=True)

W, H = 1280, 640
BG = (11, 15, 20)
GRID = (28, 34, 43)
TEXT = (236, 240, 244)
MUTED = (139, 150, 164)
ACCENT = (57, 208, 180)
LINE = (36, 44, 55)


def font(name: str, size: int) -> ImageFont.FreeTypeFont:
    return ImageFont.truetype(str(FONTS / name), size)


F_LABEL = font("DejaVuSansMono.ttf", 22)
F_TITLE = font("Inter-Bold.otf", 76)
F_SUB = font("Inter-Regular.otf", 30)
F_CHIP = font("DejaVuSansMono.ttf", 20)
F_NUM = font("Inter-SemiBold.otf", 22)


def radar(img: Image.Image, cx: int, cy: int) -> None:
    """Marca geométrica tipo radar, con brillo suave."""
    glow = Image.new("RGBA", img.size, (0, 0, 0, 0))
    g = ImageDraw.Draw(glow)
    g.ellipse((cx - 120, cy - 120, cx + 120, cy + 120), fill=ACCENT + (60,))
    glow = glow.filter(ImageFilter.GaussianBlur(90))
    img.alpha_composite(glow)

    layer = Image.new("RGBA", img.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    for i, r in enumerate((60, 120, 180, 240)):
        alpha = 150 - i * 30
        d.ellipse((cx - r, cy - r, cx + r, cy + r), outline=ACCENT + (alpha,), width=2)
    d.line((cx - 270, cy, cx + 270, cy), fill=ACCENT + (50,), width=1)
    d.line((cx, cy - 270, cx, cy + 270), fill=ACCENT + (50,), width=1)
    # barrido
    d.pieslice((cx - 240, cy - 240, cx + 240, cy + 240), -60, -20, fill=ACCENT + (38,))
    # puntos detectados
    for px, py, rr in ((cx + 95, cy - 70, 7), (cx - 140, cy + 60, 5), (cx + 40, cy + 150, 5)):
        d.ellipse((px - rr, py - rr, px + rr, py + rr), fill=ACCENT + (230,))
    d.ellipse((cx - 6, cy - 6, cx + 6, cy + 6), fill=TEXT + (255,))
    # recorta el radar para que no invada el pie
    mask = Image.new("L", img.size, 0)
    ImageDraw.Draw(mask).rectangle((0, 0, W, 560), fill=255)
    clipped = Image.new("RGBA", img.size, (0, 0, 0, 0))
    clipped.paste(layer, (0, 0), mask)
    img.alpha_composite(clipped)


def fit_title(d: ImageDraw.ImageDraw, text: str, max_w: int) -> ImageFont.FreeTypeFont:
    size = 76
    f = font("Inter-Bold.otf", size)
    while d.textlength(text, font=f) > max_w and size > 44:
        size -= 2
        f = font("Inter-Bold.otf", size)
    return f


def banner(filename: str, number: str, label: str, title: str, subtitle: str, chips: list[str]) -> None:
    img = Image.new("RGBA", (W, H), BG + (255,))
    d = ImageDraw.Draw(img)

    # rejilla de puntos
    for x in range(40, W, 40):
        for y in range(40, H, 40):
            d.point((x, y), fill=GRID)

    radar(img, 1060, 300)
    d = ImageDraw.Draw(img)

    # etiqueta superior
    x0 = 80
    d.rectangle((x0, 92, x0 + 4, 118), fill=ACCENT)
    d.text((x0 + 18, 92), f"{number}  ·  {label}", font=F_LABEL, fill=MUTED)

    # título y subtítulo
    d.text((x0, 150), title, font=fit_title(d, title, 640), fill=TEXT)
    d.text((x0, 260), subtitle, font=F_SUB, fill=MUTED)

    # chips de herramientas
    cx, cy = x0, 430
    for chip in chips:
        tw = d.textlength(chip, font=F_CHIP)
        w = int(tw) + 36
        if cx + w > 720:
            cx, cy = x0, cy + 58
        d.rounded_rectangle((cx, cy, cx + w, cy + 42), radius=21, outline=LINE, width=2, fill=(17, 22, 29))
        d.text((cx + 18, cy + 9), chip, font=F_CHIP, fill=TEXT)
        cx += w + 12

    # pie
    d.line((x0, 578, W - 80, 578), fill=LINE, width=1)
    d.text((x0, 594), "SENTINEL OSINT", font=F_NUM, fill=TEXT)
    d.text((W - 80 - d.textlength("defensive intelligence", font=F_CHIP), 596),
           "defensive intelligence", font=F_CHIP, fill=MUTED)

    img.convert("RGB").save(OUT / filename, "PNG", optimize=True)
    print("✓", filename)


BANNERS = [
    ("welcome.png", "00", "BIENVENIDO", "Sentinel OSINT",
     "Inteligencia defensiva desde Telegram.",
     ["dominios", "ips", "enlaces", "archivos", "phishing", "cve", "filtraciones", "metadatos", "marca", "evidencia"]),
    ("infra.png", "01", "INFRAESTRUCTURA", "Dominios e IPs",
     "WHOIS, DNS, certificados y reputación.",
     ["whois", "dns", "crt.sh", "asn", "puertos", "blacklists"]),
    ("threats.png", "02", "AMENAZAS", "Análisis de amenazas",
     "Enlaces, archivos y correos sospechosos.",
     ["virustotal", "urlscan", "safe browsing", "spf", "dkim", "dmarc"]),
    ("watch.png", "03", "VIGILANCIA", "Monitoreo continuo",
     "Alertas de CVEs y protección de marca.",
     ["nvd", "cve diario", "typosquatting", "certificados"]),
    ("privacy.png", "04", "PRIVACIDAD", "Tu huella digital",
     "Filtraciones y limpieza de metadatos.",
     ["hibp", "exif", "gps", "pdf", "docx"]),
    ("evidence.png", "05", "EVIDENCIA", "Archivo forense",
     "Captura con sello de tiempo y hash.",
     ["wayback", "sha-256", "utc", "html"]),
    ("admin.png", "AD", "ADMINISTRACIÓN", "Panel de control",
     "Usuarios, accesos y estadísticas.",
     ["usuarios", "aprobar", "bloquear", "difusión", "stats"]),
]

def avatar() -> None:
    """Foto de perfil cuadrada para @BotFather → /setuserpic."""
    size = 640
    img = Image.new("RGBA", (size, size), BG + (255,))
    d = ImageDraw.Draw(img)
    for x in range(32, size, 32):
        for y in range(32, size, 32):
            d.point((x, y), fill=GRID)
    cx = cy = size // 2
    glow = Image.new("RGBA", img.size, (0, 0, 0, 0))
    ImageDraw.Draw(glow).ellipse((cx - 110, cy - 110, cx + 110, cy + 110), fill=ACCENT + (70,))
    img.alpha_composite(glow.filter(ImageFilter.GaussianBlur(70)))
    layer = Image.new("RGBA", img.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    for i, r in enumerate((70, 140, 210)):
        d.ellipse((cx - r, cy - r, cx + r, cy + r), outline=ACCENT + (220 - i * 50,), width=6)
    d.pieslice((cx - 210, cy - 210, cx + 210, cy + 210), -60, -20, fill=ACCENT + (60,))
    d.ellipse((cx + 75, cy - 95, cx + 101, cy - 69), fill=ACCENT + (255,))
    d.ellipse((cx - 14, cy - 14, cx + 14, cy + 14), fill=TEXT + (255,))
    img.alpha_composite(layer)
    img.convert("RGB").save(OUT / "avatar.png", "PNG", optimize=True)
    print("✓ avatar.png")


if __name__ == "__main__":
    for b in BANNERS:
        banner(*b)
    avatar()
