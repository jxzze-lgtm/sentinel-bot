"""Utilidades de formato, validación y límites de uso."""
import html
import ipaddress
import re
import time
from collections import defaultdict, deque
from urllib.parse import urlparse

DIV = "━━━━━━━━━━━━━━━━━━"
MAX_MSG = 3900  # margen bajo el límite de 4096 de Telegram

DOMAIN_RE = re.compile(
    r"^(?=.{1,253}$)(?!-)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+(?:[a-z]{2,63}|xn--[a-z0-9-]{2,59})$"
)
EMAIL_RE = re.compile(r"^[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}$")
CVE_RE = re.compile(r"^CVE-\d{4}-\d{4,}$", re.I)


# ── Formato ─────────────────────────────────────────────────────────────
def esc(value) -> str:
    return html.escape(str(value), quote=False)


def code(value) -> str:
    return f"<code>{esc(value)}</code>"


def header(emoji: str, title: str, target: str | None = None) -> str:
    line = f"{emoji} <b>{esc(title)}</b>"
    if target:
        line += f"\n{code(target)}"
    return f"{line}\n{DIV}"


def block(title: str, rows: list[tuple[str, object]] | list[str]) -> str:
    """Bloque con estilo de árbol:
    <b>Título</b>
    ├ clave · valor
    └ clave · valor
    """
    rows = [r for r in rows if r not in (None, "") and (not isinstance(r, tuple) or r[1] not in (None, "", []))]
    if not rows:
        return ""
    out = [f"<b>{esc(title)}</b>"]
    for i, row in enumerate(rows):
        branch = "└" if i == len(rows) - 1 else "├"
        if isinstance(row, tuple):
            k, v = row
            out.append(f"{branch} {esc(k)} · {code(v)}")
        else:
            out.append(f"{branch} {row}")
    return "\n".join(out)


def join_blocks(*parts: str) -> str:
    return "\n\n".join(p for p in parts if p)


def verdict(level: str) -> str:
    return {
        "ok": "🟢 <b>Sin indicios de riesgo</b>",
        "low": "🟡 <b>Riesgo bajo</b>",
        "mid": "🟠 <b>Sospechoso</b>",
        "high": "🔴 <b>Alto riesgo</b>",
        "na": "⚪️ <b>Sin datos suficientes</b>",
    }[level]


def split_message(text: str, limit: int = MAX_MSG) -> list[str]:
    """Divide respetando saltos de línea para no romper etiquetas HTML."""
    if len(text) <= limit:
        return [text]
    parts, current = [], ""
    for line in text.split("\n"):
        if len(current) + len(line) + 1 > limit:
            parts.append(current)
            current = ""
        current += line + "\n"
    if current.strip():
        parts.append(current)
    return parts


def human_size(n: int) -> str:
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024:
            return f"{n:.0f} {unit}" if unit == "B" else f"{n:.1f} {unit}"
        n /= 1024
    return f"{n:.1f} TB"


# ── Validación ──────────────────────────────────────────────────────────
def normalize_domain(text: str) -> str | None:
    t = text.strip().lower()
    if "://" in t:
        t = urlparse(t).hostname or ""
    t = t.split("/")[0].split(":")[0].strip(".")
    if t.startswith("www."):
        t = t[4:]
    try:
        t = t.encode("idna").decode("ascii")
    except UnicodeError:
        return None
    return t if DOMAIN_RE.match(t) else None


def normalize_ip(text: str) -> ipaddress._BaseAddress | None:
    try:
        ip = ipaddress.ip_address(text.strip())
    except ValueError:
        return None
    return ip


def is_public_ip(ip: ipaddress._BaseAddress) -> bool:
    return ip.is_global and not ip.is_multicast


def normalize_url(text: str) -> str | None:
    t = text.strip()
    if not re.match(r"^[a-z][a-z0-9+.-]*://", t, re.I):
        t = "http://" + t
    p = urlparse(t)
    if p.scheme not in ("http", "https") or not p.hostname:
        return None
    host = p.hostname
    ip = normalize_ip(host)
    if ip is not None and not is_public_ip(ip):
        return None  # evita que el bot consulte redes internas (SSRF)
    if host in ("localhost",) or host.endswith(".local") or host.endswith(".internal"):
        return None
    return t


def is_email(text: str) -> bool:
    return bool(EMAIL_RE.match(text.strip()))


# ── Límite de uso ───────────────────────────────────────────────────────
class RateLimiter:
    def __init__(self, per_minute: int):
        self.per_minute = per_minute
        self.hits: dict[int, deque] = defaultdict(deque)

    def allow(self, user_id: int) -> bool:
        now = time.monotonic()
        q = self.hits[user_id]
        while q and now - q[0] > 60:
            q.popleft()
        if len(q) >= self.per_minute:
            return False
        q.append(now)
        return True
